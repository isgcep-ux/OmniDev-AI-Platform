package com.example

import com.example.data.local.entity.AiTutorCacheEntity
import com.example.data.local.entity.CachedAiTutorResponseAndUserData
import com.example.data.local.entity.IsgQuizHistoryEntity
import com.example.data.local.entity.UserDataEntity
import com.example.data.local.entity.UserWithCachedAiResponses
import com.example.model.IsgAiGeneratedQuestion
import org.junit.Assert.*
import org.junit.Test

class ExampleUnitTest {
    @Test
    fun addition_isCorrect() {
        assertEquals(4, 2 + 2)
    }

    @Test
    fun isgQuizHistoryEntity_scoreCalculation_isAccurate() {
        val total = 5
        val correct = 4
        val scorePct = (correct.toDouble() / total) * 100.0
        val history = IsgQuizHistoryEntity(
            examCategory = "6331 Sayılı İSG Kanunu",
            totalQuestions = total,
            correctAnswers = correct,
            scorePercentage = scorePct,
            difficulty = "ÖSYM Formatı",
            sourceDomain = "isgcepakademi.com.tr"
        )

        assertEquals(80.0, history.scorePercentage, 0.01)
        assertEquals("6331 Sayılı İSG Kanunu", history.examCategory)
        assertEquals("isgcepakademi.com.tr", history.sourceDomain)
    }

    @Test
    fun isgAiGeneratedQuestion_creation_isProper() {
        val question = IsgAiGeneratedQuestion(
            id = "test_q_1",
            category = "A Sınıfı İGU",
            topic = "Mevzuat",
            difficulty = "İleri / Uzmanlık",
            domain = "isgcepakademi.com",
            question = "İSG mevzuat sorusu?",
            options = listOf("A", "B", "C", "D"),
            correctIndex = 0,
            explanation = "Açıklama",
            legislationReference = "Madde 8"
        )

        assertTrue(question.isAiGenerated)
        assertEquals(4, question.options.size)
        assertEquals(0, question.correctIndex)
    }

    @Test
    fun isgCourseModule_validation_isAccurate() {
        val course = com.example.model.IsgCourseModule(
            id = "course_1",
            title = "6331 Sayılı Kanun",
            category = "Mevzuat & Hukuk",
            level = "İleri Düzey",
            durationHours = 24,
            instructor = "Av. Canan Kaya",
            domain = "isgcepakademi.com.tr",
            description = "Eğitim açıklaması",
            targetAudience = "İGU'lar",
            learningObjectives = listOf("Öğrenim çıktısı 1"),
            syllabus = listOf("Modül 1"),
            certificationInfo = "Sertifika"
        )

        assertEquals("course_1", course.id)
        assertEquals(24, course.durationHours)
        assertFalse(course.isCompleted)
        assertEquals("isgcepakademi.com.tr", course.domain)
    }

    @Test
    fun isgHapBilgi_and_katipFormula_isAccurate() {
        val repo = com.example.data.repository.DevStudioRepository()
        val hapBilgileri = repo.getIsgHapBilgileri()
        assertTrue(hapBilgileri.isNotEmpty())

        // 120 employees in Tehlikeli class: 120 * 20 min = 2400 min (40 hours)
        val employeeCount = 120
        val iguMinutesPerEmployee = 20
        val totalMinutes = employeeCount * iguMinutesPerEmployee
        assertEquals(2400, totalMinutes)
        assertEquals(40.0, totalMinutes / 60.0, 0.001)

        // 38 correct out of 50 in ÖSYM: score = 38 * 2 = 76 (passed >= 70)
        val correctCount = 38
        val score = correctCount * 2
        assertEquals(76, score)
        assertTrue(score >= 70)
    }

    @Test
    fun courseProgressAggregation_calculatesAverageAndCategoryWeightsCorrectly() {
        val course1 = com.example.model.IsgCourseModule(
            id = "c1",
            title = "Mevzuat 1",
            category = "Mevzuat & Hukuk",
            level = "Temel",
            durationHours = 10,
            instructor = "Eğitmen",
            domain = "isgcepakademi.com.tr",
            description = "Desc",
            targetAudience = "Audience",
            learningObjectives = listOf(),
            syllabus = listOf("Part 1", "Part 2"),
            certificationInfo = "Cert",
            isCompleted = true,
            progressPercentage = 100,
            completedSyllabusItems = listOf("Part 1", "Part 2")
        )
        val course2 = com.example.model.IsgCourseModule(
            id = "c2",
            title = "Mevzuat 2",
            category = "Mevzuat & Hukuk",
            level = "İleri",
            durationHours = 20,
            instructor = "Eğitmen",
            domain = "isgcepakademi.com.tr",
            description = "Desc",
            targetAudience = "Audience",
            learningObjectives = listOf(),
            syllabus = listOf("Part 1", "Part 2"),
            certificationInfo = "Cert",
            isCompleted = false,
            progressPercentage = 50,
            completedSyllabusItems = listOf("Part 1")
        )

        val courses = listOf(course1, course2)
        val avgProgress = courses.sumOf { it.progressPercentage } / courses.size
        assertEquals(75, avgProgress)
        val completedCount = courses.count { it.isCompleted }
        assertEquals(1, completedCount)
    }

    @Test
    fun certificateEligibility_triggersWhenCourseCompleted() {
        val completedCourse = com.example.model.IsgCourseModule(
            id = "isg_mod_01",
            title = "İş Güvenliği Uzmanlığı Temel Eğitimi",
            category = "Mevzuat & Hukuk",
            level = "Temel",
            durationHours = 40,
            instructor = "Dr. Ahmet Yılmaz",
            domain = "isgcepakademi.com.tr",
            description = "Eğitim",
            targetAudience = "Uzmanlar",
            learningObjectives = listOf(),
            syllabus = listOf("Konu 1", "Konu 2"),
            certificationInfo = "Akredite Belge",
            isCompleted = true,
            progressPercentage = 100,
            completedSyllabusItems = listOf("Konu 1", "Konu 2")
        )

        val isEligible = completedCourse.isCompleted || completedCourse.progressPercentage >= 100
        assertTrue(isEligible)
        val certSerial = "ISG-CERT-2026-${completedCourse.id.uppercase().take(8)}-AKD"
        assertTrue(certSerial.startsWith("ISG-CERT-2026-"))
    }

    @Test
    fun voiceAndVideoPipeline_validationAndSubtitleGeneration() {
        val voiceProfile = com.example.model.ClonedVoiceProfile(
            id = "test_voice",
            name = "Test Eğitmen Klon",
            provider = "ElevenLabs Instant Cloning",
            voiceId = "el_test_123",
            description = "Test Ses",
            gender = "Erkek"
        )
        assertEquals("ElevenLabs Instant Cloning", voiceProfile.provider)
        assertTrue(voiceProfile.stability in 0.0f..1.0f)

        val sampleScript = "Yüksekte çalışmalarda yaşam hatları hayati önem taşır. Emniyet kemeri takılmalıdır."
        val words = sampleScript.split(" ").filter { it.isNotBlank() }
        val estimatedDuration = (words.size / 2.5).toInt().coerceAtLeast(4)
        assertTrue(estimatedDuration >= 4)

        val job = com.example.model.VideoGenerationPipelineJob(
            id = "VID-TEST-01",
            title = "Yüksekte Çalışma",
            courseDomain = "isgcepakademi.com.tr",
            scriptText = sampleScript,
            voiceProfile = voiceProfile,
            avatarStyle = "3D İSG Baş Denetçisi",
            format = "9:16 Dikey (Shorts/Reels/TikTok)",
            status = com.example.model.VideoJobStatus.COMPLETED,
            progressPercent = 100,
            durationSeconds = estimatedDuration,
            outputVideoUrl = "https://cdn.isgcepakademi.com.tr/videos/test.mp4",
            outputAudioUrl = "https://cdn.isgcepakademi.com.tr/audio/test.mp3"
        )

        assertEquals(com.example.model.VideoJobStatus.COMPLETED, job.status)
        assertTrue(job.outputVideoUrl.endsWith(".mp4"))
        assertTrue(job.outputAudioUrl.endsWith(".mp3"))
    }

    @Test
    fun elevenLabsClient_requestModelAndSettings_validation() {
        val voiceSettings = com.example.data.remote.elevenlabs.VoiceSettings(
            stability = 0.80f,
            similarityBoost = 0.90f,
            style = 0.0f,
            useSpeakerBoost = true
        )
        val request = com.example.data.remote.elevenlabs.ElevenLabsTtsRequest(
            text = "İskelelerde çalışma platformları standartlara uygun olmalıdır.",
            modelId = com.example.data.remote.elevenlabs.ElevenLabsClient.MODEL_MULTILINGUAL_V2,
            voiceSettings = voiceSettings
        )

        assertEquals("eleven_multilingual_v2", request.modelId)
        assertEquals(0.80f, request.voiceSettings?.stability)
        assertEquals(0.90f, request.voiceSettings?.similarityBoost)
        assertTrue(request.voiceSettings?.useSpeakerBoost == true)

        val client = com.example.data.remote.elevenlabs.ElevenLabsClient(apiKey = "test_xi_api_key_123")
        assertTrue(client.hasApiKey())
        client.setApiKey("new_test_key_456")
        assertTrue(client.hasApiKey())
    }

    @Test
    fun moduleNarration_scriptParsingAndDurationCalculation() {
        val courseScript = "6331 sayılı İş Sağlığı ve Güvenliği Kanunu Madde 4 gereğince işveren, çalışanların işle ilgili sağlık ve güvenliğini sağlamakla yükümlüdür."
        val words = courseScript.split(Regex("\\s+")).filter { it.isNotBlank() }
        val wordCount = words.size
        val estimatedDurationSec = (wordCount / 2.5).toInt().coerceAtLeast(3)

        assertEquals(19, wordCount)
        assertTrue(estimatedDurationSec >= 7)

        val voice = com.example.model.ClonedVoiceProfile(
            id = "el_voice_1",
            name = "Eğitmen Ahmet Bey",
            provider = "ElevenLabs Instant Cloning",
            voiceId = "21m00Tcm4TlvDq8ikWAM",
            description = "İSG Eğitmen Ses Tonu",
            gender = "Erkek",
            stability = 0.75f,
            similarityBoost = 0.85f
        )
        assertEquals("21m00Tcm4TlvDq8ikWAM", voice.voiceId)
        assertTrue(voice.stability > 0.5f)
    }

    @Test
    fun isgCoursePdfDocument_urlAndMetadata_validation() {
        val repo = com.example.data.repository.DevStudioRepository()
        val courses = repo.getIsgCourseModules()

        assertTrue(courses.isNotEmpty())
        courses.forEach { course ->
            assertTrue("Course ${course.id} must have a valid PDF url", course.pdfDocumentUrl.isNotBlank())
            assertTrue("Course ${course.id} PDF url must match isgcepakademi domains",
                course.pdfDocumentUrl.contains("isgcepakademi.com.tr") ||
                course.pdfDocumentUrl.contains("isgcepakademi.xyz") ||
                course.pdfDocumentUrl.contains("isgcepakademi.com")
            )
            assertTrue("PDF document must end with .pdf", course.pdfDocumentUrl.endsWith(".pdf"))
            assertTrue("PDF document title must not be empty", course.documentTitle.isNotBlank())
            assertTrue("PDF page count must be >= 6", course.documentPagesCount >= 6)
            assertTrue("PDF file size must have MB unit", course.documentFileSize.contains("MB"))
        }
    }

    @Test
    fun personalPcWorkstation_configAndResources_validation() {
        val repo = com.example.data.repository.DevStudioRepository()
        val pc = repo.getPersonalWorkstationConfig()

        assertEquals("ozben-workstation-pc", pc.hostname)
        assertEquals("Özben A.", pc.ownerName)
        assertEquals(32, pc.ramTotalGb)
        assertEquals(512, pc.diskTotalGb)
        assertTrue(pc.cpuUsagePercent >= 0)
        assertTrue(pc.ramUsedGb > 0)
        assertTrue(pc.emulatorDpiScale in 0.5f..2.0f)
        assertEquals("192.168.1.108", pc.localIp)
    }

    @Test
    fun personalWorkspaceFiles_and_notes_validation() {
        val repo = com.example.data.repository.DevStudioRepository()
        val files = repo.getInitialWorkspaceFiles()
        val notes = repo.getInitialWorkspaceNotes()
        val terminalEntries = repo.getInitialTerminalEntries()

        assertTrue(files.isNotEmpty())
        files.forEach { file ->
            assertTrue(file.name.isNotBlank())
            assertTrue(file.path.startsWith("/workspace/"))
            assertTrue(file.content.isNotBlank())
        }

        assertTrue(notes.isNotEmpty())
        notes.forEach { note ->
            assertTrue(note.title.isNotBlank())
            assertTrue(note.content.isNotBlank())
            assertTrue(note.tags.isNotEmpty())
        }

        assertTrue(terminalEntries.isNotEmpty())
        assertEquals("neofetch", terminalEntries[0].command)
    }

    @Test
    fun cachedAiTutorResponseAndUserData_schemaValidation_isComplete() {
        val cacheEntry = CachedAiTutorResponseAndUserData(
            id = 1L,
            userId = "user_igu_99",
            userName = "Ahmet Yılmaz",
            userEmail = "ahmet@isgcepakademi.com.tr",
            userRole = "A Sınıfı İGU",
            completedLessonsCount = 14,
            totalExamScoreAvg = 84.5,
            promptQuery = "6331 sayılı kanuna göre acil durum planı kaç yılda bir yenilenir?",
            responseMarkdown = "Çok tehlikeli işyerlerinde 2 yılda bir, tehlikeli işyerlerinde 4 yılda bir, az tehlikeli işyerlerinde 6 yılda bir yenilenir.",
            category = "Acil Durum & Tahliye",
            moduleCode = "ISG-6331-M11",
            legalArticleReferences = "6331 Sayılı Kanun Madde 11, Acil Durumlar Hakkında Yönetmelik Madde 19",
            confidenceScore = 0.98,
            isFavorite = true,
            userNotes = "Sınavda sıkça çıkıyor, periyotlara dikkat edilmeli."
        )

        assertEquals("user_igu_99", cacheEntry.userId)
        assertEquals("Ahmet Yılmaz", cacheEntry.userName)
        assertEquals("A Sınıfı İGU", cacheEntry.userRole)
        assertEquals(14, cacheEntry.completedLessonsCount)
        assertEquals(84.5, cacheEntry.totalExamScoreAvg, 0.01)
        assertTrue(cacheEntry.promptQuery.contains("acil durum planı"))
        assertTrue(cacheEntry.responseMarkdown.contains("Çok tehlikeli işyerlerinde 2 yılda bir"))
        assertEquals("Acil Durum & Tahliye", cacheEntry.category)
        assertEquals("ISG-6331-M11", cacheEntry.moduleCode)
        assertEquals(0.98, cacheEntry.confidenceScore, 0.01)
        assertTrue(cacheEntry.isFavorite)
        assertTrue(cacheEntry.timestamp > 0)
    }

    @Test
    fun userWithCachedAiResponses_relationSchema_isFunctional() {
        val user = UserDataEntity(
            userId = "user_dsp_12",
            displayName = "Zeynep Demir",
            email = "zeynep@isgcepakademi.com",
            role = "İşyeri Hemşiresi / DSP",
            completedLessonsCount = 8,
            totalExamScoreAvg = 78.0
        )

        val response1 = AiTutorCacheEntity(
            id = 101L,
            userId = user.userId,
            promptQuery = "Periyodik sağlık muayeneleri sıklığı nedir?",
            responseMarkdown = "Çok tehlikeli en geç yılda bir, tehlikeli en geç 3 yılda bir, az tehlikeli en geç 5 yılda bir yapılır.",
            category = "Sağlık Gözetimi"
        )

        val response2 = AiTutorCacheEntity(
            id = 102L,
            userId = user.userId,
            promptQuery = "Biyolojik risk etkenleri yönetmeliği aşı temini yükümlülüğü kime aittir?",
            responseMarkdown = "İşveren, çalışanlara ücretsiz olarak uygun aşı temin etmekle yükümlüdür.",
            category = "Biyolojik Riskler"
        )

        val relation = UserWithCachedAiResponses(
            user = user,
            cachedResponses = listOf(response1, response2)
        )

        assertEquals("user_dsp_12", relation.user.userId)
        assertEquals(2, relation.cachedResponses.size)
        assertEquals("Periyodik sağlık muayeneleri sıklığı nedir?", relation.cachedResponses[0].promptQuery)
        assertEquals("user_dsp_12", relation.cachedResponses[0].userId)
    }
}



