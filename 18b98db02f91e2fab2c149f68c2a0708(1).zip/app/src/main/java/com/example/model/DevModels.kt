package com.example.model

enum class MainTab(val title: String, val group: String) {
    // IDX Group
    FLUTTER("Flutter Web", "PRIMARY IDX"),
    NEXTJS("Next.js App", "PRIMARY IDX"),
    FIREBASE("Firebase", "PRIMARY IDX"),
    DATABASE("Database", "PRIMARY IDX"),
    TESTS("Tests Suite", "PRIMARY IDX"),
    DEPLOYMENT("Deploy", "PRIMARY IDX"),

    // AI Studio Group
    GEMINI_MODELS("Models", "AI STUDIO"),
    PROMPT_STUDIO("Prompt Studio", "AI STUDIO"),
    QA_GENERATOR("AI Q&A", "AI STUDIO"),
    TUTOR_CHAT("Chatbot Tutor", "AI STUDIO"),
    INTEGRATION_SDK("SDK Hub", "AI STUDIO"),

    // İSG Cep Akademi Group
    ISG_HAP_BILGILER("Hap Bilgiler & Hesaplama", "İSG AKADEMİ"),
    ISG_COURSES("Eğitim Modülleri", "İSG AKADEMİ"),
    ISG_PLUGINS("Eklentiler & Hub", "İSG AKADEMİ"),
    ISG_AI_QA("AI Soru Bankası & Geçmiş", "İSG AKADEMİ"),
    ISG_EXAMS("Sınav Simülatörü", "İSG AKADEMİ"),
    ISG_RISK_CALC("Risk Hesaplayıcı", "İSG AKADEMİ"),
    ISG_API_SUITE("API & Webhook", "İSG AKADEMİ"),
    ISG_VOICE_STUDIO("Klon Ses & Video", "İSG AKADEMİ"),

    // Personal Computer & Workstation Group
    PC_DESKTOP("Kişisel Masaüstü & Sistem", "KİŞİSEL PC"),
    PC_EXPLORER("Dosya Gezgini & Depo", "KİŞİSEL PC"),
    PC_TERMINAL("Geliştirici Terminali", "KİŞİSEL PC"),
    PC_NOTES("Çalışma Defteri & Notlar", "KİŞİSEL PC"),
    PC_SETTINGS("PC & Emülatör Ayarları", "KİŞİSEL PC")
}

data class IsgHapBilgi(
    val id: String,
    val title: String,
    val category: String, // "Kritik Süreler & Periyotlar", "Çalışan & Temsilci Sayıları", "Eşik & Eylem Değerleri", "İSG Kurulları & Kâtip", "Yangın & Acil Durum", "Kimyasal & Biyolojik Riskler"
    val summary: String,
    val keyPoints: List<String>,
    val lawReference: String,
    val badge: String,
    val isFavorite: Boolean = false
)

data class IsgCourseModule(
    val id: String,
    val title: String,
    val category: String, // "Mevzuat & Hukuk", "Saha Güvenliği & KKD", "Risk & Metodoloji", "Sağlık & İlkyardım", "Global & Sertifikasyon"
    val level: String, // "Temel Seviye", "Orta Düzey", "İleri Düzey / Uzmanlık"
    val durationHours: Int,
    val instructor: String,
    val domain: String, // "isgcepakademi.com", "isgcepakademi.com.tr", "isgcepakademi.xyz"
    val description: String,
    val targetAudience: String,
    val learningObjectives: List<String>,
    val syllabus: List<String>,
    val certificationInfo: String,
    val isCompleted: Boolean = false,
    val progressPercentage: Int = 0,
    val completedSyllabusItems: List<String> = emptyList(),
    val enrolledCount: Int = 1240,
    val rating: Double = 4.9,
    val pdfDocumentUrl: String = "",
    val documentTitle: String = "",
    val documentPagesCount: Int = 8,
    val documentFileSize: String = "3.2 MB"
)

data class IsgAiGeneratedQuestion(
    val id: String,
    val category: String, // "6331 Sayılı İSG Kanunu", "A Sınıfı İGU", "B Sınıfı İGU", "C Sınıfı İGU", "İşyeri Hekimliği", "DSP", "Risk Metodolojileri & Fine-Kinney", "KKD & Standartlar"
    val topic: String,
    val difficulty: String, // "Temel Seviye", "Orta Düzey", "İleri / Uzmanlık", "ÖSYM Çıkmış Formatı"
    val domain: String, // "isgcepakademi.com", "isgcepakademi.com.tr", "isgcepakademi.xyz"
    val question: String,
    val options: List<String>,
    val correctIndex: Int,
    val explanation: String,
    val legislationReference: String,
    val isAiGenerated: Boolean = true
)

data class IsgPlugin(
    val id: String,
    val title: String,
    val description: String,
    val domain: String, // "isgcepakademi.com.tr" or "isgcepakademi.xyz" or "Tümü"
    val version: String,
    val author: String,
    val category: String, // "Mevzuat", "Risk Analizi", "Sınav & Eğitim", "Kâtip & Atama", "Raporlama & AI"
    val isInstalled: Boolean = true,
    val rating: Double = 4.9,
    val downloads: String = "25.4K",
    val features: List<String>,
    val manifestJson: String,
    val apiEndpoints: List<String>,
    val docsUrl: String
)

data class IsgExamQuestion(
    val id: String,
    val examType: String, // "A Sınıfı İGU", "B Sınıfı İGU", "C Sınıfı İGU", "İşyeri Hekimliği", "Diğer Sağlık Personeli (DSP)"
    val topic: String,
    val question: String,
    val options: List<String>,
    val correctIndex: Int,
    val explanation: String,
    val legislationReference: String
)

data class IsgRiskAssessment(
    val id: String,
    val activity: String,
    val dangerSource: String,
    val riskDescription: String,
    val probability: Double, // Fine-Kinney: 0.2 - 10, Matrix: 1 - 5
    val severity: Double,    // Fine-Kinney: 1 - 100, Matrix: 1 - 5
    val frequency: Double,   // Fine-Kinney: 0.5 - 10
    val method: String,      // "Fine-Kinney" or "5x5 Matris"
    val score: Double,
    val riskLevel: String,   // "Tolerans Edilemez", "Esaslı Risk", "Önemli Risk", "Olası Risk", "Kabul Edilebilir"
    val recommendedActions: List<String>
)

data class IsgApiEndpoint(
    val method: String,
    val path: String,
    val domain: String,
    val title: String,
    val description: String,
    val requestSample: String,
    val responseSample: String
)

data class FlutterPreset(
    val id: String,
    val title: String,
    val description: String,
    val stateManagement: String,
    val renderer: String,
    val sampleCode: String,
    val pubspecYaml: String
)

data class NextJsRoute(
    val path: String,
    val type: String, // "Server Component", "Client Component", "Server Action", "API Route"
    val renderStrategy: String, // "SSR", "SSG", "ISR", "Dynamic"
    val codeSnippet: String
)

data class FirebaseRuleTest(
    val name: String,
    val path: String,
    val authRole: String, // "authenticated", "anonymous", "admin", "unauthenticated"
    val operation: String, // "read", "write", "delete"
    val allowed: Boolean,
    val explanation: String
)

data class DbTableSchema(
    val tableName: String,
    val columns: List<DbColumn>,
    val sampleRows: List<Map<String, String>>
)

data class DbColumn(
    val name: String,
    val type: String,
    val isPrimary: Boolean = false,
    val isNullable: Boolean = false
)

data class TestCase(
    val id: String,
    val title: String,
    val suite: String,
    val framework: String,
    val status: TestStatus = TestStatus.PENDING,
    val durationMs: Long = 0,
    val errorMessage: String? = null
)

enum class TestStatus {
    PENDING, RUNNING, PASSED, FAILED
}

data class DeploymentTarget(
    val id: String,
    val name: String,
    val provider: String,
    val url: String,
    val status: String,
    val lastDeployTime: String,
    val buildSteps: List<String>
)

data class GeminiModelSpec(
    val modelId: String,
    val displayName: String,
    val badge: String,
    val contextWindow: String,
    val bestFor: String,
    val latencyMs: Int,
    val inputCostPerMillion: String,
    val outputCostPerMillion: String,
    val capabilities: List<String>
)

data class PromptTemplate(
    val id: String,
    val title: String,
    val category: String,
    val systemInstruction: String,
    val userPrompt: String,
    val expectedOutputFormat: String
)

data class QuizQuestion(
    val id: String,
    val stack: String, // "Flutter", "Next.js", "Firebase", "Gemini", "Database"
    val difficulty: String, // "Junior", "Intermediate", "Senior", "Architect"
    val question: String,
    val options: List<String>,
    val correctIndex: Int,
    val explanation: String
)

data class SdkSnippet(
    val language: String,
    val extension: String,
    val title: String,
    val code: String
)

data class ClonedVoiceProfile(
    val id: String,
    val name: String,
    val provider: String, // "ElevenLabs Instant Cloning", "Google Cloud Custom Voice", "Gemini Multi-speaker Audio"
    val voiceId: String,
    val language: String = "tr-TR",
    val description: String,
    val gender: String, // "Erkek", "Kadın"
    val stability: Float = 0.75f,
    val similarityBoost: Float = 0.85f,
    val sampleAudioDurationSec: Int = 18,
    val isDefault: Boolean = false
)

data class VideoGenerationPipelineJob(
    val id: String,
    val title: String,
    val courseDomain: String, // "isgcepakademi.com", "isgcepakademi.com.tr", "isgcepakademi.xyz"
    val scriptText: String,
    val voiceProfile: ClonedVoiceProfile,
    val avatarStyle: String, // "3D İSG Baş Denetçisi", "Gerçekçi Şantiye Şefi Avatarı", "Minimalist Eğitmen", "Hap Bilgi Reels Karakteri"
    val format: String, // "16:9 Yatay (YouTube/LMS)", "9:16 Dikey (Shorts/Reels/TikTok)"
    val status: VideoJobStatus = VideoJobStatus.COMPLETED,
    val progressPercent: Int = 100,
    val durationSeconds: Int = 45,
    val outputVideoUrl: String = "",
    val outputAudioUrl: String = "",
    val subtitles: List<VideoSubtitleCue> = emptyList(),
    val createdAt: String = "2026-08-25 12:30"
)

enum class VideoJobStatus {
    IDLE,
    SYNTHESIZING_AUDIO,
    GENERATING_AVATAR_LIPSYNC,
    COMPOSITING_SLIDES_BROLL,
    RENDERING_FINAL_MP4,
    COMPLETED,
    FAILED
}

data class VideoSubtitleCue(
    val startMs: Long,
    val endMs: Long,
    val text: String
)

data class PersonalPcWorkstation(
    val hostname: String = "ozben-dev-station",
    val ownerName: String = "Özben A.",
    val ownerRole: String = "Kıdemli Bulut Mimarı & İSG Baş Uzmanı",
    val osName: String = "DevOS Workstation Linux (x86_64)",
    val kernelVersion: String = "6.8.0-devstudio-cloud-hybrid",
    val cpuModel: String = "AMD Ryzen 9 7950X / Google Cloud DevEngine (16 vCPU)",
    val cpuUsagePercent: Int = 22,
    val ramTotalGb: Int = 32,
    val ramUsedGb: Double = 9.2,
    val diskTotalGb: Int = 512,
    val diskUsedGb: Double = 142.8,
    val localIp: String = "192.168.1.108",
    val uptimeFormatted: String = "7 gün, 18 saat, 45 dk",
    val isTurboBoostEnabled: Boolean = true,
    val activeTheme: String = "Cyber Matrix Dark", // "Cyber Matrix Dark", "IDX Modern Slate", "Clean Studio Light", "Retro CRT Amber"
    val emulatorDpiScale: Float = 1.0f,
    val windowMode: String = "Desktop Workstation",
    val personalNotesCount: Int = 6,
    val filesCount: Int = 12
)

data class PersonalWorkspaceFile(
    val id: String,
    val path: String,
    val name: String,
    val extension: String,
    val sizeBytes: Long,
    val content: String,
    val category: String, // "KAYNAK KOD", "YAPILANDIRMA", "İSG RAPORU", "DOKÜMAN", "SCRİPT"
    val lastModified: String = "2026-08-25 13:20"
)

data class PersonalWorkspaceNote(
    val id: String,
    val title: String,
    val content: String,
    val category: String, // "Geliştirme", "İSG Mevzuat", "Sistem & Terminal", "Yapılacaklar"
    val isPinned: Boolean = false,
    val updatedAt: String = "2026-08-25 13:15",
    val tags: List<String> = emptyList()
)

data class PersonalTerminalEntry(
    val id: String,
    val command: String,
    val output: String,
    val isError: Boolean = false,
    val timestamp: String = "13:20:05",
    val workingDir: String = "~/workspace"
)


