package com.example.data.remote.elevenlabs

import android.util.Log
import com.squareup.moshi.Moshi
import com.squareup.moshi.kotlin.reflect.KotlinJsonAdapterFactory
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.Interceptor
import okhttp3.OkHttpClient
import okhttp3.ResponseBody
import okhttp3.logging.HttpLoggingInterceptor
import retrofit2.Response
import retrofit2.Retrofit
import retrofit2.converter.moshi.MoshiConverterFactory
import java.io.File
import java.io.FileOutputStream
import java.io.InputStream
import java.util.concurrent.TimeUnit

/**
 * Production-ready ElevenLabs API wrapper in Kotlin using Retrofit.
 * Handles authenticated Text-to-Speech requests, voice management,
 * and audio serialization for video narration generation pipelines.
 */
class ElevenLabsClient(
    private var apiKey: String = "",
    private val baseUrl: String = DEFAULT_BASE_URL,
    private val enableLogging: Boolean = false
) {

    companion object {
        const val DEFAULT_BASE_URL = "https://api.elevenlabs.io/"
        const val HEADER_API_KEY = "xi-api-key"
        const val MODEL_MULTILINGUAL_V2 = "eleven_multilingual_v2"
        const val MODEL_TURBO_V2_5 = "eleven_turbo_v2_5"
        const val MODEL_FLASH_V2 = "eleven_flash_v2"
        const val FORMAT_MP3_44100_128 = "mp3_44100_128"
        const val FORMAT_MP3_22050_32 = "mp3_22050_32"
        const val TAG = "ElevenLabsClient"
    }

    private val moshi: Moshi = Moshi.Builder()
        .addLast(KotlinJsonAdapterFactory())
        .build()

    private val authInterceptor = Interceptor { chain ->
        val originalRequest = chain.request()
        val requestBuilder = originalRequest.newBuilder()

        // Attach authentication key header if available
        if (apiKey.isNotBlank()) {
            requestBuilder.header(HEADER_API_KEY, apiKey)
        }

        requestBuilder.header("Accept", "application/json, audio/mpeg")
        chain.proceed(requestBuilder.build())
    }

    private val okHttpClient: OkHttpClient by lazy {
        val builder = OkHttpClient.Builder()
            .addInterceptor(authInterceptor)
            .connectTimeout(30, TimeUnit.SECONDS)
            .readTimeout(60, TimeUnit.SECONDS)
            .writeTimeout(30, TimeUnit.SECONDS)

        if (enableLogging) {
            val logging = HttpLoggingInterceptor { message -> Log.d(TAG, message) }
            logging.level = HttpLoggingInterceptor.Level.HEADERS
            builder.addInterceptor(logging)
        }

        builder.build()
    }

    private val retrofit: Retrofit by lazy {
        Retrofit.Builder()
            .baseUrl(baseUrl)
            .client(okHttpClient)
            .addConverterFactory(MoshiConverterFactory.create(moshi))
            .build()
    }

    val apiService: ElevenLabsApiService by lazy {
        retrofit.create(ElevenLabsApiService::class.java)
    }

    /**
     * Updates the API key used for subsequent requests.
     */
    fun setApiKey(newKey: String) {
        this.apiKey = newKey
    }

    /**
     * Checks if an API key is configured.
     */
    fun hasApiKey(): Boolean = apiKey.isNotBlank()

    /**
     * Generates speech audio bytes from text using the specified voice ID.
     *
     * @param voiceId ElevenLabs voice ID (e.g. cloned voice or library voice)
     * @param text The narration script to synthesize
     * @param modelId Model ID (default: eleven_multilingual_v2)
     * @param voiceSettings Voice fine-tuning settings (stability, similarity_boost, etc.)
     * @param outputFormat Audio format (default: mp3_44100_128)
     * @return Result containing raw MP3 audio ByteArray or Exception
     */
    suspend fun generateSpeech(
        voiceId: String,
        text: String,
        modelId: String = MODEL_MULTILINGUAL_V2,
        voiceSettings: VoiceSettings = VoiceSettings(stability = 0.75f, similarityBoost = 0.85f),
        outputFormat: String = FORMAT_MP3_44100_128
    ): Result<ByteArray> = withContext(Dispatchers.IO) {
        if (text.isBlank()) {
            return@withContext Result.failure(IllegalArgumentException("Narration text cannot be blank."))
        }
        if (voiceId.isBlank()) {
            return@withContext Result.failure(IllegalArgumentException("Voice ID cannot be blank."))
        }

        try {
            val request = ElevenLabsTtsRequest(
                text = text,
                modelId = modelId,
                voiceSettings = voiceSettings
            )

            val response = apiService.textToSpeech(
                voiceId = voiceId,
                request = request,
                outputFormat = outputFormat
            )

            if (response.isSuccessful && response.body() != null) {
                val bytes = response.body()!!.bytes()
                Result.success(bytes)
            } else {
                val errorMsg = parseErrorMessage(response)
                Result.failure(ElevenLabsApiException(response.code(), errorMsg))
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error during ElevenLabs TTS generation", e)
            Result.failure(e)
        }
    }

    /**
     * Synthesizes narration script and writes the MP3 audio directly to a target File.
     * Ideal for caching audio before avatar lip-sync compositing.
     */
    suspend fun generateSpeechToFile(
        voiceId: String,
        text: String,
        destinationFile: File,
        modelId: String = MODEL_MULTILINGUAL_V2,
        voiceSettings: VoiceSettings = VoiceSettings(),
        outputFormat: String = FORMAT_MP3_44100_128
    ): Result<File> = withContext(Dispatchers.IO) {
        val audioBytesResult = generateSpeech(voiceId, text, modelId, voiceSettings, outputFormat)
        audioBytesResult.fold(
            onSuccess = { bytes ->
                try {
                    destinationFile.parentFile?.mkdirs()
                    FileOutputStream(destinationFile).use { fos ->
                        fos.write(bytes)
                    }
                    Result.success(destinationFile)
                } catch (e: Exception) {
                    Result.failure(e)
                }
            },
            onFailure = { error ->
                Result.failure(error)
            }
        )
    }

    /**
     * Fetches all available voices (including custom cloned voices associated with the account).
     */
    suspend fun getVoices(): Result<List<ElevenLabsVoice>> = withContext(Dispatchers.IO) {
        try {
            val response = apiService.getVoices()
            if (response.isSuccessful && response.body() != null) {
                Result.success(response.body()!!.voices)
            } else {
                Result.failure(ElevenLabsApiException(response.code(), parseErrorMessage(response)))
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    /**
     * Fetches details for a specific voice by voice ID.
     */
    suspend fun getVoice(voiceId: String): Result<ElevenLabsVoice> = withContext(Dispatchers.IO) {
        try {
            val response = apiService.getVoice(voiceId)
            if (response.isSuccessful && response.body() != null) {
                Result.success(response.body()!!)
            } else {
                Result.failure(ElevenLabsApiException(response.code(), parseErrorMessage(response)))
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    /**
     * Fetches user subscription details and remaining character quota.
     */
    suspend fun getUserSubscription(): Result<ElevenLabsUserSubscription> = withContext(Dispatchers.IO) {
        try {
            val response = apiService.getUserSubscription()
            if (response.isSuccessful && response.body() != null) {
                Result.success(response.body()!!)
            } else {
                Result.failure(ElevenLabsApiException(response.code(), parseErrorMessage(response)))
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    private fun parseErrorMessage(response: Response<*>): String {
        val errorBody = response.errorBody()?.string() ?: return "HTTP Error ${response.code()}: ${response.message()}"
        return try {
            val adapter = moshi.adapter(ElevenLabsApiError::class.java)
            val parsed = adapter.fromJson(errorBody)
            parsed?.detail?.message ?: "HTTP ${response.code()}: $errorBody"
        } catch (_: Exception) {
            "HTTP ${response.code()}: $errorBody"
        }
    }
}

/**
 * Custom Exception for ElevenLabs API errors with HTTP status code.
 */
class ElevenLabsApiException(
    val statusCode: Int,
    override val message: String
) : Exception("ElevenLabs API Error [$statusCode]: $message")
