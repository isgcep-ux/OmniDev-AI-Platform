package com.example.data.repository

import com.example.data.local.AppDatabase
import com.example.data.local.entity.ChatMessageEntity
import com.example.data.local.entity.CourseProgressEntity
import com.example.data.local.entity.IsgQuizHistoryEntity
import com.example.data.local.entity.SavedPromptEntity
import com.example.data.local.entity.SavedSnippetEntity
import com.example.data.local.entity.TestHistoryEntity
import com.example.model.*
import kotlinx.coroutines.flow.Flow

class DevStudioRepository(private val db: AppDatabase? = null) {

    // Database Flows
    val savedPrompts: Flow<List<SavedPromptEntity>> = db?.promptDao()?.getAllPrompts() ?: kotlinx.coroutines.flow.flowOf(emptyList())
    val chatHistory: Flow<List<ChatMessageEntity>> = db?.chatDao()?.getAllMessages() ?: kotlinx.coroutines.flow.flowOf(emptyList())
    val savedSnippets: Flow<List<SavedSnippetEntity>> = db?.snippetDao()?.getAllSnippets() ?: kotlinx.coroutines.flow.flowOf(emptyList())
    val testHistory: Flow<List<TestHistoryEntity>> = db?.testDao()?.getRecentTestRuns() ?: kotlinx.coroutines.flow.flowOf(emptyList())
    val isgQuizHistory: Flow<List<IsgQuizHistoryEntity>> = db?.isgQuizDao()?.getAllQuizHistory() ?: kotlinx.coroutines.flow.flowOf(emptyList())
    val courseProgressFlow: Flow<List<CourseProgressEntity>> = db?.courseProgressDao()?.getAllProgress() ?: kotlinx.coroutines.flow.flowOf(emptyList())

    suspend fun savePrompt(prompt: SavedPromptEntity) = db?.promptDao()?.insertPrompt(prompt)
    suspend fun deletePrompt(prompt: SavedPromptEntity) = db?.promptDao()?.deletePrompt(prompt)
    suspend fun saveChatMessage(msg: ChatMessageEntity) = db?.chatDao()?.insertMessage(msg)
    suspend fun clearChatHistory() = db?.chatDao()?.clearHistory()
    suspend fun saveSnippet(snippet: SavedSnippetEntity) = db?.snippetDao()?.insertSnippet(snippet)
    suspend fun deleteSnippet(snippet: SavedSnippetEntity) = db?.snippetDao()?.deleteSnippet(snippet)
    suspend fun recordTestRun(testRun: TestHistoryEntity) = db?.testDao()?.insertTestRun(testRun)
    suspend fun saveIsgQuizHistory(history: IsgQuizHistoryEntity) = db?.isgQuizDao()?.insertQuizHistory(history)
    suspend fun deleteIsgQuizHistory(history: IsgQuizHistoryEntity) = db?.isgQuizDao()?.deleteQuizHistory(history)
    suspend fun clearAllIsgQuizHistory() = db?.isgQuizDao()?.clearAllQuizHistory()

    // Course Progress Room Operations
    suspend fun saveCourseProgress(progress: CourseProgressEntity) = db?.courseProgressDao()?.insertOrUpdateProgress(progress)
    suspend fun updateCourseStatus(courseId: String, isCompleted: Boolean, progressPercentage: Int, completedHours: Double) =
        db?.courseProgressDao()?.updateCourseStatus(courseId, isCompleted, progressPercentage, completedHours)
    suspend fun updateSyllabusProgress(courseId: String, progressPercentage: Int, syllabusItems: String, completedHours: Double, isCompleted: Boolean) =
        db?.courseProgressDao()?.updateSyllabusProgress(courseId, progressPercentage, syllabusItems, completedHours, isCompleted)
    suspend fun resetAllCourseProgress() = db?.courseProgressDao()?.resetAllProgress()
    suspend fun getCourseProgress(courseId: String) = db?.courseProgressDao()?.getProgressForCourse(courseId)
    fun observeCourseProgress(courseId: String): Flow<CourseProgressEntity?> = db?.courseProgressDao()?.observeProgressForCourse(courseId) ?: kotlinx.coroutines.flow.flowOf(null)

    // IDX Presets
    fun getFlutterPresets(): List<FlutterPreset> = listOf(
        FlutterPreset(
            id = "flutter_wasm_saas",
            title = "WASM SaaS Dashboard (Riverpod)",
            description = "High-performance Flutter Web application compiled to WebAssembly with Material 3 and Riverpod 2.x state management.",
            stateManagement = "flutter_riverpod",
            renderer = "WASM (WebAssembly)",
            sampleCode = """
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

final counterProvider = StateProvider<int>((ref) => 0);

void main() {
  runApp(const ProviderScope(child: IdxSaaSApp()));
}

class IdxSaaSApp extends ConsumerWidget {
  const IdxSaaSApp({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final count = ref.watch(counterProvider);
    return MaterialApp(
      theme: ThemeData(useMaterial3: true, colorSchemeSeed: Colors.indigo),
      home: Scaffold(
        appBar: AppBar(title: const Text('IDX Flutter Web SaaS')),
        body: Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              const Text('Live WebAssembly Render:'),
              Text('${'$'}count', style: Theme.of(context).textTheme.displayLarge),
              ElevatedButton.icon(
                icon: const Icon(Icons.add_task),
                onPressed: () => ref.read(counterProvider.notifier).state++,
                label: const Text('Increment State'),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
            """.trimIndent(),
            pubspecYaml = """
name: idx_flutter_web
description: Flutter Web application built inside Project IDX
publish_to: 'none'
version: 1.0.0+1

environment:
  sdk: '>=3.3.0 <4.0.0'

dependencies:
  flutter:
    sdk: flutter
  flutter_riverpod: ^2.5.1
  go_router: ^14.2.0
  dio: ^5.4.3+1
  google_fonts: ^6.2.1

dev_dependencies:
  flutter_test:
    sdk: flutter
  flutter_lints: ^4.0.0
            """.trimIndent()
        ),
        FlutterPreset(
            id = "flutter_ecommerce_bloc",
            title = "E-Commerce Catalog (BLoC)",
            description = "Reactive product listing with BLoC architecture, caching, and CanvasKit rendering engine.",
            stateManagement = "flutter_bloc",
            renderer = "CanvasKit",
            sampleCode = """
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

abstract class CatalogEvent {}
class LoadCatalog extends CatalogEvent {}

class CatalogState {
  final List<String> items;
  final bool isLoading;
  CatalogState({required this.items, this.isLoading = false});
}

class CatalogBloc extends Bloc<CatalogEvent, CatalogState> {
  CatalogBloc() : super(CatalogState(items: [])) {
    on<LoadCatalog>((event, emit) async {
      emit(CatalogState(items: state.items, isLoading: true));
      await Future.delayed(const Duration(milliseconds: 500));
      emit(CatalogState(items: ['Pixel 9 Pro', 'Gemini Pro Watch', 'Nest Hub 3']));
    });
  }
}
            """.trimIndent(),
            pubspecYaml = """
name: idx_catalog_bloc
environment:
  sdk: '>=3.3.0 <4.0.0'
dependencies:
  flutter:
    sdk: flutter
  flutter_bloc: ^8.1.5
  equatable: ^2.0.5
  cached_network_image: ^3.3.1
            """.trimIndent()
        ),
        FlutterPreset(
            id = "flutter_ai_assistant",
            title = "Gemini AI Chat Client (StateNotifier)",
            description = "Streaming conversational interface with responsive chat bubbles and markdown syntax highlighting.",
            stateManagement = "StateNotifier",
            renderer = "HTML / Auto",
            sampleCode = """
import 'package:flutter/material.dart';
import 'package:google_generative_ai/google_generative_ai.dart';

class GeminiChatPage extends StatefulWidget {
  const GeminiChatPage({super.key});
  @override
  State<GeminiChatPage> createState() => _GeminiChatPageState();
}

class _GeminiChatPageState extends State<GeminiChatPage> {
  final _model = GenerativeModel(model: 'gemini-3.5-flash', apiKey: 'API_KEY');
  final _messages = <String>['Welcome to IDX DevStudio Chat!'];

  void _sendMessage(String text) async {
    final response = await _model.generateContent([Content.text(text)]);
    setState(() => _messages.add(response.text ?? 'No reply'));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Gemini Assistant')),
      body: ListView.builder(
        itemCount: _messages.length,
        itemBuilder: (context, i) => ListTile(title: Text(_messages[i])),
      ),
    );
  }
}
            """.trimIndent(),
            pubspecYaml = """
name: idx_gemini_chat
dependencies:
  flutter:
    sdk: flutter
  google_generative_ai: ^0.4.6
  flutter_markdown: ^0.7.3
            """.trimIndent()
        )
    )

    fun getNextJsRoutes(): List<NextJsRoute> = listOf(
        NextJsRoute(
            path = "app/dashboard/page.tsx",
            type = "Server Component",
            renderStrategy = "SSR (Server-Side Rendering)",
            codeSnippet = """
import { Suspense } from 'react';
import { AnalyticsCard } from '@/components/analytics';
import { db } from '@/lib/db';

export const dynamic = 'force-dynamic';

export default async function DashboardPage() {
  const metrics = await db.metrics.findMany();
  
  return (
    <main className="p-8 max-w-7xl mx-auto space-y-6">
      <h1 className="text-3xl font-bold tracking-tight text-slate-900 dark:text-white">
        Project IDX Workspace Metrics
      </h1>
      <Suspense fallback={<p className="text-slate-500">Streaming live data...</p>}>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {metrics.map(m => <AnalyticsCard key={m.id} data={m} />)}
        </div>
      </Suspense>
    </main>
  );
}
            """.trimIndent()
        ),
        NextJsRoute(
            path = "app/actions/gemini-action.ts",
            type = "Server Action",
            renderStrategy = "Server Action (POST)",
            codeSnippet = """
'use server';

import { GoogleGenerativeAI } from '@google/generative-ai';
import { revalidatePath } from 'next/cache';

const genAI = new GoogleGenerativeAI(process.env.GEMINI_API_KEY!);

export async function summarizeCode(formData: FormData) {
  const codeSnippet = formData.get('code') as string;
  const model = genAI.getGenerativeModel({ model: 'gemini-3.5-flash' });
  
  const result = await model.generateContent([
    'Analyze this code and provide a concise summary with optimization tips:',
    codeSnippet
  ]);

  revalidatePath('/dashboard');
  return { summary: result.response.text() };
}
            """.trimIndent()
        ),
        NextJsRoute(
            path = "app/api/deploy/route.ts",
            type = "API Route",
            renderStrategy = "Dynamic Edge API",
            codeSnippet = """
import { NextResponse } from 'next/server';

export async function POST(req: Request) {
  const { branch, environment } = await req.json();
  
  // Trigger Cloud Build / Cloud Run Pipeline
  const deployJob = await fetch('https://cloudbuild.googleapis.com/v1/projects/idx-demo/builds', {
    method: 'POST',
    headers: { 'Authorization': `Bearer ${'$'}{process.env.GCP_ACCESS_TOKEN}` },
    body: JSON.stringify({ source: { repoSource: { branchName: branch } } })
  });

  return NextResponse.json({ status: 'DEPLOYING', buildId: 'build_9281a', env: environment });
}
            """.trimIndent()
        ),
        NextJsRoute(
            path = "app/settings/client-panel.tsx",
            type = "Client Component",
            renderStrategy = "Client Interactive (useState / useTransition)",
            codeSnippet = """
'use client';

import { useState, useTransition } from 'react';
import { Button } from '@/components/ui/button';

export function SettingsPanel() {
  const [isPending, startTransition] = useTransition();
  const [theme, setTheme] = useState<'dark' | 'light'>('dark');

  return (
    <div className="rounded-xl border border-slate-700 p-6 bg-slate-900/50">
      <h3 className="font-semibold text-lg text-white">Workspace Preferences</h3>
      <Button 
        disabled={isPending}
        onClick={() => startTransition(() => setTheme(t => t === 'dark' ? 'light' : 'dark'))}
        className="mt-4"
      >
        Toggle Theme ({theme})
      </Button>
    </div>
  );
}
            """.trimIndent()
        )
    )

    fun getFirebaseSecurityTests(): List<FirebaseRuleTest> = listOf(
        FirebaseRuleTest(
            name = "Read Public Posts",
            path = "/databases/(default)/documents/posts/p1",
            authRole = "unauthenticated",
            operation = "read",
            allowed = true,
            explanation = "match /posts/{postId} { allow read: if true; }"
        ),
        FirebaseRuleTest(
            name = "Update Profile by Owner",
            path = "/databases/(default)/documents/users/user_123",
            authRole = "authenticated (uid: user_123)",
            operation = "write",
            allowed = true,
            explanation = "match /users/{userId} { allow write: if request.auth.uid == userId; }"
        ),
        FirebaseRuleTest(
            name = "Delete Other User's Account",
            path = "/databases/(default)/documents/users/user_456",
            authRole = "authenticated (uid: user_123)",
            operation = "delete",
            allowed = false,
            explanation = "Permission denied: request.auth.uid (user_123) != user_456"
        ),
        FirebaseRuleTest(
            name = "Admin Secret Config Access",
            path = "/databases/(default)/documents/system/secrets",
            authRole = "admin (custom claim: admin=true)",
            operation = "read",
            allowed = true,
            explanation = "allow read, write: if request.auth.token.admin == true;"
        )
    )

    fun getDatabaseSchemas(): List<DbTableSchema> = listOf(
        DbTableSchema(
            tableName = "idx_projects",
            columns = listOf(
                DbColumn("id", "VARCHAR(36)", isPrimary = true),
                DbColumn("name", "VARCHAR(255)"),
                DbColumn("template", "VARCHAR(50)"),
                DbColumn("created_at", "TIMESTAMP"),
                DbColumn("status", "VARCHAR(20)")
            ),
            sampleRows = listOf(
                mapOf("id" to "p-101", "name" to "ShopFast Flutter Web", "template" to "flutter_wasm", "created_at" to "2026-08-20 10:14:00", "status" to "ACTIVE"),
                mapOf("id" to "p-102", "name" to "CloudPulse Next.js", "template" to "nextjs_15_app", "created_at" to "2026-08-22 14:30:22", "status" to "DEPLOYED"),
                mapOf("id" to "p-103", "name" to "Gemini Vision Tutor", "template" to "ai_studio_starter", "created_at" to "2026-08-24 09:05:41", "status" to "BUILDING")
            )
        ),
        DbTableSchema(
            tableName = "gemini_prompt_runs",
            columns = listOf(
                DbColumn("run_id", "BIGINT AUTO_INCREMENT", isPrimary = true),
                DbColumn("model_name", "VARCHAR(100)"),
                DbColumn("tokens_in", "INT"),
                DbColumn("tokens_out", "INT"),
                DbColumn("latency_ms", "INT"),
                DbColumn("success", "BOOLEAN")
            ),
            sampleRows = listOf(
                mapOf("run_id" to "1", "model_name" to "gemini-3.5-flash", "tokens_in" to "412", "tokens_out" to "280", "latency_ms" to "380", "success" to "true"),
                mapOf("run_id" to "2", "model_name" to "gemini-3.1-pro-preview", "tokens_in" to "1280", "tokens_out" to "850", "latency_ms" to "920", "success" to "true"),
                mapOf("run_id" to "3", "model_name" to "gemini-3.1-flash-lite-preview", "tokens_in" to "150", "tokens_out" to "90", "latency_ms" to "140", "success" to "true")
            )
        )
    )

    fun getInitialTestCases(): List<TestCase> = listOf(
        TestCase("t1", "Flutter Widget: Counter Increments State on Tap", "Flutter Web Suite", "Flutter", TestStatus.PASSED, 142),
        TestCase("t2", "Flutter Web: CanvasKit vs WASM Rendering Pipeline", "Flutter Web Suite", "Flutter", TestStatus.PASSED, 280),
        TestCase("t3", "Next.js: Server Action Code Summary Auth Check", "Next.js Vitest", "Jest/Next.js", TestStatus.PASSED, 88),
        TestCase("t4", "Next.js: App Router Dynamic SSR Route Generation", "Next.js Vitest", "Jest/Next.js", TestStatus.PASSED, 195),
        TestCase("t5", "Firebase: Firestore Security Rules Denial for Impersonator", "Firebase Emulators", "Firebase Emulators", TestStatus.PASSED, 64),
        TestCase("t6", "Firebase: Cloud Storage Upload Bucket CORS policy", "Firebase Emulators", "Firebase Emulators", TestStatus.PASSED, 110),
        TestCase("t7", "AI Studio: Gemini Structured JSON Schema Validator", "AI Studio Suite", "Gemini API", TestStatus.PASSED, 320),
        TestCase("t8", "Gemini: Polyglot SDK Serialization Compliance", "AI Studio Suite", "Gemini API", TestStatus.PASSED, 95)
    )

    fun getDeploymentTargets(): List<DeploymentTarget> = listOf(
        DeploymentTarget(
            id = "firebase_hosting",
            name = "Firebase Web Hosting (Flutter + Next.js)",
            provider = "Google Firebase",
            url = "https://idx-devstudio.web.app",
            status = "HEALTHY (Global CDN)",
            lastDeployTime = "2 mins ago",
            buildSteps = listOf("Flutter build web --wasm", "Next.js export", "firebase deploy --only hosting")
        ),
        DeploymentTarget(
            id = "cloud_run",
            name = "Google Cloud Run (Serverless Next.js SSR & API)",
            provider = "Google Cloud Platform",
            url = "https://idx-backend-cr-xr5db.run.app",
            status = "SERVING (Autoscale 0-10)",
            lastDeployTime = "12 mins ago",
            buildSteps = listOf("Docker build --target runner", "gcr.io push", "gcloud run deploy --region europe-west2")
        ),
        DeploymentTarget(
            id = "vercel_edge",
            name = "Vercel Edge Platform",
            provider = "Vercel",
            url = "https://idx-workspace.vercel.app",
            status = "DEPLOYED",
            lastDeployTime = "1 hour ago",
            buildSteps = listOf("vercel build --prod", "Deploying edge middleware")
        )
    )

    fun getGeminiModels(): List<GeminiModelSpec> = listOf(
        GeminiModelSpec(
            modelId = "gemini-3.5-flash",
            displayName = "Gemini 3.5 Flash",
            badge = "RECOMMENDED DEFAULT",
            contextWindow = "1,048,576 tokens",
            bestFor = "Fast text generation, Q&A, chat assistants, high throughput, and general tasks.",
            latencyMs = 280,
            inputCostPerMillion = "$0.075",
            outputCostPerMillion = "$0.30",
            capabilities = listOf("Text Generation", "Multimodal", "Structured JSON", "Function Calling", "Streaming")
        ),
        GeminiModelSpec(
            modelId = "gemini-3.1-pro-preview",
            displayName = "Gemini 3.1 Pro (Preview)",
            badge = "ADVANCED REASONING",
            contextWindow = "2,097,152 tokens",
            bestFor = "Complex STEM reasoning, deep code architecture analysis, multi-file refactoring, mathematics.",
            latencyMs = 750,
            inputCostPerMillion = "$1.25",
            outputCostPerMillion = "$5.00",
            capabilities = listOf("Complex Code Analysis", "Deep Reasoning", "Math & Logic", "Extended Context (2M)")
        ),
        GeminiModelSpec(
            modelId = "gemini-3.1-flash-lite-preview",
            displayName = "Gemini 3.1 Flash Lite",
            badge = "ULTRA FAST & LIGHT",
            contextWindow = "1,048,576 tokens",
            bestFor = "Real-time autocomplete, microservices, classification, sentiment, token-efficient pipelines.",
            latencyMs = 120,
            inputCostPerMillion = "$0.0375",
            outputCostPerMillion = "$0.15",
            capabilities = listOf("Ultra-low Latency", "Batch Processing", "Edge-optimized", "High QPS")
        ),
        GeminiModelSpec(
            modelId = "gemini-2.5-flash-native-audio-preview-12-2025",
            displayName = "Gemini 2.5 Flash Native Audio",
            badge = "MULTIMODAL AUDIO",
            contextWindow = "524,288 tokens",
            bestFor = "Real-time bi-directional voice chat, speech transcription, low-latency audio interaction.",
            latencyMs = 190,
            inputCostPerMillion = "$0.10",
            outputCostPerMillion = "$0.40",
            capabilities = listOf("Native Audio In/Out", "Voice Synthesis", "Live Dialogue", "Speech Translation")
        )
    )

    fun getPromptTemplates(): List<PromptTemplate> = listOf(
        PromptTemplate(
            id = "p1",
            title = "Flutter to Compose Converter",
            category = "Cross-Platform Migration",
            systemInstruction = "You are a master Android & Flutter architect. Convert Dart/Flutter widget trees into idiomatic, modern Jetpack Compose Kotlin code using Material 3.",
            userPrompt = "Convert this Flutter StatefulWidget with an AnimatedContainer and FloatingActionButton into Jetpack Compose with remember and AnimatedVisibility.",
            expectedOutputFormat = "Kotlin Jetpack Compose code with brief structural diff notes."
        ),
        PromptTemplate(
            id = "p2",
            title = "Next.js Server Actions & Firestore",
            category = "Backend Integration",
            systemInstruction = "You are a cloud architect specializing in Next.js App Router and Firebase Firestore. Write type-safe, authenticated server actions.",
            userPrompt = "Generate a Next.js 15 Server Action that validates a zod schema, checks Firebase Auth ID token, and writes an order record to Firestore.",
            expectedOutputFormat = "TypeScript with zod validation, error handling, and revalidatePath()."
        ),
        PromptTemplate(
            id = "p3",
            title = "Structured JSON Schema for E-Commerce",
            category = "Structured Output",
            systemInstruction = "You are a data API engine. Always return strictly valid JSON matching the requested schema without markdown wrapper blocks.",
            userPrompt = "Extract product name, price, stockStatus (IN_STOCK, LOW, OUT), and tags list from this unstructured vendor email.",
            expectedOutputFormat = "{ \"type\": \"OBJECT\", \"properties\": { \"products\": { \"type\": \"ARRAY\" } } }"
        ),
        PromptTemplate(
            id = "p4",
            title = "CI/CD Deployment Optimizer",
            category = "DevOps & Cloud",
            systemInstruction = "You are a Google Cloud Platform and GitHub Actions specialist. Optimize build caches, Docker multi-stage builds, and deployment manifests.",
            userPrompt = "Provide a production-ready cloudbuild.yaml that builds a Flutter WASM web app and deploys to Firebase Hosting with CDN cache headers.",
            expectedOutputFormat = "YAML manifest with step comments and caching directives."
        )
    )

    fun getQuizQuestions(): List<QuizQuestion> = listOf(
        QuizQuestion(
            id = "q1",
            stack = "Flutter",
            difficulty = "Intermediate",
            question = "Which Flutter Web rendering mode produces the most compact binary and near-native CPU execution on modern browsers supporting WasmGC?",
            options = listOf(
                "HTML Renderer with DOM elements",
                "CanvasKit with WebGL 2",
                "WebAssembly (WASM) with WasmGC",
                "Skia CPU Fallback"
            ),
            correctIndex = 2,
            explanation = "Flutter's WebAssembly (WasmGC) compilation compiles Dart directly into Wasm bytecode, executing significantly faster with lower memory overhead compared to CanvasKit or HTML renderers."
        ),
        QuizQuestion(
            id = "q2",
            stack = "Next.js",
            difficulty = "Senior",
            question = "In Next.js App Router, how does a Server Action run when triggered from a Client Component button click?",
            options = listOf(
                "It executes inside the client's browser web worker",
                "It sends an encrypted POST request to the server endpoint with serialized arguments",
                "It compiles to WebAssembly on the client side",
                "It opens a WebSocket subscription to localhost"
            ),
            correctIndex = 1,
            explanation = "Next.js Server Actions are compiled into secure RPC endpoints invoked via an HTTP POST request, keeping database connections and private secrets strictly on the server."
        ),
        QuizQuestion(
            id = "q3",
            stack = "Firebase",
            difficulty = "Intermediate",
            question = "In Firebase Security Rules, which token variable checks if the user is authenticated via Google Identity Services?",
            options = listOf(
                "request.auth.token.firebase.sign_in_provider == 'google.com'",
                "request.identity.provider == 'google'",
                "auth.isGoogle == true",
                "resource.data.google_auth == true"
            ),
            correctIndex = 0,
            explanation = "Firebase Auth encodes provider information in `request.auth.token.firebase.sign_in_provider`, which equals `'google.com'` for Google Sign-In."
        ),
        QuizQuestion(
            id = "q4",
            stack = "Gemini",
            difficulty = "Architect",
            question = "When requesting structured JSON from Gemini API via REST, what parameter must be specified in GenerationConfig?",
            options = listOf(
                "header: 'Content-Type: application/json'",
                "responseFormat with responseMimeType = 'application/json' (and optional schema)",
                "prompt suffix: 'Please return valid JSON only'",
                "model parameter: 'json_mode=1'"
            ),
            correctIndex = 1,
            explanation = "Gemini API supports native structured outputs by providing `responseMimeType: 'application/json'` and an optional JSON Schema inside `GenerationConfig.responseFormat`."
        ),
        QuizQuestion(
            id = "q5",
            stack = "Database",
            difficulty = "Junior",
            question = "What is the primary difference between Room on Android and Cloud Firestore?",
            options = listOf(
                "Room is an on-device local SQLite ORM, while Firestore is a cloud-hosted NoSQL document database with real-time sync",
                "Room only works in web browsers, while Firestore is for Android only",
                "Room requires a monthly GCP subscription",
                "Firestore stores data only in RAM memory"
            ),
            correctIndex = 0,
            explanation = "Room is an Android Jetpack persistence library providing an abstraction layer over SQLite for on-device local caching, while Cloud Firestore is a cloud NoSQL document store."
        )
    )

    fun getSdkSnippets(): List<SdkSnippet> = listOf(
        SdkSnippet(
            language = "Kotlin (Android Compose)",
            extension = ".kt",
            title = "Retrofit + OkHttp Gemini REST Client",
            code = """
// Android Kotlin Retrofit Client for Gemini API
val request = GenerateContentRequest(
    contents = listOf(Content(parts = listOf(Part(text = "Explain Project IDX architecture")))),
    generationConfig = GenerationConfig(
        temperature = 0.7f,
        responseModalities = listOf("TEXT")
    )
)

val response = RetrofitClient.service.generateContent(
    apiKey = BuildConfig.GEMINI_API_KEY,
    request = request
)
val reply = response.candidates.firstOrNull()?.content?.parts?.firstOrNull()?.text
            """.trimIndent()
        ),
        SdkSnippet(
            language = "Dart (Flutter)",
            extension = ".dart",
            title = "Google Generative AI Dart Package",
            code = """
import 'package:google_generative_ai/google_generative_ai.dart';

final apiKey = const String.fromEnvironment('GEMINI_API_KEY');
final model = GenerativeModel(
  model: 'gemini-3.5-flash',
  apiKey: apiKey,
  generationConfig: GenerationConfig(
    temperature: 0.7,
    maxOutputTokens: 1000,
  ),
);

final content = [Content.text('Build a responsive Flutter Web navigation bar')];
final response = await model.generateContent(content);
print(response.text);
            """.trimIndent()
        ),
        SdkSnippet(
            language = "TypeScript (Next.js 15)",
            extension = ".ts",
            title = "@google/generative-ai Node/Server Actions",
            code = """
import { GoogleGenerativeAI, SchemaType } from '@google/generative-ai';

const genAI = new GoogleGenerativeAI(process.env.GEMINI_API_KEY!);

export async function generateCodeReview(diff: string) {
  const model = genAI.getGenerativeModel({
    model: 'gemini-3.5-flash',
    systemInstruction: 'You are a senior staff software engineer.',
    generationConfig: {
      responseMimeType: 'application/json',
      responseSchema: {
        type: SchemaType.OBJECT,
        properties: {
          score: { type: SchemaType.NUMBER },
          improvements: { type: SchemaType.ARRAY, items: { type: SchemaType.STRING } }
        },
        required: ['score', 'improvements']
      }
    }
  });

  const result = await model.generateContent(diff);
  return JSON.parse(result.response.text());
}
            """.trimIndent()
        ),
        SdkSnippet(
            language = "Python",
            extension = ".py",
            title = "google-genai Python SDK",
            code = """
from google import genai
from google.genai import types
import os

client = genai.Client(api_key=os.environ.get("GEMINI_API_KEY"))

response = client.models.generate_content(
    model="gemini-3.5-flash",
    contents="Generate automated unit test suites for Firebase Cloud Functions.",
    config=types.GenerateContentConfig(
        temperature=0.4,
        top_p=0.95
    )
)
print(response.text)
            """.trimIndent()
        ),
        SdkSnippet(
            language = "cURL / REST",
            extension = ".sh",
            title = "Direct HTTP REST API POST",
            code = """
curl -X POST "https://generativelanguage.googleapis.com/v1beta/models/gemini-3.5-flash:generateContent?key=${'$'}GEMINI_API_KEY" \
-H "Content-Type: application/json" \
-d '{
  "contents": [{
    "parts": [{"text": "Summarize key features of Project IDX for web developers"}]
  }],
  "generationConfig": {
    "temperature": 0.7,
    "maxOutputTokens": 800
  }
}'
            """.trimIndent()
        )
    )

    // ==========================================
    // İSG CEP AKADEMİ EXTENSIONS & INTEGRATIONS
    // Domains: isgcepakademi.com, isgcepakademi.com.tr & isgcepakademi.xyz
    // ==========================================

    fun getIsgPlugins(): List<IsgPlugin> = listOf(
        IsgPlugin(
            id = "isg_global_academy_plugin",
            title = "İSG Cep Akademi Global & Sertifikasyon Portalı",
            description = "isgcepakademi.com ana portalı üzerinden uluslararası İSG sertifikasyonları (NEBOSH, IOSH, OSHA), online eğitimler ve sertifika doğrulama eklentisi.",
            domain = "isgcepakademi.com",
            version = "5.0.1",
            author = "İSG Cep Akademi Global Team",
            category = "Eğitim & Global",
            isInstalled = true,
            rating = 4.96,
            downloads = "54.8K",
            features = listOf(
                "NEBOSH IGC ve OSHA 30 saatlik müfredat entegrasyonu",
                "QR kodlu resmi sertifika sorgulama ve doğrulama motoru",
                "Canlı interaktif webinar ve seminer ajandası",
                "Çok dilli (Türkçe, İngilizce) İSG terimler sözlüğü"
            ),
            manifestJson = """
{
  "name": "İSG Cep Akademi Global Portalı",
  "version": "5.0.1",
  "domain_origin": "https://isgcepakademi.com",
  "permissions": ["storage", "notifications", "webRequest"],
  "api_endpoint": "https://api.isgcepakademi.com/v1/global-academy",
  "features": ["cert_verification", "webinar_sync", "osha_nebosh_catalog"]
}
            """.trimIndent(),
            apiEndpoints = listOf("GET /api/v1/academy/cert-verify", "GET /api/v1/academy/courses", "POST /api/v1/academy/webinar-register"),
            docsUrl = "https://isgcepakademi.com/developer/docs"
        ),
        IsgPlugin(
            id = "isg_mevzuat_plugin",
            title = "İSG Mevzuat & 6331 Kanun Asistanı",
            description = "6331 Sayılı İSG Kanunu, 4857 Sayılı İş Kanunu ve 120+ alt yönetmeliği anlık arayan, maddeleri özetleyen ve cezai yaptırımları listeleyen eklenti.",
            domain = "isgcepakademi.com.tr",
            version = "3.2.0",
            author = "İSG Cep Akademi Core Team",
            category = "Mevzuat",
            isInstalled = true,
            rating = 4.9,
            downloads = "48.2K",
            features = listOf(
                "6331 ve 4857 Sayılı Kanun madde indeksleme",
                "Yönetmelik değişiklikleri ve Resmi Gazete bildirimleri",
                "İdari para cezaları (İPC) otomatik katsayı hesaplama",
                "Madde bazlı arama ve AI mevzuat yorumlama"
            ),
            manifestJson = """
{
  "name": "İSG Cep Akademi Mevzuat Motoru",
  "version": "3.2.0",
  "domain_origin": "https://isgcepakademi.com.tr",
  "permissions": ["storage", "activeTab", "webRequest"],
  "api_endpoint": "https://api.isgcepakademi.com.tr/v1/legislation",
  "offline_sync": true
}
            """.trimIndent(),
            apiEndpoints = listOf("GET /api/v1/mevzuat/search", "GET /api/v1/mevzuat/ipc-hesapla", "POST /api/v1/mevzuat/analiz"),
            docsUrl = "https://isgcepakademi.com.tr/dokumanlar/mevzuat-eklentisi"
        ),
        IsgPlugin(
            id = "isg_risk_engine_plugin",
            title = "Fine-Kinney & 5x5 L Matris Risk Motoru",
            description = "İşyerlerindeki tehlikeleri Fine-Kinney (Risk = İhtimal x Şiddet x Frekans) ve 5x5 Matris yöntemleriyle puanlayıp DÖF (Düzeltici Önleyici Faaliyet) raporu üreten eklenti.",
            domain = "isgcepakademi.xyz",
            version = "2.8.4",
            author = "İSG Cep Akademi Analytics",
            category = "Risk Analizi",
            isInstalled = true,
            rating = 4.95,
            downloads = "39.1K",
            features = listOf(
                "Fine-Kinney 3 faktörlü dinamik hesaplayıcı",
                "5x5 L Tipi Matris olasılık & şiddet tablosu",
                "Otomatik risk derecelendirmesi (Tolerans Edilemez / Kabul Edilebilir)",
                "DÖF (Düzeltici Önleyici Faaliyet) ve termin tarihi atama"
            ),
            manifestJson = """
{
  "name": "İSG Cep Akademi Risk Engine",
  "version": "2.8.4",
  "domain_origin": "https://isgcepakademi.xyz",
  "algorithms": ["fine_kinney", "matrix_5x5", "fmea_lite"],
  "api_endpoint": "https://engine.isgcepakademi.xyz/api/v2/risk-evaluate",
  "export_formats": ["PDF", "XLSX", "JSON"]
}
            """.trimIndent(),
            apiEndpoints = listOf("POST /api/v2/risk/calculate", "GET /api/v2/risk/matrix-table", "POST /api/v2/risk/export-report"),
            docsUrl = "https://isgcepakademi.xyz/docs/risk-matrix"
        ),
        IsgPlugin(
            id = "isg_exam_sim_plugin",
            title = "İSG Sınav Soru Bankası & Deneme Çözücü",
            description = "ÖSYM İSG Sınavları (A, B, C Sınıfı İGU, İşyeri Hekimliği, DSP) için çıkmış sorular, denemeler, konu tekrarları ve çözümlü soru bankası eklentisi.",
            domain = "isgcepakademi.com.tr",
            version = "4.1.0",
            author = "İSG Akademi Eğitim Kurulu",
            category = "Sınav & Eğitim",
            isInstalled = true,
            rating = 4.98,
            downloads = "62.7K",
            features = listOf(
                "50 soruluk tam formatlı ÖSYM deneme modülü",
                "A, B, C Sınıfı Uzmanlık, İH ve DSP ayrımı",
                "Her soru için ayrıntılı mevzuat dayanağı ve çözüm analizi",
                "Başarı yüzdesi ve zayıf konu tespiti"
            ),
            manifestJson = """
{
  "name": "İSG Sınav Pro Eklentisi",
  "version": "4.1.0",
  "domain_origin": "https://isgcepakademi.com.tr",
  "exam_types": ["A_SINIFI", "B_SINIFI", "C_SINIFI", "ISYERI_HEKIMLIGI", "DSP"],
  "api_endpoint": "https://sinav.isgcepakademi.com.tr/v1/soru-bankasi",
  "interactive_quiz": true
}
            """.trimIndent(),
            apiEndpoints = listOf("GET /api/v1/sorular/deneme", "POST /api/v1/sorular/degerlendir", "GET /api/v1/konu-analizi"),
            docsUrl = "https://isgcepakademi.com.tr/sinav-merkezi"
        ),
        IsgPlugin(
            id = "isg_katip_sync_plugin",
            title = "İSG-KÂTİP & Hizmet Süresi Hesaplayıcı",
            description = "Tehlike sınıfı (Az Tehlikeli, Tehlikeli, Çok Tehlikeli) ve çalışan sayısına göre aylık İGU, İşyeri Hekimi ve DSP zorunlu çalışma dakikalarını hesaplayan eklenti.",
            domain = "isgcepakademi.com.tr",
            version = "2.4.1",
            author = "İSG Cep Akademi Entegrasyon",
            category = "Kâtip & Atama",
            isInstalled = true,
            rating = 4.87,
            downloads = "31.5K",
            features = listOf(
                "Az Tehlikeli (10 dk), Tehlikeli (20 dk), Çok Tehlikeli (40 dk) kişi başı süre",
                "İşyeri hekimi (5, 10, 15 dk) ve DSP (10, 15, 20 dk) hesaplama",
                "Tam zamanlı uzman ve hekim istihdam eşik uyarıları",
                "İSG-KÂTİP sözleşme onay takvimi ve e-imza bildirimleri"
            ),
            manifestJson = """
{
  "name": "İSG-KÂTİP Hesaplayıcı Eklentisi",
  "version": "2.4.1",
  "domain_origin": "https://isgcepakademi.com.tr",
  "api_endpoint": "https://api.isgcepakademi.com.tr/v1/katip-calc",
  "standards": ["6331_Madde_8", "ISG_Hizmetleri_Yonetmeligi"]
}
            """.trimIndent(),
            apiEndpoints = listOf("POST /api/v1/katip/sure-hesapla", "POST /api/v1/katip/sozlesme-kontrol"),
            docsUrl = "https://isgcepakademi.com.tr/katip-rehberi"
        ),
        IsgPlugin(
            id = "isg_ai_incident_plugin",
            title = "Ramak Kala & Kaza Kök Neden Analizörü (AI)",
            description = "İş kazası ve ramak kala (near-miss) olaylarını 5 Neden (5 Whys), Balık Kılçığı (Ishikawa) ve Gemini 3.5 Flash ile analiz edip önlem öneren eklenti.",
            domain = "isgcepakademi.xyz",
            version = "1.9.5",
            author = "İSG AI Araştırma Lab",
            category = "Raporlama & AI",
            isInstalled = true,
            rating = 4.92,
            downloads = "21.9K",
            features = listOf(
                "Gemini destekli olay kök neden sentezi",
                "5 Neden ve İshikawa Balık Kılçığı otomatik diyagramı",
                "Kaza sıklık ve ağırlık oranı (KSO, KAO) istatistikleri",
                "Sosyal Güvenlik Kurumu (SGK) 3 iş günü bildirim kontrolörü"
            ),
            manifestJson = """
{
  "name": "İSG AI Olay Analizörü",
  "version": "1.9.5",
  "domain_origin": "https://isgcepakademi.xyz",
  "ai_backend": "gemini-3.5-flash",
  "api_endpoint": "https://ai.isgcepakademi.xyz/api/v1/incident-root-cause"
}
            """.trimIndent(),
            apiEndpoints = listOf("POST /api/v1/olay/kok-neden", "POST /api/v1/olay/ramak-kala-rapor"),
            docsUrl = "https://isgcepakademi.xyz/ai-asistan"
        ),
        IsgPlugin(
            id = "isg_kkd_periyodik_plugin",
            title = "KKD Matrisi & Periyodik Kontrol Takipçisi",
            description = "Tehlike tipine göre EN/CE standartlı Kişisel Koruyucu Donanım eşleştirmesi, basınçlı kaplar ve kaldırma araçlarının periyodik muayene takvimi.",
            domain = "isgcepakademi.com.tr",
            version = "2.1.0",
            author = "İSG Cep Akademi Teknik",
            category = "Ekipman & KKD",
            isInstalled = true,
            rating = 4.88,
            downloads = "28.3K",
            features = listOf(
                "EN 397 Baret, EN 388 Eldiven, EN ISO 20345 Ayakkabı standart kütüphanesi",
                "Vinç, forklift, kompresör, kazan yıllık periyodik kontrol sayaçları",
                "Yetkili muayene personeli (EKİPNET) kayıt doğrulaması",
                "Zimmet ve KKD teslim tutanağı PDF çıktısı"
            ),
            manifestJson = """
{
  "name": "KKD & Muayene Takip Eklentisi",
  "version": "2.1.0",
  "domain_origin": "https://isgcepakademi.com.tr",
  "api_endpoint": "https://api.isgcepakademi.com.tr/v1/equipment-checks"
}
            """.trimIndent(),
            apiEndpoints = listOf("GET /api/v1/kkd/standartlar", "POST /api/v1/periyodik/hatirlatici"),
            docsUrl = "https://isgcepakademi.com.tr/kkd-rehberi"
        )
    )

    fun getIsgExamQuestions(): List<IsgExamQuestion> = listOf(
        IsgExamQuestion(
            id = "isg_q1",
            examType = "C Sınıfı İGU",
            topic = "6331 Sayılı Kanun & Temel Prensipler",
            question = "6331 Sayılı İş Sağlığı ve Güvenliği Kanunu'na göre, işyerinde meydana gelen iş kazalarının Sosyal Güvenlik Kurumu'na (SGK) bildirim süresi ne kadardır?",
            options = listOf(
                "Kazadan sonraki 3 iş günü içinde",
                "Kazanın olduğu gün derhal",
                "Kazadan sonraki 24 saat içinde",
                "Kazadan sonraki ilk ayın sonuna kadar"
            ),
            correctIndex = 0,
            explanation = "6331 Sayılı İSG Kanunu Madde 14 uyarınca; işveren iş kazalarını kazadan sonraki 3 İŞ GÜNÜ içinde Sosyal Güvenlik Kurumuna bildirmekle yükümlüdür.",
            legislationReference = "6331 Sayılı Kanun Madde 14/2-a"
        ),
        IsgExamQuestion(
            id = "isg_q2",
            examType = "B Sınıfı İGU",
            topic = "Risk Değerlendirmesi Yönetmeliği",
            question = "İş Sağlığı ve Güvenliği Risk Değerlendirmesi Yönetmeliği'ne göre; Çok Tehlikeli, Tehlikeli ve Az Tehlikeli sınıftaki işyerlerinde risk değerlendirmesi en geç kaç yılda bir yenilenir?",
            options = listOf(
                "Çok Tehlikeli: 2 yıl, Tehlikeli: 4 yıl, Az Tehlikeli: 6 yıl",
                "Çok Tehlikeli: 1 yıl, Tehlikeli: 2 yıl, Az Tehlikeli: 3 yıl",
                "Çok Tehlikeli: 3 yıl, Tehlikeli: 5 yıl, Az Tehlikeli: 7 yıl",
                "Tüm tehlike sınıflarında her yıl"
            ),
            correctIndex = 0,
            explanation = "İlgili yönetmelik Madde 12 uyarınca yenileme periyotları: Çok Tehlikeli sınıfta en geç 2 yılda bir, Tehlikeli sınıfta en geç 4 yılda bir, Az Tehlikeli sınıfta en geç 6 yılda birdir.",
            legislationReference = "İSG Risk Değerlendirmesi Yönetmeliği Madde 12"
        ),
        IsgExamQuestion(
            id = "isg_q3",
            examType = "A Sınıfı İGU",
            topic = "Binaların Yangından Korunması",
            question = "Binaların Yangından Korunması Hakkında Yönetmelik gereğince, acil çıkış kapılarının açılış yönü ve kilit mekanizması nasıl olmalıdır?",
            options = listOf(
                "Kaçış yönüne doğru dışarıya açılmalı, kilitli olmamalı veya panik bar ile kolayca açılmalıdır",
                "İçeriye doğru açılmalı ve yangın anında anahtarla açılmalıdır",
                "Döner kapı veya kayar kapı şeklinde olmalıdır",
                "Sadece iş güvenliği uzmanının onayından sonra açılabilir olmalıdır"
            ),
            correctIndex = 0,
            explanation = "Kaçış merdivenleri ve acil çıkış kapıları kesinlikle kaçış yönüne doğru açılmalı, kilitlenmemeli ve panik bar tipi mekanizmaya sahip olmalıdır.",
            legislationReference = "Binaların Yangından Korunması Hakkında Yönetmelik Madde 47"
        ),
        IsgExamQuestion(
            id = "isg_q4",
            examType = "İşyeri Hekimliği",
            topic = "Meslek Hastalıkları & Sağlık Gözetimi",
            question = "İşyerinde çalışanların periyodik sağlık muayeneleri; Çok Tehlikeli, Tehlikeli ve Az Tehlikeli işyerlerinde en geç hangi sıklıkla yapılmalıdır?",
            options = listOf(
                "Çok Tehlikeli: En geç yılda 1, Tehlikeli: En geç 3 yılda 1, Az Tehlikeli: En geç 5 yılda 1",
                "Çok Tehlikeli: 6 ayda 1, Tehlikeli: 1 yılda 1, Az Tehlikeli: 2 yılda 1",
                "Tüm tehlike sınıflarında 2 yılda 1",
                "Sadece işe girişte yapılır, periyodik muayene zorunlu değildir"
            ),
            correctIndex = 0,
            explanation = "6331 Sayılı Kanun ve İSG Hizmetleri Yönetmeliği uyarınca periyodik muayene süreleri: Çok Tehlikeli sınıfta en geç 1 yılda 1, Tehlikeli sınıfta en geç 3 yılda 1, Az Tehlikeli sınıfta en geç 5 yılda 1 kez tekrarlanır.",
            legislationReference = "6331 Sayılı Kanun Madde 15 & Sağlık Gözetimi Esasları"
        ),
        IsgExamQuestion(
            id = "isg_q5",
            examType = "Diğer Sağlık Personeli (DSP)",
            topic = "İlk Yardım & Acil Durumlar",
            question = "İşyerlerinde Acil Durumlar Hakkında Yönetmelik uyarınca, Çok Tehlikeli sınıfta yer alan işyerlerinde her kaç çalışana kadar en az 1 arama, kurtarma, tahliye ve yangınla mücadele personeli görevlendirilir?",
            options = listOf(
                "Her 30 çalışana kadar en az 1 personel",
                "Her 40 çalışana kadar en az 1 personel",
                "Her 50 çalışana kadar en az 1 personel",
                "Her 100 çalışana kadar en az 1 personel"
            ),
            correctIndex = 0,
            explanation = "Acil durum destek elemanı sayıları: Çok Tehlikeli işyerlerinde her 30 çalışana kadar 1'er destek elemanı (Arama-kurtarma-tahliye ve Yangın), Tehlikeli sınıfta her 40 çalışana, Az Tehlikeli sınıfta her 50 çalışana kadardır.",
            legislationReference = "İşyerlerinde Acil Durumlar Hakkında Yönetmelik Madde 11"
        )
    )

    fun getIsgAiGeneratedQuestions(): List<IsgAiGeneratedQuestion> = listOf(
        IsgAiGeneratedQuestion(
            id = "isg_ai_q1",
            category = "6331 Sayılı İSG Kanunu",
            topic = "İşverenin Genel Yükümlülükleri & Riskten Kaçınma",
            difficulty = "ÖSYM Çıkmış Formatı",
            domain = "isgcepakademi.com.tr",
            question = "6331 Sayılı İSG Kanunu'nun 5. Maddesi uyarınca işverenin risklerden korunma ilkeleri arasında aşağıdakilerden hangisi İLK sırada yer alır?",
            options = listOf(
                "Risklerden kaçınmak ve tehlikeyi kaynağında yok etmek",
                "Kişisel koruyucu donanımlara öncelik vermek",
                "Kaçınılması mümkün olmayan riskleri analiz etmek",
                "Çalışanlara rutin ikaz levhaları asmak"
            ),
            correctIndex = 0,
            explanation = "6331 Sayılı Kanun Madde 5/1-a bendine göre koruma ilkelerinin başında 'Risklerden kaçınmak' ve 'Tehlikeleri kaynağında yok etmek' gelir. Toplu koruma her zaman kişisel korunmaya önceliklidir.",
            legislationReference = "6331 Sayılı İSG Kanunu Madde 5"
        ),
        IsgAiGeneratedQuestion(
            id = "isg_ai_q2",
            category = "Risk Metodolojileri & Fine-Kinney",
            topic = "Fine-Kinney Formülasyonu ve Risk Derecesi",
            difficulty = "İleri / Uzmanlık",
            domain = "isgcepakademi.xyz",
            question = "Fine-Kinney risk değerlendirme metodunda hesaplanan Risk Skoru (R = İ x Ş x F) değeri 240 çıkmıştır. Bu sonuca göre risk düzeyi ve eylem gereksinimi nedir?",
            options = listOf(
                "Esaslı Risk (200 - 400 arası): Kısa vadede (en geç birkaç gün içinde) iyileştirme yapılmalıdır",
                "Tolerans Edilemez Risk (> 400): İş derhal durdurulmalıdır",
                "Önemli Risk (70 - 200 arası): Birkaç ay içinde önlem alınabilir",
                "Kabul Edilebilir Risk (< 20): Acil önleme gerek yoktur"
            ),
            correctIndex = 0,
            explanation = "Fine-Kinney metodunda 200 - 400 arası skor 'Esaslı Risk' sınıfındadır ve kısa vadede (günler içinde) mühendislik veya yönetsel önlemlerle risk skoru düşürülmelidir.",
            legislationReference = "Fine-Kinney Metodolojisi & İSG Risk Değerlendirme Esasları"
        ),
        IsgAiGeneratedQuestion(
            id = "isg_ai_q3",
            category = "A Sınıfı İGU",
            topic = "Basınçlı Kaplar & Periyodik Muayeneler",
            difficulty = "İleri / Uzmanlık",
            domain = "isgcepakademi.com",
            question = "İş Ekipmanlarının Kullanımında Sağlık ve Güvenlik Şartları Yönetmeliği'ne göre, kompresör hava tanklarının periyodik kontrol süresi ve hidrostatik test basıncı ne olmalıdır?",
            options = listOf(
                "En geç yılda 1 kez ve işletme basıncının 1.5 katı ile hidrostatik test yapılmalıdır",
                "En geç 6 ayda 1 kez ve işletme basıncının 2 katı ile test yapılmalıdır",
                "En geç 3 yılda 1 kez tahribatsız muayene ile yapılmalıdır",
                "Kompresör bozulana kadar teste gerek yoktur"
            ),
            correctIndex = 0,
            explanation = "Basınçlı kap ve hava tanklarında standartlarda aksi belirtilmedikçe en geç yılda 1 periyodik kontrol yapılır ve hidrostatik test işletme basıncının 1.5 katı ile uygulanır.",
            legislationReference = "İş Ekipmanlarının Kullanımında Sağlık ve Güvenlik Şartları Yönetmeliği Ek-III"
        ),
        IsgAiGeneratedQuestion(
            id = "isg_ai_q4",
            category = "İşyeri Hekimliği",
            topic = "Gürültü Yönetmeliği & Eylem Değerleri",
            difficulty = "ÖSYM Çıkmış Formatı",
            domain = "isgcepakademi.com.tr",
            question = "Çalışanların Gürültü ile İlgili Risklerden Korunmalarına Dair Yönetmelik'e göre 'En Yüksek Maruziyet Eylem Değeri' (LEX, 8saat) kaç dB(A)'dır?",
            options = listOf(
                "85 dB(A)",
                "80 dB(A)",
                "87 dB(A)",
                "90 dB(A)"
            ),
            correctIndex = 0,
            explanation = "En düşük maruziyet eylem değeri 80 dB(A), En yüksek maruziyet eylem değeri 85 dB(A), Maruziyet sınır değeri ise (kulak koruyucu etkisi dahil) 87 dB(A)'dır.",
            legislationReference = "Gürültü Yönetmeliği Madde 5"
        ),
        IsgAiGeneratedQuestion(
            id = "isg_ai_q5",
            category = "KKD & Standartlar",
            topic = "Düşmeyi Önleyici Donanımlar (EN Standartları)",
            difficulty = "Orta Düzey",
            domain = "isgcepakademi.com",
            question = "Yüksekte çalışmalarda vücudu tam kavrayarak düşmeyi durduran 'Paraşüt Tipi Emniyet Kemeri' hangi Avrupa standardına (EN) uygun olmalıdır?",
            options = listOf(
                "TS EN 361",
                "TS EN 358",
                "TS EN 354",
                "TS EN 397"
            ),
            correctIndex = 0,
            explanation = "TS EN 361: Düşmeye karşı kişisel koruyucu donanımlar - Tam vücut emniyet kemerleri standardıdır. EN 358 konumlandırma, EN 354 bağlama halatları, EN 397 ise baret standardıdır.",
            legislationReference = "KKD Yönetmeliği & EN 361 Standardı"
        )
    )

    fun getIsgCourseModules(): List<IsgCourseModule> = listOf(
        IsgCourseModule(
            id = "course_6331_mastery",
            title = "6331 Sayılı İSG Kanunu ve Alt Mevzuat Uzmanlık Eğitimi",
            category = "Mevzuat & Hukuk",
            level = "İleri Düzey / Uzmanlık",
            durationHours = 24,
            instructor = "Av. & Baş İSG Denetçisi Canan Kaya",
            domain = "isgcepakademi.com.tr",
            description = "İş sağlığı ve güvenliği kanunu, 4857 sayılı İş Kanunu ilgili maddeleri, işverenin hukuki/cezai sorumlulukları, rücu davaları ve en güncel alt yönetmeliklerin vaka analizleriyle incelenmesi.",
            targetAudience = "A/B/C Sınıfı İGU'lar, İşyeri Hekimleri, İK Müdürleri, İş Hukuku Danışmanları",
            learningObjectives = listOf(
                "6331 sayılı Kanun'un tüm maddelerini ve emsal Yargıtay kararlarını yorumlama",
                "İş kazalarında kusur oranları, işveren ve uzman sorumluluk sınırları",
                "İdari para cezaları (İPC) itiraz süreçleri ve resmi teftiş hazırlığı",
                "Alt işveren-asıl işveren ilişkilerinde İSG koordinasyonu"
            ),
            syllabus = listOf(
                "Modül 1: 6331 Sayılı Kanun Temel Kavramlar & Kapsam",
                "Modül 2: İşverenin Genel Yükümlülükleri ve Koruma İlkeleri",
                "Modül 3: İSG Hizmetleri & İSG-KÂTİP Sözleşme Yönetimi",
                "Modül 4: İş Kazası Hukuki & Cezai Boyutları (Taksirle Ölüme/Yaralamaya Sebebiyet)",
                "Modül 5: Güncel Yönetmelik Değişiklikleri ve Teftiş Rehberi"
            ),
            certificationInfo = "isgcepakademi.com.tr Onaylı Başarı Sertifikası ve e-Devlet Barkodlu Doğrulama Kodu",
            enrolledCount = 3820,
            rating = 4.95,
            pdfDocumentUrl = "https://isgcepakademi.com.tr/dokumanlar/6331-sayili-isg-kanunu-ve-alt-mevzuat-rehberi.pdf",
            documentTitle = "6331 Sayılı İSG Kanunu ve Alt Yönetmelikler Kapsamlı Uygulama Rehberi",
            documentPagesCount = 12,
            documentFileSize = "4.8 MB"
        ),
        IsgCourseModule(
            id = "course_fine_kinney_matrix",
            title = "Kantitatif Risk Analizi: Fine-Kinney, FMEA & 5x5 L Matris",
            category = "Risk & Metodoloji",
            level = "İleri Düzey / Uzmanlık",
            durationHours = 18,
            instructor = "Dr. Mehmet Demir (Kıdemli Risk Mühendisi)",
            domain = "isgcepakademi.xyz",
            description = "Endüstriyel tesisler, inşaat ve kimya sektöründe tehlike tanımlama, Fine-Kinney frekans-ihtimal-şiddet katsayıları, FMEA hata türleri analizi ve DÖF (Düzeltici Önleyici Faaliyet) planlaması.",
            targetAudience = "Risk Değerlendirme Ekipleri, İSG Uzmanları, Üretim ve Bakım Şefleri",
            learningObjectives = listOf(
                "Fine-Kinney 3 parametreli matematiksel modelini eksiksiz hesaplama",
                "5x5 L Tipi ve Çoklu Matris metodolojilerini sahaya entegre etme",
                "Kabul edilebilir risk seviyeleri ve önlem hiyerarşisi belirleme",
                "Proses güvenliği ve FMEA ile arıza modu risk analizi hazırlama"
            ),
            syllabus = listOf(
                "Modül 1: Risk Değerlendirmesi Yönetmeliği ve Yasal Zorunluluklar",
                "Modül 2: Nitel ve Nicel Risk Değerlendirme Yöntemleri Karşılaştırması",
                "Modül 3: Fine-Kinney Metodolojisi Derinlemesine Uygulama & Excel Entegrasyonu",
                "Modül 4: Kimyasal, Biyolojik ve Ergonomik Risklerin Matrislenmesi",
                "Modül 5: Risk Skoruna Göre DÖF Takip Yazılımları ve Aksiyon Matrisi"
            ),
            certificationInfo = "isgcepakademi.xyz Uygulamalı Risk Mühendisliği Sertifikası",
            enrolledCount = 2940,
            rating = 4.92,
            pdfDocumentUrl = "https://isgcepakademi.xyz/docs/kantitatif-risk-analizi-fine-kinney-ve-matris-kilavuzu.pdf",
            documentTitle = "Kantitatif Risk Analizi Metodolojileri: Fine-Kinney, FMEA & 5x5 L Matris Sahası",
            documentPagesCount = 10,
            documentFileSize = "3.9 MB"
        ),
        IsgCourseModule(
            id = "course_nebosh_osha_prep",
            title = "Global İSG Sertifikasyonları: NEBOSH IGC & OSHA Standartları",
            category = "Global & Sertifikasyon",
            level = "İleri Düzey / Uzmanlık",
            durationHours = 32,
            instructor = "Eng. Sarah Jenkins (CMIOSH, NEBOSH Certified Trainer)",
            domain = "isgcepakademi.com",
            description = "Uluslararası petrol, gaz, inşaat ve lojistik projelerinde geçerli NEBOSH International General Certificate (IGC) ve OSHA 30-Hour Construction/General Industry müfredatına hazırlık eğitimi.",
            targetAudience = "Yurtdışı Projelerde Çalışan/Hedefleyen İSG Uzmanları, HSE Yöneticileri",
            learningObjectives = listOf(
                "NEBOSH IG1 ve IG2 sınav formatlarına ve OBE (Open Book Exam) tekniklerine hakim olma",
                "OSHA 1926 (İnşaat) ve OSHA 1910 (Genel Endüstri) federal standartlarını kavrama",
                "Uluslararası HSE yönetim sistemleri (ISO 45001) entegrasyonu",
                "Global güvenlik kültürü ve incident investigation teknikleri"
            ),
            syllabus = listOf(
                "Modül 1: Why We Should Manage Workplace Health and Safety",
                "Modül 2: How Health and Safety Management Systems Work and What They Look Like",
                "Modül 3: Managing Risk - Understanding People and Processes",
                "Modül 4: Health and Safety Monitoring and Measuring (IG2 Practical Assessment)",
                "Modül 5: OSHA Compliance, HazCom, Lockout/Tagout (LOTO) & Confined Spaces"
            ),
            certificationInfo = "isgcepakademi.com Global Akademi Uluslararası Hazırlık Bitirme Diploması",
            enrolledCount = 1850,
            rating = 4.98,
            pdfDocumentUrl = "https://isgcepakademi.com/docs/nebosh-igc-and-osha-standards-study-guide.pdf",
            documentTitle = "NEBOSH IGC & OSHA 30-Hour International Safety Standards Comprehensive Module",
            documentPagesCount = 15,
            documentFileSize = "5.6 MB"
        ),
        IsgCourseModule(
            id = "course_working_at_height_ppe",
            title = "Yüksekte Güvenli Çalışma, İskele Denetimi & KKD Standartları",
            category = "Saha Güvenliği & KKD",
            level = "Orta Düzey",
            durationHours = 12,
            instructor = "Serdar Aksoy (IRATA L3 Süpervizör & A Sınıfı İGU)",
            domain = "isgcepakademi.com.tr",
            description = "Yüksekte çalışma tanımı, TS EN 361 paraşüt tipi kemerler, şok emicili lanyardlar, yaşam hatları, flanşlı/kamalı cephe iskelelerinin kurulum kontrolü ve yeşil/kırmızı etiketleme prosedürleri.",
            targetAudience = "İnşaat Sahaları, Rüzgar Türbinleri ve Fabrika Bakım Ekipleri, İGU'lar",
            learningObjectives = listOf(
                "Düşmeyi durdurucu ve sınırlandırıcı sistemlerin EN standartlarını öğrenme (EN 361, EN 358, EN 353)",
                "İskele periyodik kontrol kriterleri ve TS EN 12810/12811 denetim formu doldurma",
                "Kurtarma planı hazırlama ve askı travması (ortostatik şok) önlemleri",
                "Ankraj noktalarının seçimi ve statik yük testleri"
            ),
            syllabus = listOf(
                "Modül 1: Yüksekte Çalışma İstatistikleri ve Yasal Çerçeve",
                "Modül 2: Kişisel Koruyucu Donanım (KKD) Seçimi, Kontrolü ve Bakımı",
                "Modül 3: Ön Yapımlı Cephe İskeleleri Güvenliği ve Etiketleme",
                "Modül 4: Mobil Yükseltilebilir Çalışma Platformları (MEWP / Manlift)",
                "Modül 5: Acil Durum Tahliye ve Askı Travması Müdahalesi"
            ),
            certificationInfo = "Uygulamalı Yüksekte Çalışma & İskele Kontrolörü Yetkinlik Belgesi",
            enrolledCount = 4120,
            rating = 4.89,
            pdfDocumentUrl = "https://isgcepakademi.com.tr/dokumanlar/yuksekte-guvenli-calisma-ve-iskele-denetim-dokumani.pdf",
            documentTitle = "Yüksekte Güvenli Çalışma, İskele Kontrolü & TS EN 361 KKD Standartları",
            documentPagesCount = 8,
            documentFileSize = "2.9 MB"
        ),
        IsgCourseModule(
            id = "course_occupational_health_firstaid",
            title = "İş Sağlığı, Meslek Hastalıkları & İleri İlkyardım Protokolleri",
            category = "Sağlık & İlkyardım",
            level = "Temel Seviye",
            durationHours = 16,
            instructor = "Uzm. Dr. Selin Öztürk (İşyeri Hekimi Eğitmeni)",
            domain = "isgcepakademi.com",
            description = "İşyerlerinde meslek hastalıklarının erken teşhisi, periyodik sağlık muayeneleri, gürültü/toz/titreşim maruziyet sınırları, biyolojik etkenler ve işyeri acil ilkyardım müdahaleleri.",
            targetAudience = "İşyeri Hekimleri, DSP, İlkyardımcı Personel ve İSG Komite Üyeleri",
            learningObjectives = listOf(
                "İşitme kayıpları (odyometri) ve solunum fonksiyon testleri (SFT) yorumlama",
                "İşyerinde kimyasal zehirlenmeler ve MSDS sağlık riskleri analizi",
                "Olay yerinde temel yaşam desteği (CPR) ve OED (Otomatik Şok Cihazı) kullanımı",
                "İş kazalarında turnike, kırık tespiti ve yanık protokolleri"
            ),
            syllabus = listOf(
                "Modül 1: Meslek Hastalıkları Tanı ve Bildirim Esasları",
                "Modül 2: Fiziksel Risk Etmenleri Sağlık Etkileri (Gürültü, Termal Konfor)",
                "Modül 3: Kimyasal ve Biyolojik Etkenlere Bağlı Hastalıklar",
                "Modül 4: Temel Yaşam Desteği, Kanamalar ve Şok Müdahalesi",
                "Modül 5: Gebe, Emziren ve Genç Çalışanların Sağlık Gözetimi"
            ),
            certificationInfo = "İSG Cep Akademi Onaylı İş Sağlığı & İlkyardım Gelişim Sertifikası",
            enrolledCount = 2100,
            rating = 4.94,
            pdfDocumentUrl = "https://isgcepakademi.com/docs/is-sagligi-ve-ileri-ilkyardim-protokolleri.pdf",
            documentTitle = "İş Sağlığı, Meslek Hastalıkları Tespiti ve İleri İlkyardım Müdahale Protokolü",
            documentPagesCount = 9,
            documentFileSize = "3.4 MB"
        )
    )

    fun getInitialRiskAssessments(): List<IsgRiskAssessment> = listOf(
        IsgRiskAssessment(
            id = "risk_1",
            activity = "Yüksekte İskele Kurulumu ve Dış Cephe Çalışması",
            dangerSource = "Düşme koruma sistemlerinin yetersizliği / Kırık kalas",
            riskDescription = "Çalışanın 12 metre yükseklikten düşmesi sonucu ağır yaralanma veya can kaybı",
            probability = 6.0,   // Fine-Kinney İhtimal: 6 (Kuvvetle muhtemel)
            severity = 40.0,     // Fine-Kinney Şiddet: 40 (Ölümcül kaza)
            frequency = 6.0,     // Fine-Kinney Frekans: 6 (Günlük / Sürekli)
            method = "Fine-Kinney",
            score = 1440.0,      // 6 * 40 * 6 = 1440 (Tolerans Edilemez Risk > 400)
            riskLevel = "Tolerans Edilemez Risk",
            recommendedActions = listOf(
                "Çalışmayı derhal durdurun ve alanı şeritle emniyete alın.",
                "TSE EN 12810/12811 standartlarına uygun flanşlı iskele ve tam ankrajlı yaşam hattı kurun.",
                "EN 361 paraşüt tipi emniyet kemeri, çift kollu şok emicili lanyard zorunlu kılın.",
                "Yüksekte çalışma eğitim sertifikası olmayan personelin iskeleye çıkışını yasaklayın."
            )
        ),
        IsgRiskAssessment(
            id = "risk_2",
            activity = "Atölyede CNC ve Torna Tezgahı Operasyonu",
            dangerSource = "Açık dönen fener mili ve talaş fırlaması",
            riskDescription = "Dönen aksama el veya kıyafet kapılması, göze talaş kaçması",
            probability = 3.0,   // Olası
            severity = 15.0,     // Kalıcı sakatlık / uzuv kaybı
            frequency = 6.0,     // Günlük
            method = "Fine-Kinney",
            score = 270.0,       // 3 * 15 * 6 = 270 (Esaslı Risk: 200 - 400)
            riskLevel = "Esaslı Risk",
            recommendedActions = listOf(
                "Tezgah aynasına ve dönen mile mikroswitchli interlock emniyet siperliği takın.",
                "Operatörlerin bol kıyafet, yüzük, kravat veya eldivenle tezgaha yaklaşmasını engelleyin.",
                "EN 166 standartlı polikarbonat koruyucu iş gözlüğü kullanımını denetleyin."
            )
        ),
        IsgRiskAssessment(
            id = "risk_3",
            activity = "Kimyasal Depolama Alanı Malzeme Transferi",
            dangerSource = "Uçucu organik solvent buharı ve sızıntı",
            riskDescription = "Solvent buharı solunması nedeniyle kronik solunum yolu zehirlenmesi",
            probability = 2.0,   // Düşük ihtimal
            severity = 7.0,      // İş göremezlik
            frequency = 3.0,     // Haftada bir
            method = "Fine-Kinney",
            score = 42.0,        // 2 * 7 * 3 = 42 (Olası Risk: 20 - 70)
            riskLevel = "Olası Risk",
            recommendedActions = listOf(
                "Kimyasal depoya ex-proof lokal cebri havalandırma sistemi kurun.",
                "Güvenlik Bilgi Formlarını (GBF/MSDS) Türkçe ve güncel olarak depolama alanına asın.",
                "A2P3 kombine filtreli yarım yüz maskesi temin edin."
            )
        )
    )

    fun getIsgApiEndpoints(): List<IsgApiEndpoint> = listOf(
        IsgApiEndpoint(
            method = "GET",
            path = "/api/v1/academy/cert-verify",
            domain = "isgcepakademi.com",
            title = "Global Sertifika Doğrulama Servisi",
            description = "isgcepakademi.com üzerinden alınan uluslararası ve yerel İSG eğitim sertifikalarını sorgular ve QR doğrulamasını yapar.",
            requestSample = """
curl -X GET "https://api.isgcepakademi.com/v1/academy/cert-verify?cert_id=ISG-2026-9941A" \
-H "Authorization: Bearer isg_live_token_77a9"
            """.trimIndent(),
            responseSample = """
{
  "status": "valid",
  "domain": "isgcepakademi.com",
  "certificate": {
    "cert_id": "ISG-2026-9941A",
    "student_name": "Ahmet Yılmaz",
    "course": "NEBOSH International General Certificate (IGC)",
    "issue_date": "2026-03-15",
    "expiry_date": "2029-03-15",
    "status": "ACTIVE_VERIFIED"
  }
}
            """.trimIndent()
        ),
        IsgApiEndpoint(
            method = "GET",
            path = "/api/v1/legislation/search",
            domain = "isgcepakademi.com.tr",
            title = "Mevzuat Arama ve İPC Sorgu Servisi",
            description = "Resmi Gazete indeksli 6331 ve 4857 maddelerini, ceza katsayılarını ve yükümlülükleri döndürür.",
            requestSample = """
curl -X GET "https://api.isgcepakademi.com.tr/v1/legislation/search?q=risk+degerlendirmesi&year=2026" \
-H "Authorization: Bearer isg_live_token_77a9"
            """.trimIndent(),
            responseSample = """
{
  "status": "success",
  "domain": "isgcepakademi.com.tr",
  "query": "risk degerlendirmesi",
  "results_count": 14,
  "top_matches": [
    {
      "law_code": "6331",
      "article": 10,
      "title": "Risk Değerlendirmesi, Kontrol, Ölçüm ve Araştırma",
      "fine_try_per_month": 48250.00,
      "summary": "İşveren, iş sağlığı ve güvenliği yönünden çalışma ortamına ve çalışanların maruz kaldığı risklerin belirlenmesine yönelik risk değerlendirmesi yapar veya yaptırır."
    }
  ]
}
            """.trimIndent()
        ),
        IsgApiEndpoint(
            method = "POST",
            path = "/api/v2/risk-evaluate/fine-kinney",
            domain = "isgcepakademi.xyz",
            title = "Fine-Kinney Risk Hesaplama Motoru",
            description = "İhtimal, Şiddet ve Frekans değerlerini alıp otomatik risk skoru, renk kodu ve DÖF eylem planı oluşturur.",
            requestSample = """
curl -X POST "https://engine.isgcepakademi.xyz/api/v2/risk-evaluate/fine-kinney" \
-H "Content-Type: application/json" \
-d '{
  "activity": "Forklift ile Paletli Yükleme",
  "hazard": "Kör noktada yaya çarpışması",
  "probability": 6.0,
  "severity": 15.0,
  "frequency": 6.0
}'
            """.trimIndent(),
            responseSample = """
{
  "status": "success",
  "domain": "isgcepakademi.xyz",
  "score": 540.0,
  "level": "TOLERANS_EDILEMEZ_RISK",
  "risk_color": "#D32F2F",
  "urgency": "Derhal Faaliyet Durdurulmalı / Acil Önlem Alınmalı",
  "recommended_actions": [
    "Fabrika içi yaya yollarını sarı çizgiler ve çelik bariyerle ayırın",
    "Forkliftlere Blue Spot (Mavi Işık) ve sesli geri vites ikazı takın",
    "Kör noktalara 360 derece parabolik güvenlik aynaları monte edin"
  ]
}
            """.trimIndent()
        ),
        IsgApiEndpoint(
            method = "GET",
            path = "/api/v1/exams/questions/random",
            domain = "isgcepakademi.com.tr",
            title = "ÖSYM Formatlı Sınav Soru Üreteci",
            description = "A/B/C Sınıfı İGU, İşyeri Hekimliği veya DSP için güncel soru bankasından filtrelenmiş sorular çeker.",
            requestSample = """
curl -X GET "https://sinav.isgcepakademi.com.tr/v1/exams/questions/random?exam=C_SINIFI&count=5" \
-H "Authorization: Bearer isg_live_token_77a9"
            """.trimIndent(),
            responseSample = """
{
  "exam_type": "C Sınıfı İGU",
  "question_count": 5,
  "questions": [
    {
      "id": "isg_q1",
      "topic": "İş Kazası Bildirimi",
      "question": "6331'e göre SGK bildirim süresi ne kadardır?",
      "options": ["3 iş günü", "Derhal", "24 saat", "1 ay"],
      "correct_index": 0,
      "legislation_ref": "6331 Madde 14"
    }
  ]
}
            """.trimIndent()
        ),
        IsgApiEndpoint(
            method = "POST",
            path = "/api/v1/webhook/events",
            domain = "isgcepakademi.xyz",
            title = "İSG Cep Akademi Canlı Webhook Köprüsü",
            description = "Mevzuat değişiklikleri, yeni soru eklemeleri ve ramak kala bildirimleri için IDX / Webhook bildirim soketi.",
            requestSample = """
curl -X POST "https://webhook.isgcepakademi.xyz/api/v1/webhook/register" \
-H "Content-Type: application/json" \
-d '{
  "target_url": "https://myapp.cloudrun.app/api/isg-webhook",
  "events": ["legislation.updated", "incident.reported", "exam.published"]
}'
            """.trimIndent(),
            responseSample = """
{
  "registered": true,
  "webhook_id": "whk_isg_9921b",
  "status": "ACTIVE_LISTENING",
  "sync_interval": "REALTIME_WS"
}
            """.trimIndent()
        )
    )

    fun getIsgHapBilgileri(): List<IsgHapBilgi> = listOf(
        IsgHapBilgi(
            id = "hb_1",
            title = "Kritik İSG Süreleri ve Yenileme Periyotları",
            category = "Kritik Süreler & Periyotlar",
            summary = "Risk değerlendirmesi, acil durum planları, sağlık muayeneleri ve çalışan eğitimlerinin tehlike sınıflarına göre zorunlu yenilenme süreleri.",
            keyPoints = listOf(
                "Risk Değerlendirmesi Yenileme: Çok Tehlikeli: 2 Yılda 1, Tehlikeli: 4 Yılda 1, Az Tehlikeli: 6 Yılda 1",
                "Acil Durum Planları Yenileme: Çok Tehlikeli: 2 Yılda 1, Tehlikeli: 4 Yılda 1, Az Tehlikeli: 6 Yılda 1",
                "Acil Durum Tatbikatı: En geç yılda 1 kez (Madenlerde 6 ayda 1)",
                "Periyodik Sağlık Muayeneleri: Çok Tehlikeli: Yılda 1, Tehlikeli: 3 Yılda 1, Az Tehlikeli: 5 Yılda 1",
                "Temel İSG Eğitimleri: Çok Tehlikeli: Yılda 1 (16 Saat), Tehlikeli: 2 Yılda 1 (12 Saat), Az Tehlikeli: 3 Yılda 1 (8 Saat)",
                "İş Kazası Bildirimi: Kazadan sonraki 3 İŞ GÜNÜ içinde SGK'ya bildirilmelidir",
                "Sağlık Hizmet Sunucuları Bildirimi: Kendilerine intikal eden iş kazalarını en geç 10 GÜN içinde SGK'ya bildirir"
            ),
            lawReference = "6331 Sayılı Kanun Madde 10, 11, 14, 15 & İlgili Yönetmelikler",
            badge = "En Çok Soru Çıkan Konu"
        ),
        IsgHapBilgi(
            id = "hb_2",
            title = "Çalışan Temsilcisi & İSG Kurulu Şartları",
            category = "Çalışan & Temsilci Sayıları",
            summary = "İşyerlerinde atanacak çalışan temsilcisi sayı baremleri ve İSG Kurulu kurma zorunluluğu kriterleri.",
            keyPoints = listOf(
                "2 - 50 Çalışan: 1 Çalışan Temsilcisi",
                "51 - 100 Çalışan: 2 Çalışan Temsilcisi",
                "101 - 500 Çalışan: 3 Çalışan Temsilcisi",
                "501 - 1000 Çalışan: 4 Çalışan Temsilcisi",
                "1001 - 2000 Çalışan: 5 Çalışan Temsilcisi",
                "2001 ve Üzeri: 6 Çalışan Temsilcisi",
                "İSG Kurulu Zorunluluğu: 50 ve daha fazla çalışan bulunan ve 6 aydan fazla süren sürekli işlerin yapıldığı işyerlerinde kurulur",
                "Kurul Toplantı Sıklığı: Normalde ayda 1 kez (Tehlikeli işyerlerinde 2 ayda 1, Az tehlikeli işyerlerinde 3 ayda 1 olarak Kurul kararıyla belirlenebilir)"
            ),
            lawReference = "6331 Sayılı Kanun Madde 20 & 22",
            badge = "Sınavda Kesin Çıkar"
        ),
        IsgHapBilgi(
            id = "hb_3",
            title = "Fiziksel Risk Etmenleri: Gürültü ve Titreşim Değerleri",
            category = "Eşik & Eylem Değerleri",
            summary = "Gürültü ve titreşim yönetmeliklerinde yer alan yasal maruziyet eylem ve sınır değerleri tablosu.",
            keyPoints = listOf(
                "Gürültü En Düşük Maruziyet Eylem Değeri: 80 dB(A) -> Kulak koruyucu temin edilir (kullanım isteğe bağlı)",
                "Gürültü En Yüksek Maruziyet Eylem Değeri: 85 dB(A) -> Kulak koruyucu kullanımı ZORUNLU hale gelir",
                "Gürültü Maruziyet Sınır Değeri: 87 dB(A) -> Kulak koruyucunun etkisi dahil kesinlikle aşılamaz",
                "El-Kol Titreşimi 8 Saatlik Günlük Eylem Değeri: 2.5 m/s²",
                "El-Kol Titreşimi 8 Saatlik Günlük Sınır Değeri: 5.0 m/s²",
                "Bütün Vücut Titreşimi 8 Saatlik Günlük Eylem Değeri: 0.5 m/s²",
                "Bütün Vücut Titreşimi 8 Saatlik Günlük Sınır Değeri: 1.15 m/s²"
            ),
            lawReference = "Gürültü & Titreşim Yönetmelikleri (Madde 5)",
            badge = "Sayısal Soru Şablonu"
        ),
        IsgHapBilgi(
            id = "hb_4",
            title = "İSG-KÂTİP Çalışma Süreleri & Tam Zamanlı Uzman Eşikleri",
            category = "İSG Kurulları & Kâtip",
            summary = "İş Güvenliği Uzmanı, İşyeri Hekimi ve Diğer Sağlık Personeli için kişi başı aylık asgari çalışma dakikaları.",
            keyPoints = listOf(
                "İGU Az Tehlikeli Sınıf: Çalışan başına ayda en az 10 DAKİKA (Her 1000 çalışanda 1 tam gün uzman)",
                "İGU Tehlikeli Sınıf: Çalışan başına ayda en az 20 DAKİKA (Her 500 çalışanda 1 tam gün uzman)",
                "İGU Çok Tehlikeli Sınıf: Çalışan başına ayda en az 40 DAKİKA (Her 250 çalışanda 1 tam gün uzman)",
                "İşyeri Hekimi Az Tehlikeli: Çalışan başına ayda en az 5 DAKİKA (Her 2000 çalışanda 1 tam gün hekim)",
                "İşyeri Hekimi Tehlikeli: Çalışan başına ayda en az 10 DAKİKA (Her 1000 çalışanda 1 tam gün hekim)",
                "İşyeri Hekimi Çok Tehlikeli: Çalışan başına ayda en az 15 DAKİKA (Her 750 çalışanda 1 tam gün hekim)",
                "DSP (Diğer Sağlık Personeli): Çok tehlikeli sınıfta 10+ çalışanda zorunludur (10-49 çalışan: 35 dk, 50-249: 40 dk, 250+: 50 dk)"
            ),
            lawReference = "İSG Hizmetleri Yönetmeliği Ek-1",
            badge = "Kâtip Hesaplama Matrisi"
        ),
        IsgHapBilgi(
            id = "hb_5",
            title = "TS EN 2 Yangın Sınıfları & Söndürme Maddeleri",
            category = "Yangın & Acil Durum",
            summary = "Yanıcı maddenin cinsine göre yangın sınıflaması ve kullanılacak uygun söndürme maddeleri.",
            keyPoints = listOf(
                "A Sınıfı Yangınlar: Katı madde (ahşap, kömür, kağıt, tekstil) yangınlarıdır. Temel söndürücü: SU ve ABC Kuru Kimyevi Toz",
                "B Sınıfı Yangınlar: Sıvı yanıcı (benzin, mazot, tiner, boya) yangınlarıdır. Temel söndürücü: KÖPÜK, KKT, CO2 (ASLA SU KULLANILMAZ)",
                "C Sınıfı Yangınlar: Gaz (LPG, doğalgaz, metan, hidrojen) yangınlarıdır. Temel söndürücü: KKT, CO2 (Önce gaz vanası kesilmelidir)",
                "D Sınıfı Yangınlar: Hafif metal (magnezyum, alüminyum, titanyum, lityum, sodyum) yangınlarıdır. Temel söndürücü: ÖZEL D TOZU / KURU KUM (Asla su ve köpük sıkılmaz, patlar!)",
                "F Sınıfı Yangınlar: Pişirme ortamı ve bitkisel/hayvansal mutfak yağları yangınlarıdır. Temel söndürücü: ISLAK KİMYASAL (Wet Chemical) ve Yangın Battaniyesi (Asla su dökülmez)"
            ),
            lawReference = "Binaların Yangından Korunması Hakkında Yönetmelik & TS EN 2",
            badge = "Yangın Güvenliği"
        ),
        IsgHapBilgi(
            id = "hb_6",
            title = "İş Ekipmanları Periyodik Kontrol Süreleri",
            category = "Kritik Süreler & Periyotlar",
            summary = "Basınçlı kaplar, kaldırma araçları, iskeleler ve tesisatların yasal muayene aralıkları.",
            keyPoints = listOf(
                "Basınçlı Kaplar & Hava Tankları / Kazanlar: Standartta süre yoksa En geç YILDA 1 KEZ (Test: 1.5 katı işletme basıncı)",
                "Kaldırma ve İletme Ekipmanları (Vinç, Caraskal, Forklift, Transpalet): En geç YILDA 1 KEZ (Statik test: 1.25 katı, Dinamik test: 1.1 katı)",
                "Ön Yapımlı Cephe İskeleleri: En geç 6 AYDA 1 KEZ",
                "Elektrik Tesisatı, Topraklama, Paratoner ve Akümülatör/Transformatör: En geç YILDA 1 KEZ",
                "Yangın Tesisatı ve Hortumlar / Yangın Pompaları: En geç YILDA 1 KEZ",
                "Havalandırma ve Klima Tesisatları: En geç YILDA 1 KEZ"
            ),
            lawReference = "İş Ekipmanlarının Kullanımında Sağlık ve Güvenlik Şartları Yönetmeliği Ek-III",
            badge = "Saha Denetim Kriteri"
        )
    )

    fun getClonedVoiceProfiles(): List<ClonedVoiceProfile> = listOf(
        ClonedVoiceProfile(
            id = "voice_el_01",
            name = "Eğitmen Ahmet Bey (Klon)",
            provider = "ElevenLabs Instant Cloning",
            voiceId = "21m00Tcm4TlvDq8ikWAM",
            language = "tr-TR",
            description = "Otoriter, berrak ve akıcı Türkçe İSG baş denetçisi ses tonu. Mevzuat ve saha anlatımları için optimize.",
            gender = "Erkek",
            stability = 0.78f,
            similarityBoost = 0.90f,
            sampleAudioDurationSec = 30,
            isDefault = true
        ),
        ClonedVoiceProfile(
            id = "voice_el_02",
            name = "Uzman Zeynep Hanım (Klon)",
            provider = "ElevenLabs Multilingual v2",
            voiceId = "AZnzlk1XvdvUeBnXmlld",
            language = "tr-TR",
            description = "Dinamik, sıcak ve eğitici anlatım tarzı. Hap bilgiler, reels ve kısa sınav ipuçları için ideal.",
            gender = "Kadın",
            stability = 0.72f,
            similarityBoost = 0.88f,
            sampleAudioDurationSec = 25,
            isDefault = false
        ),
        ClonedVoiceProfile(
            id = "voice_gc_01",
            name = "Google Cloud Wavenet TR (Stüdyo)",
            provider = "Google Cloud Custom Voice",
            voiceId = "tr-TR-Wavenet-E",
            language = "tr-TR",
            description = "Yüksek netlikte ve nöral telaffuzlu stüdyo kaydı kalitesinde sentetik ses motoru.",
            gender = "Erkek",
            stability = 0.85f,
            similarityBoost = 0.80f,
            sampleAudioDurationSec = 20,
            isDefault = false
        ),
        ClonedVoiceProfile(
            id = "voice_gem_01",
            name = "Gemini Native Multimodal Voice (Aoede)",
            provider = "Gemini Live Audio In/Out",
            voiceId = "aoede-tr",
            language = "tr-TR",
            description = "Doğal tonlama ve duraklama yeteneğine sahip Gemini 2.0 yerel ses sentezleme.",
            gender = "Kadın",
            stability = 0.90f,
            similarityBoost = 0.92f,
            sampleAudioDurationSec = 15,
            isDefault = false
        )
    )

    fun getInitialVideoPipelineJobs(): List<VideoGenerationPipelineJob> = listOf(
        VideoGenerationPipelineJob(
            id = "VID-ISG-001",
            title = "Yüksekte Çalışma & Yaşam Hattı Kuralları",
            courseDomain = "isgcepakademi.com.tr",
            scriptText = "Merhaba değerli meslektaşlarım. Yüksekte çalışmalarda düşmeyi durdurucu sistemler ve dikey yaşam hatları hayati önem taşır. Ankraj noktalarınızın EN 795 standardına uygun olduğundan ve paraşüt tipi emniyet kemerinizin her kullanım öncesi kontrol edildiğinden emin olun.",
            voiceProfile = ClonedVoiceProfile(
                id = "voice_el_01",
                name = "Eğitmen Ahmet Bey (Klon)",
                provider = "ElevenLabs Instant Cloning",
                voiceId = "21m00Tcm4TlvDq8ikWAM",
                language = "tr-TR",
                description = "Otoriter, berrak ve akıcı Türkçe İSG baş denetçisi ses tonu.",
                gender = "Erkek",
                stability = 0.78f,
                similarityBoost = 0.90f,
                sampleAudioDurationSec = 30,
                isDefault = true
            ),
            avatarStyle = "3D İSG Baş Denetçisi",
            format = "9:16 Dikey (Shorts/Reels/TikTok)",
            status = VideoJobStatus.COMPLETED,
            progressPercent = 100,
            durationSeconds = 28,
            outputVideoUrl = "https://cdn.isgcepakademi.com.tr/videos/yuksekte-calisma-reels.mp4",
            outputAudioUrl = "https://cdn.isgcepakademi.com.tr/audio/yuksekte-calisma.mp3",
            subtitles = listOf(
                VideoSubtitleCue(0, 4200, "Merhaba değerli meslektaşlarım."),
                VideoSubtitleCue(4200, 12000, "Yüksekte çalışmalarda düşmeyi durdurucu sistemler ve dikey yaşam hatları hayati önem taşır."),
                VideoSubtitleCue(12000, 28000, "Ankraj noktalarınızın EN 795 standardına uygun olduğundan emin olun.")
            ),
            createdAt = "2026-08-25 09:15"
        ),
        VideoGenerationPipelineJob(
            id = "VID-ISG-002",
            title = "Gürültü Sınır & Maruziyet Eşik Değerleri",
            courseDomain = "isgcepakademi.com",
            scriptText = "İşitme kayıplarının önüne geçmek için 80 desibel en düşük, 85 desibel en yüksek eylem değeridir. 87 desibel ise kulak koruyucu etkisi dahil kesin maruziyet sınır değeridir.",
            voiceProfile = ClonedVoiceProfile(
                id = "voice_el_02",
                name = "Uzman Zeynep Hanım (Klon)",
                provider = "ElevenLabs Multilingual v2",
                voiceId = "AZnzlk1XvdvUeBnXmlld",
                language = "tr-TR",
                description = "Dinamik, sıcak ve eğitici anlatım tarzı.",
                gender = "Kadın",
                stability = 0.72f,
                similarityBoost = 0.88f,
                sampleAudioDurationSec = 25,
                isDefault = false
            ),
            avatarStyle = "Hap Bilgi Reels Karakteri",
            format = "16:9 Yatay (YouTube/LMS)",
            status = VideoJobStatus.COMPLETED,
            progressPercent = 100,
            durationSeconds = 22,
            outputVideoUrl = "https://cdn.isgcepakademi.com/videos/gurultu-esik-dersi.mp4",
            outputAudioUrl = "https://cdn.isgcepakademi.com/audio/gurultu-esik.mp3",
            subtitles = listOf(
                VideoSubtitleCue(0, 8000, "İşitme kayıplarının önüne geçmek için 80 desibel en düşük eylem değeridir."),
                VideoSubtitleCue(8000, 15000, "85 desibel en yüksek eylem değeridir."),
                VideoSubtitleCue(15000, 22000, "87 desibel ise kulak koruyucu dahil kesin maruziyet sınır değeridir.")
            ),
            createdAt = "2026-08-25 11:00"
        )
    )

    // Personal PC & Workstation Data
    fun getPersonalWorkstationConfig(): PersonalPcWorkstation = PersonalPcWorkstation(
        hostname = "ozben-workstation-pc",
        ownerName = "Özben A.",
        ownerRole = "Kıdemli Bulut Mimarı & İSG Baş Uzmanı",
        osName = "DevOS Workstation Linux (x86_64)",
        kernelVersion = "6.8.0-devstudio-cloud-hybrid",
        cpuModel = "AMD Ryzen 9 7950X / Google Cloud DevEngine (16 vCPU)",
        cpuUsagePercent = 22,
        ramTotalGb = 32,
        ramUsedGb = 9.4,
        diskTotalGb = 512,
        diskUsedGb = 142.8,
        localIp = "192.168.1.108",
        uptimeFormatted = "7 gün, 18 saat, 45 dk",
        isTurboBoostEnabled = true,
        activeTheme = "Cyber Matrix Dark",
        emulatorDpiScale = 1.0f,
        windowMode = "Desktop Workstation",
        personalNotesCount = 4,
        filesCount = 6
    )

    fun getInitialWorkspaceFiles(): List<PersonalWorkspaceFile> = listOf(
        PersonalWorkspaceFile(
            id = "file_01",
            path = "/workspace/isg/fine_kinney_calculator.py",
            name = "fine_kinney_calculator.py",
            extension = "py",
            sizeBytes = 2840,
            category = "KAYNAK KOD",
            lastModified = "2026-08-25 13:10",
            content = """
# Fine-Kinney Risk Skoru Hesaplama Motoru (v2.4)
# Formül: R = Olasılık (O) x Frekans (F) x Şiddet (S)

def calculate_risk(prob: float, freq: float, sev: float) -> dict:
    score = prob * freq * sev
    if score >= 400:
        level = "TOLERANS EDİLEMEZ RİSK"
        action = "Derhal çalışma durdurulmalı, acil önlem alınmalıdır."
    elif score >= 200:
        level = "ESASLI RİSK"
        action = "Kısa vadede (en geç 1 hafta) önlem alınmalıdır."
    elif score >= 70:
        level = "ÖNEMLİ RİSK"
        action = "Planlı düzeltici önleyici faaliyet başlatılmalıdır."
    elif score >= 20:
        level = "OLASI RİSK"
        action = "İzleme ve periyodik kontrol planına alınmalıdır."
    else:
        level = "KABUL EDİLEBİLİR RİSK"
        action = "Mevcut tedbirlerin sürekliliği sağlanmalıdır."
    
    return {"score": round(score, 2), "level": level, "action": action}

if __name__ == "__main__":
    result = calculate_risk(prob=6.0, freq=3.0, sev=15.0)
    print(f"Risk Skoru: {result['score']} -> {result['level']}")
""".trimIndent()
        ),
        PersonalWorkspaceFile(
            id = "file_02",
            path = "/workspace/isg/saha_denetim_kontrol.json",
            name = "saha_denetim_kontrol.json",
            extension = "json",
            sizeBytes = 1950,
            category = "İSG RAPORU",
            lastModified = "2026-08-25 12:45",
            content = """
{
  "denetimNo": "ISG-2026-0825-01",
  "isletme": "Mega Endüstri Tesisleri A.Ş.",
  "sektor": "Çok Tehlikeli (Kimya & İmalat)",
  "denetci": "Özben A. (A Sınıfı İGU)",
  "maddeler": [
    {"konu": "Acil Çıkış Kapıları", "durum": "UYGUN", "not": "Panik barlı ve dışa açılır."},
    {"konu": "Yangın Söndürme Tüpleri", "durum": "UYGUN", "not": "Son hidrostatik test: 2026/04"},
    {"konu": "Kimyasal Güvenlik Bilgi Formları (GBF/MSDS)", "durum": "UYARI", "not": "3 solvent tankında Türkçe GBF güncellenmeli."},
    {"konu": "Yüksekte Çalışma KKD ve Yaşam Hatları", "durum": "UYGUN", "not": "EN 361 ve EN 355 tam uyumlu."}
  ],
  "genelUygunlukYuzdesi": 94.5
}
""".trimIndent()
        ),
        PersonalWorkspaceFile(
            id = "file_03",
            path = "/workspace/config/devos_env.sh",
            name = "devos_env.sh",
            extension = "sh",
            sizeBytes = 1120,
            category = "YAPILANDIRMA",
            lastModified = "2026-08-25 10:30",
            content = """
#!/usr/bin/env bash
# DevOS Kişisel Geliştirici Ortamı Değişkenleri
export WORKSPACE_ROOT="/workspace"
export ISG_DOMAINS="isgcepakademi.com,isgcepakademi.com.tr,isgcepakademi.xyz"
export GEMINI_MODEL="gemini-2.5-pro"
export CLOUD_EMULATOR_DPI="1.0"
export ELEVENLABS_VOICE_STABILITY="0.75"

echo "[DevOS] Kişisel Bilgisayar ortam değişkenleri başarıyla yüklendi."
""".trimIndent()
        ),
        PersonalWorkspaceFile(
            id = "file_04",
            path = "/workspace/notes/mevzuat_ozetleri.md",
            name = "mevzuat_ozetleri.md",
            extension = "md",
            sizeBytes = 3400,
            category = "DOKÜMAN",
            lastModified = "2026-08-25 09:15",
            content = """
# 6331 Sayılı İSG Kanunu & Kritik Hatırlatmalar

### 1. Risk Değerlendirmesi Yenileme Periyotları
- **Çok Tehlikeli:** En geç 2 yılda bir
- **Tehlikeli:** En geç 4 yılda bir
- **Az Tehlikeli:** En geç 6 yılda bir

### 2. Acil Durum Tatbikatları
- Yılda en az **1 defa** düzenlenmesi zorunludur.

### 3. Gürültü Sınır Değerleri (Yönetmelik)
- **En Düşük Maruziyet Eylem:** 80 dB(A)
- **En Yüksek Maruziyet Eylem:** 85 dB(A)
- **Maruziyet Sınır Değeri:** 87 dB(A) *(KKD etkisi dahil)*
""".trimIndent()
        ),
        PersonalWorkspaceFile(
            id = "file_05",
            path = "/workspace/scripts/run_ai_pipeline.kt",
            name = "run_ai_pipeline.kt",
            extension = "kt",
            sizeBytes = 2100,
            category = "SCRİPT",
            lastModified = "2026-08-25 08:50",
            content = """
package com.example.scripts

// Kişisel Gemini AI Çoklu Model İcra Scripti
fun executePipeline(inputPrompt: String) {
    println("Pipeline başlatılıyor: " + inputPrompt)
    val start = System.currentTimeMillis()
    // AI Model inferencing call simulation
    val elapsed = System.currentTimeMillis() - start
    println("Tamamlandı: " + elapsed + "ms")
}
""".trimIndent()
        ),
        PersonalWorkspaceFile(
            id = "file_06",
            path = "/workspace/docs/sertifikalarim.txt",
            name = "sertifikalarim.txt",
            extension = "txt",
            sizeBytes = 850,
            category = "DOKÜMAN",
            lastModified = "2026-08-25 08:20",
            content = """
KİŞİSEL SERTİFİKA VE YETKİ BELGELERİ
--------------------------------------
1. ÇSGB A Sınıfı İş Güvenliği Uzmanlığı Belgesi (No: TR-ISG-88421)
2. ISO 45001 Baş Denetçi Sertifikası (IRCA Onaylı)
3. Google Cloud Certified Professional Cloud Architect
4. Yangın Eğitici Eğitmeni & İlkyardım Sertifikası
""".trimIndent()
        )
    )

    fun getInitialWorkspaceNotes(): List<PersonalWorkspaceNote> = listOf(
        PersonalWorkspaceNote(
            id = "note_01",
            title = "📌 Haftalık İSG Denetim & Sınav Simülatörü Kontrolü",
            content = "1. isgcepakademi.com.tr ve xyz alan adlarındaki yeni soru bankasını test et.\n2. Fine-Kinney hesaplayıcıdaki tolerans eşiklerini doğrula.\n3. ElevenLabs klon ses modelinin yeni modül anlatımını tamamla.",
            category = "Yapılacaklar",
            isPinned = true,
            updatedAt = "2026-08-25 13:15",
            tags = listOf("İSG", "Saha", "Sprint")
        ),
        PersonalWorkspaceNote(
            id = "note_02",
            title = "💡 Gemini 2.5 Flash Hızlı Prompt Şablonu",
            content = "Sistem komutu: 'Sen A Sınıfı İSG Baş Denetçisisin. 6331 sayılı kanun ve ilgili yönetmelik maddelerine göre yanıt ver.'\nÇıktı formatı JSON tabanlı olmalı.",
            category = "Geliştirme",
            isPinned = true,
            updatedAt = "2026-08-25 12:40",
            tags = listOf("AI", "Gemini", "Prompt")
        ),
        PersonalWorkspaceNote(
            id = "note_03",
            title = "⚡ Kişisel Dev Terminal Hızlı Kısayolları",
            content = "- `sysinfo`: Kişisel bilgisayar sistem durumunu gösterir.\n- `ls`: Çalışma alanındaki dosyaları listeler.\n- `cat [dosya]`: Dosya içeriğini yazdırır.\n- `gemini [soru]`: AI asistanına doğrudan komut satırından soru sorar.\n- `isg-check`: Hızlı mevzuat doğrulaması yapar.",
            category = "Sistem & Terminal",
            isPinned = false,
            updatedAt = "2026-08-25 11:30",
            tags = listOf("Terminal", "DevOS", "CLI")
        ),
        PersonalWorkspaceNote(
            id = "note_04",
            title = "📋 Tehlike Sınıfları Tebliği Hatırlatması",
            content = "NACE koduna göre tehlike sınıfı tespiti yapılırken asıl işin niteliği dikkate alınır. İtirazlar ÇSGB Tehlike Sınıfları Komisyonuna yapılır.",
            category = "İSG Mevzuat",
            isPinned = false,
            updatedAt = "2026-08-25 10:10",
            tags = listOf("Mevzuat", "6331", "NACE")
        )
    )

    fun getInitialTerminalEntries(): List<PersonalTerminalEntry> = listOf(
        PersonalTerminalEntry(
            id = "term_01",
            command = "neofetch",
            output = """
       /\_/\      ozben@ozben-workstation-pc
      ( o.o )     --------------------------
       > ^ <      OS: DevOS Workstation Linux x86_64
                  Host: Google Cloud DevEngine High-Compute
                  Kernel: 6.8.0-devstudio-cloud-hybrid
                  Uptime: 7 days, 18 hours, 45 mins
                  Shell: dev-bash 5.2.26
                  Terminal: IDX Integrated Cloud Console
                  CPU: AMD Ryzen 9 7950X (16 vCPU) @ 4.50GHz
                  GPU: Virtual Mali-G78 DevEngine
                  Memory: 9.4GB / 32.0GB (29.3%)
                  Disk: 142.8GB / 512.0GB (27.8%)
""".trimIndent(),
            isError = false,
            timestamp = "13:18:22"
        ),
        PersonalWorkspaceFile(
            id = "term_welcome",
            path = "",
            name = "",
            extension = "",
            sizeBytes = 0,
            content = "",
            category = ""
        ).let {
            PersonalTerminalEntry(
                id = "term_02",
                command = "ls -la /workspace",
                output = """
total 36
drwxr-xr-x 6 ozben ozben 4096 Aug 25 13:20 .
drwxr-xr-x 3 root  root  4096 Aug 25 08:00 ..
drwxr-xr-x 2 ozben ozben 4096 Aug 25 13:10 isg
drwxr-xr-x 2 ozben ozben 4096 Aug 25 10:30 config
drwxr-xr-x 2 ozben ozben 4096 Aug 25 09:15 notes
drwxr-xr-x 2 ozben ozben 4096 Aug 25 08:50 scripts
drwxr-xr-x 2 ozben ozben 4096 Aug 25 08:20 docs
-rw-r--r-- 1 ozben ozben 2840 Aug 25 13:10 fine_kinney_calculator.py
-rw-r--r-- 1 ozben ozben 1950 Aug 25 12:45 saha_denetim_kontrol.json
-rw-r--r-- 1 ozben ozben 1120 Aug 25 10:30 devos_env.sh
-rw-r--r-- 1 ozben ozben 3400 Aug 25 09:15 mevzuat_ozetleri.md
""".trimIndent(),
                isError = false,
                timestamp = "13:19:05"
            )
        }
    )
}

