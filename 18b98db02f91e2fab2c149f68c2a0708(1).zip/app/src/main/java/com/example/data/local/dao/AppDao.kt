package com.example.data.local.dao

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Transaction
import androidx.room.Update
import com.example.data.local.entity.AiTutorCacheEntity
import com.example.data.local.entity.CachedAiTutorResponseAndUserData
import com.example.data.local.entity.CourseProgressEntity
import com.example.data.local.entity.ChatMessageEntity
import com.example.data.local.entity.IsgQuizHistoryEntity
import com.example.data.local.entity.SavedPromptEntity
import com.example.data.local.entity.SavedSnippetEntity
import com.example.data.local.entity.TestHistoryEntity
import com.example.data.local.entity.UserDataEntity
import com.example.data.local.entity.UserWithCachedAiResponses
import kotlinx.coroutines.flow.Flow

@Dao
interface PromptDao {
    @Query("SELECT * FROM saved_prompts ORDER BY timestamp DESC")
    fun getAllPrompts(): Flow<List<SavedPromptEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPrompt(prompt: SavedPromptEntity): Long

    @Delete
    suspend fun deletePrompt(prompt: SavedPromptEntity)

    @Update
    suspend fun updatePrompt(prompt: SavedPromptEntity)
}

@Dao
interface ChatDao {
    @Query("SELECT * FROM chat_messages ORDER BY timestamp ASC")
    fun getAllMessages(): Flow<List<ChatMessageEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertMessage(message: ChatMessageEntity): Long

    @Query("DELETE FROM chat_messages")
    suspend fun clearHistory()
}

@Dao
interface SnippetDao {
    @Query("SELECT * FROM saved_snippets ORDER BY timestamp DESC")
    fun getAllSnippets(): Flow<List<SavedSnippetEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSnippet(snippet: SavedSnippetEntity): Long

    @Delete
    suspend fun deleteSnippet(snippet: SavedSnippetEntity)
}

@Dao
interface TestDao {
    @Query("SELECT * FROM test_history ORDER BY timestamp DESC LIMIT 20")
    fun getRecentTestRuns(): Flow<List<TestHistoryEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTestRun(testRun: TestHistoryEntity): Long
}

@Dao
interface IsgQuizDao {
    @Query("SELECT * FROM isg_quiz_history ORDER BY timestamp DESC")
    fun getAllQuizHistory(): Flow<List<IsgQuizHistoryEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertQuizHistory(history: IsgQuizHistoryEntity): Long

    @Delete
    suspend fun deleteQuizHistory(history: IsgQuizHistoryEntity)

    @Query("DELETE FROM isg_quiz_history")
    suspend fun clearAllQuizHistory()
}

@Dao
interface CourseProgressDao {
    @Query("SELECT * FROM course_progress ORDER BY lastAccessedTimestamp DESC")
    fun getAllProgress(): Flow<List<CourseProgressEntity>>

    @Query("SELECT * FROM course_progress WHERE courseId = :courseId LIMIT 1")
    suspend fun getProgressForCourse(courseId: String): CourseProgressEntity?

    @Query("SELECT * FROM course_progress WHERE courseId = :courseId LIMIT 1")
    fun observeProgressForCourse(courseId: String): Flow<CourseProgressEntity?>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertOrUpdateProgress(progress: CourseProgressEntity)

    @Query("UPDATE course_progress SET isCompleted = :isCompleted, progressPercentage = :progressPercentage, completedHours = :completedHours, lastAccessedTimestamp = :timestamp WHERE courseId = :courseId")
    suspend fun updateCourseStatus(courseId: String, isCompleted: Boolean, progressPercentage: Int, completedHours: Double, timestamp: Long = System.currentTimeMillis())

    @Query("UPDATE course_progress SET progressPercentage = :progressPercentage, completedSyllabusItems = :syllabusItems, completedHours = :completedHours, isCompleted = :isCompleted, lastAccessedTimestamp = :timestamp WHERE courseId = :courseId")
    suspend fun updateSyllabusProgress(courseId: String, progressPercentage: Int, syllabusItems: String, completedHours: Double, isCompleted: Boolean, timestamp: Long = System.currentTimeMillis())

    @Query("DELETE FROM course_progress WHERE courseId = :courseId")
    suspend fun deleteProgress(courseId: String)

    @Query("DELETE FROM course_progress")
    suspend fun resetAllProgress()
}

@Dao
interface AiTutorDao {
    @Query("SELECT * FROM ai_tutor_cache ORDER BY timestamp DESC")
    fun getAllCachedResponses(): Flow<List<AiTutorCacheEntity>>

    @Query("SELECT * FROM ai_tutor_cache WHERE category = :category ORDER BY timestamp DESC")
    fun getCachedResponsesByCategory(category: String): Flow<List<AiTutorCacheEntity>>

    @Query("SELECT * FROM ai_tutor_cache WHERE promptQuery LIKE '%' || :query || '%' OR responseMarkdown LIKE '%' || :query || '%' ORDER BY timestamp DESC")
    fun searchCachedResponses(query: String): Flow<List<AiTutorCacheEntity>>

    @Query("SELECT * FROM ai_tutor_cache WHERE isFavorite = 1 ORDER BY timestamp DESC")
    fun getFavoriteResponses(): Flow<List<AiTutorCacheEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertCachedResponse(response: AiTutorCacheEntity): Long

    @Delete
    suspend fun deleteCachedResponse(response: AiTutorCacheEntity)

    @Query("DELETE FROM ai_tutor_cache WHERE timestamp < :olderThanTimestamp")
    suspend fun pruneOldCache(olderThanTimestamp: Long)

    @Query("DELETE FROM ai_tutor_cache")
    suspend fun clearAllCache()
}

@Dao
interface UserDataDao {
    @Query("SELECT * FROM user_data WHERE userId = :userId LIMIT 1")
    fun observeUserData(userId: String): Flow<UserDataEntity?>

    @Query("SELECT * FROM user_data WHERE userId = :userId LIMIT 1")
    suspend fun getUserData(userId: String): UserDataEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertOrUpdateUserData(userData: UserDataEntity)

    @Query("UPDATE user_data SET completedLessonsCount = :count, lastSyncTimestamp = :timestamp WHERE userId = :userId")
    suspend fun updateLessonCount(userId: String, count: Int, timestamp: Long = System.currentTimeMillis())

    @Query("DELETE FROM user_data WHERE userId = :userId")
    suspend fun deleteUserData(userId: String)

    @Transaction
    @Query("SELECT * FROM user_data WHERE userId = :userId LIMIT 1")
    fun getUserWithCachedResponses(userId: String): Flow<UserWithCachedAiResponses?>
}

@Dao
interface CachedAiTutorUserDataDao {
    @Query("SELECT * FROM cached_ai_tutor_responses_and_user_data ORDER BY timestamp DESC")
    fun getAll(): Flow<List<CachedAiTutorResponseAndUserData>>

    @Query("SELECT * FROM cached_ai_tutor_responses_and_user_data WHERE userId = :userId ORDER BY timestamp DESC")
    fun getByUserId(userId: String): Flow<List<CachedAiTutorResponseAndUserData>>

    @Query("SELECT * FROM cached_ai_tutor_responses_and_user_data WHERE promptQuery LIKE '%' || :query || '%' OR responseMarkdown LIKE '%' || :query || '%' ORDER BY timestamp DESC")
    fun searchCache(query: String): Flow<List<CachedAiTutorResponseAndUserData>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(item: CachedAiTutorResponseAndUserData): Long

    @Delete
    suspend fun delete(item: CachedAiTutorResponseAndUserData)

    @Query("DELETE FROM cached_ai_tutor_responses_and_user_data WHERE userId = :userId")
    suspend fun deleteByUserId(userId: String)

    @Query("DELETE FROM cached_ai_tutor_responses_and_user_data")
    suspend fun clearAll()
}


