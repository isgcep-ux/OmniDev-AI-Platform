package com.example.data.repository

import com.example.data.remote.GeminiApiService

class GeminiRepository(private val apiService: GeminiApiService) {

    suspend fun generateText(
        prompt: String,
        systemInstruction: String = "",
        model: String = "gemini-3.5-flash",
        temperature: Float = 0.7f,
        isJsonMode: Boolean = false
    ): Pair<String, Boolean> {
        val result = apiService.generateContent(
            prompt = prompt,
            systemInstruction = systemInstruction,
            model = model,
            temperature = temperature,
            isJsonMode = isJsonMode
        )

        return if (result.isSuccess) {
            Pair(result.getOrNull() ?: "No response", true)
        } else {
            // Intelligent fallback with rich context for Project IDX / AI Studio knowledge
            val fallbackText = generateOfflineFallback(prompt, systemInstruction, model)
            Pair(fallbackText, false)
        }
    }

    private fun generateOfflineFallback(prompt: String, systemInstruction: String, model: String): String {
        val lowerPrompt = prompt.lowercase()
        return when {
            lowerPrompt.contains("flutter") || lowerPrompt.contains("wasm") || lowerPrompt.contains("dart") -> """
### 🚀 Flutter on Project IDX Architecture Guide

**Key Advantages:**
1. **WebAssembly (WasmGC) Acceleration**: Up to 2x faster load and smooth 60fps rendering in modern Chromium browsers.
2. **Multi-Platform Single Codebase**: Build Android, iOS, Web, and Desktop from one unified project structure.
3. **Hot Reload in Cloud Workspaces**: Project IDX provisions instant dev containers with Flutter SDK pre-installed.

```dart
// Example Flutter Web WASM entrypoint
void main() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const DevStudioApp());
}
```

*Note: For live API synthesis, provide a Gemini API Key in the Secrets panel.*
            """.trimIndent()

            lowerPrompt.contains("next") || lowerPrompt.contains("react") || lowerPrompt.contains("server action") -> """
### ⚡ Next.js 15 & Project IDX Workflow

**Modern Best Practices:**
1. **App Router & React Server Components (RSC)**: Keep database calls on the server for zero client-bundle overhead.
2. **Server Actions**: Seamless mutation without separate API controllers.
3. **Cloud Run / Vercel Deployments**: One-click preview links directly generated from the IDX environment.

```typescript
'use server';
export async function handleProjectCreate(data: FormData) {
  const name = data.get('projectName');
  // Secure Cloud SQL / Firestore transaction
  return { success: true, name };
}
```
            """.trimIndent()

            lowerPrompt.contains("firebase") || lowerPrompt.contains("firestore") || lowerPrompt.contains("rule") -> """
### 🔥 Firebase Backend Integration

**Security Rule Essentials:**
```javascript
rules_version = '2';
service cloud.firestore {
  match /databases/{database}/documents {
    match /users/{userId} {
      allow read, write: if request.auth != null && request.auth.uid == userId;
    }
  }
}
```
**Cloud Functions 2nd Gen**: Powered by Google Cloud Run with concurrency and min-instances for zero cold-starts.
            """.trimIndent()

            lowerPrompt.contains("deploy") || lowerPrompt.contains("cloud run") || lowerPrompt.contains("docker") -> """
### ☁️ Cloud Deployment Strategies

1. **Firebase Hosting**: Ideal for Flutter Web WASM assets with global edge CDN caching.
2. **Google Cloud Run**: Ideal for containerized Next.js SSR / Node.js backends with auto-scaling to zero.
3. **Artifact Registry**: Secure multi-region container storage for Google Cloud builds.
            """.trimIndent()

            else -> """
### 🌟 Project IDX & Gemini AI Studio Intelligence

Here is a recommendation tailored to your request:
- **Architecture**: Decouple client-side interactive state from server-side data loaders.
- **Model Recommendation**: Use `${model}` for low latency and high context efficiency (1M+ tokens).
- **Security**: Never expose API keys or service accounts on client devices; leverage Cloud Secret Manager or Server Actions.

```kotlin
// Android Compose Gemini Integration
val response = geminiRepository.generateText(
    prompt = "$prompt",
    model = "$model"
)
```
*(Tip: Configure your Gemini API key in Secrets panel for live online reasoning).*
            """.trimIndent()
        }
    }
}
