package com.example.data.remote.elevenlabs

import com.squareup.moshi.Json
import com.squareup.moshi.JsonClass

/**
 * Text-to-Speech request body sent to ElevenLabs API:
 * POST /v1/text-to-speech/{voice_id}
 */
@JsonClass(generateAdapter = true)
data class ElevenLabsTtsRequest(
    @Json(name = "text")
    val text: String,
    @Json(name = "model_id")
    val modelId: String = "eleven_multilingual_v2",
    @Json(name = "voice_settings")
    val voiceSettings: VoiceSettings? = null,
    @Json(name = "pronunciation_dictionary_locators")
    val pronunciationDictionaryLocators: List<PronunciationDictionaryLocator>? = null,
    @Json(name = "seed")
    val seed: Int? = null,
    @Json(name = "previous_text")
    val previousText: String? = null,
    @Json(name = "next_text")
    val nextText: String? = null,
    @Json(name = "previous_request_ids")
    val previousRequestIds: List<String>? = null,
    @Json(name = "next_request_ids")
    val nextRequestIds: List<String>? = null
)

@JsonClass(generateAdapter = true)
data class VoiceSettings(
    @Json(name = "stability")
    val stability: Float = 0.75f,
    @Json(name = "similarity_boost")
    val similarityBoost: Float = 0.85f,
    @Json(name = "style")
    val style: Float = 0.0f,
    @Json(name = "use_speaker_boost")
    val useSpeakerBoost: Boolean = true
)

@JsonClass(generateAdapter = true)
data class PronunciationDictionaryLocator(
    @Json(name = "pronunciation_dictionary_id")
    val pronunciationDictionaryId: String,
    @Json(name = "version_id")
    val versionId: String
)

@JsonClass(generateAdapter = true)
data class ElevenLabsVoicesResponse(
    @Json(name = "voices")
    val voices: List<ElevenLabsVoice> = emptyList()
)

@JsonClass(generateAdapter = true)
data class ElevenLabsVoice(
    @Json(name = "voice_id")
    val voiceId: String,
    @Json(name = "name")
    val name: String,
    @Json(name = "category")
    val category: String? = null,
    @Json(name = "description")
    val description: String? = null,
    @Json(name = "preview_url")
    val previewUrl: String? = null,
    @Json(name = "labels")
    val labels: Map<String, String>? = null,
    @Json(name = "settings")
    val settings: VoiceSettings? = null
)

@JsonClass(generateAdapter = true)
data class ElevenLabsModel(
    @Json(name = "model_id")
    val modelId: String,
    @Json(name = "name")
    val name: String,
    @Json(name = "description")
    val description: String? = null,
    @Json(name = "languages")
    val languages: List<ElevenLabsLanguage>? = null
)

@JsonClass(generateAdapter = true)
data class ElevenLabsLanguage(
    @Json(name = "language_id")
    val languageId: String,
    @Json(name = "name")
    val name: String
)

@JsonClass(generateAdapter = true)
data class ElevenLabsUserSubscription(
    @Json(name = "tier")
    val tier: String? = null,
    @Json(name = "character_count")
    val characterCount: Int = 0,
    @Json(name = "character_limit")
    val characterLimit: Int = 10000,
    @Json(name = "status")
    val status: String? = null
)

@JsonClass(generateAdapter = true)
data class ElevenLabsApiError(
    @Json(name = "detail")
    val detail: ElevenLabsErrorDetail? = null
)

@JsonClass(generateAdapter = true)
data class ElevenLabsErrorDetail(
    @Json(name = "status")
    val status: String? = null,
    @Json(name = "message")
    val message: String? = null
)
