package com.example.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import com.example.data.local.dao.AiTutorDao
import com.example.data.local.dao.CachedAiTutorUserDataDao
import com.example.data.local.dao.ChatDao
import com.example.data.local.dao.CourseProgressDao
import com.example.data.local.dao.IsgQuizDao
import com.example.data.local.dao.PromptDao
import com.example.data.local.dao.SnippetDao
import com.example.data.local.dao.TestDao
import com.example.data.local.dao.UserDataDao
import com.example.data.local.entity.AiTutorCacheEntity
import com.example.data.local.entity.CachedAiTutorResponseAndUserData
import com.example.data.local.entity.ChatMessageEntity
import com.example.data.local.entity.CourseProgressEntity
import com.example.data.local.entity.IsgQuizHistoryEntity
import com.example.data.local.entity.SavedPromptEntity
import com.example.data.local.entity.SavedSnippetEntity
import com.example.data.local.entity.TestHistoryEntity
import com.example.data.local.entity.UserDataEntity

@Database(
    entities = [
        SavedPromptEntity::class,
        ChatMessageEntity::class,
        SavedSnippetEntity::class,
        TestHistoryEntity::class,
        IsgQuizHistoryEntity::class,
        CourseProgressEntity::class,
        AiTutorCacheEntity::class,
        UserDataEntity::class,
        CachedAiTutorResponseAndUserData::class
    ],
    version = 5,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun promptDao(): PromptDao
    abstract fun chatDao(): ChatDao
    abstract fun snippetDao(): SnippetDao
    abstract fun testDao(): TestDao
    abstract fun isgQuizDao(): IsgQuizDao
    abstract fun courseProgressDao(): CourseProgressDao
    abstract fun aiTutorDao(): AiTutorDao
    abstract fun userDataDao(): UserDataDao
    abstract fun cachedAiTutorUserDataDao(): CachedAiTutorUserDataDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getInstance(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "idx_studio_database.db"
                ).fallbackToDestructiveMigration().build()
                INSTANCE = instance
                instance
            }
        }
    }
}
