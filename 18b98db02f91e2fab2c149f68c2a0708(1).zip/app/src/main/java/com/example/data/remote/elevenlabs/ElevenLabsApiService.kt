package com.example.data.remote.elevenlabs

import okhttp3.ResponseBody
import retrofit2.Response
import retrofit2.http.*

/**
 * Retrofit interface defining ElevenLabs API endpoints
 * Base URL: https://api.elevenlabs.io/
 */
interface ElevenLabsApiService {

    /**
     * Converts text into speech using a specified voice ID.
     * Returns binary audio stream (MP3/WAV/etc.).
     */
    @Headers("Accept: audio/mpeg")
    @POST("v1/text-to-speech/{voice_id}")
    @Streaming
    suspend fun textToSpeech(
        @Path("voice_id") voiceId: String,
        @Body request: ElevenLabsTtsRequest,
        @Query("output_format") outputFormat: String? = null,
        @Query("optimize_streaming_latency") optimizeStreamingLatency: Int? = null
    ): Response<ResponseBody>

    /**
     * Converts text into speech stream using a specified voice ID.
     */
    @Headers("Accept: audio/mpeg")
    @POST("v1/text-to-speech/{voice_id}/stream")
    @Streaming
    suspend fun textToSpeechStream(
        @Path("voice_id") voiceId: String,
        @Body request: ElevenLabsTtsRequest,
        @Query("output_format") outputFormat: String? = null,
        @Query("optimize_streaming_latency") optimizeStreamingLatency: Int? = null
    ): Response<ResponseBody>

    /**
     * Retrieves all available voices (cloned and pre-made).
     */
    @GET("v1/voices")
    suspend fun getVoices(): Response<ElevenLabsVoicesResponse>

    /**
     * Retrieves information about a specific voice.
     */
    @GET("v1/voices/{voice_id}")
    suspend fun getVoice(
        @Path("voice_id") voiceId: String,
        @Query("with_settings") withSettings: Boolean = true
    ): Response<ElevenLabsVoice>

    /**
     * Retrieves all available models.
     */
    @GET("v1/models")
    suspend fun getModels(): Response<List<ElevenLabsModel>>

    /**
     * Retrieves user subscription info (character quota and tier).
     */
    @GET("v1/user/subscription")
    suspend fun getUserSubscription(): Response<ElevenLabsUserSubscription>
}
