package com.example.data.remote

import com.squareup.moshi.Json
import com.squareup.moshi.JsonClass

@JsonClass(generateAdapter = true)
data class GeminiRequest(
    val contents: List<ContentPayload>,
    @Json(name = "generationConfig") val generationConfig: GenerationConfigPayload? = null,
    @Json(name = "systemInstruction") val systemInstruction: ContentPayload? = null
)

@JsonClass(generateAdapter = true)
data class ContentPayload(
    val role: String? = null,
    val parts: List<PartPayload>
)

@JsonClass(generateAdapter = true)
data class PartPayload(
    val text: String? = null
)

@JsonClass(generateAdapter = true)
data class GenerationConfigPayload(
    val temperature: Float? = null,
    val topP: Float? = null,
    val topK: Int? = null,
    val maxOutputTokens: Int? = null,
    val responseMimeType: String? = null
)

@JsonClass(generateAdapter = true)
data class GeminiResponse(
    val candidates: List<CandidatePayload>? = null,
    val error: GeminiErrorPayload? = null
)

@JsonClass(generateAdapter = true)
data class CandidatePayload(
    val content: ContentPayload? = null,
    val finishReason: String? = null
)

@JsonClass(generateAdapter = true)
data class GeminiErrorPayload(
    val code: Int? = null,
    val message: String? = null,
    val status: String? = null
)
