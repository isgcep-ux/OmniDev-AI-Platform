package com.example.data.local.entity

import androidx.room.Embedded
import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey
import androidx.room.Relation

@Entity(tableName = "saved_prompts")
data class SavedPromptEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val title: String,
    val promptText: String,
    val systemInstruction: String = "",
    val model: String = "gemini-3.5-flash",
    val category: String = "Engineering",
    val isFavorite: Boolean = false,
    val timestamp: Long = System.currentTimeMillis()
)

@Entity(tableName = "chat_messages")
data class ChatMessageEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val sender: String, // "user" or "ai"
    val text: String,
    val codeSnippet: String = "",
    val codeLanguage: String = "",
    val timestamp: Long = System.currentTimeMillis(),
    val isAi: Boolean = false
)

@Entity(tableName = "saved_snippets")
data class SavedSnippetEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val title: String,
    val stack: String, // "Flutter", "Next.js", "Firebase", "Gemini", "Database"
    val language: String, // "dart", "typescript", "kotlin", "sql", "json"
    val code: String,
    val description: String = "",
    val timestamp: Long = System.currentTimeMillis()
)

@Entity(tableName = "test_history")
data class TestHistoryEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val suiteName: String,
    val framework: String, // "Flutter", "Jest/Next.js", "Firebase Emulators"
    val totalTests: Int,
    val passedTests: Int,
    val failedTests: Int,
    val durationMs: Long,
    val timestamp: Long = System.currentTimeMillis()
)

@Entity(tableName = "isg_quiz_history")
data class IsgQuizHistoryEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val examCategory: String, // "A Sınıfı İGU", "B Sınıfı İGU", "C Sınıfı İGU", "İşyeri Hekimliği", "DSP", "6331 Kanun & Mevzuat"
    val totalQuestions: Int,
    val correctAnswers: Int,
    val scorePercentage: Double,
    val difficulty: String = "ÖSYM Formatı",
    val sourceDomain: String = "isgcepakademi.com.tr", // "isgcepakademi.com", "isgcepakademi.com.tr", "isgcepakademi.xyz"
    val notes: String = "",
    val timestamp: Long = System.currentTimeMillis()
)

@Entity(tableName = "course_progress")
data class CourseProgressEntity(
    @PrimaryKey val courseId: String,
    val courseTitle: String,
    val category: String,
    val isCompleted: Boolean = false,
    val progressPercentage: Int = 0, // 0 - 100
    val completedSyllabusItems: String = "", // Comma-separated or serialized indices/names
    val completedHours: Double = 0.0,
    val totalHours: Int = 0,
    val lastAccessedTimestamp: Long = System.currentTimeMillis()
)

@Entity(
    tableName = "ai_tutor_cache",
    indices = [
        Index(value = ["userId"]),
        Index(value = ["category"]),
        Index(value = ["timestamp"])
    ]
)
data class AiTutorCacheEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val userId: String = "default_user",
    val promptQuery: String,
    val responseMarkdown: String,
    val category: String = "Genel İSG",
    val moduleCode: String = "",
    val legalArticleReferences: String = "",
    val timestamp: Long = System.currentTimeMillis(),
    val isFavorite: Boolean = false
)

@Entity(tableName = "user_data")
data class UserDataEntity(
    @PrimaryKey val userId: String,
    val displayName: String = "",
    val email: String = "",
    val role: String = "İSG Uzmanı",
    val completedLessonsCount: Int = 0,
    val totalExamScoreAvg: Double = 0.0,
    val preferencesJson: String = "{}",
    val lastSyncTimestamp: Long = System.currentTimeMillis()
)

/**
 * Room Entity schema defining the table for caching AI tutor responses together with user data.
 */
@Entity(
    tableName = "cached_ai_tutor_responses_and_user_data",
    indices = [
        Index(value = ["userId"]),
        Index(value = ["promptQuery"]),
        Index(value = ["timestamp"])
    ]
)
data class CachedAiTutorResponseAndUserData(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val userId: String = "default_user",
    val userName: String = "",
    val userEmail: String = "",
    val userRole: String = "İSG Uzmanı",
    val completedLessonsCount: Int = 0,
    val totalExamScoreAvg: Double = 0.0,
    val promptQuery: String,
    val responseMarkdown: String,
    val category: String = "Genel İSG",
    val moduleCode: String = "",
    val legalArticleReferences: String = "",
    val confidenceScore: Double = 0.95,
    val isFavorite: Boolean = false,
    val userNotes: String = "",
    val timestamp: Long = System.currentTimeMillis()
)

typealias AiTutorUserDataCacheEntity = CachedAiTutorResponseAndUserData
typealias AiTutorResponseAndUserData = CachedAiTutorResponseAndUserData
typealias CachedAiTutorUserData = CachedAiTutorResponseAndUserData
typealias AiTutorResponseCacheEntity = CachedAiTutorResponseAndUserData

/**
 * Composite Room relationship schema combining UserDataEntity with their cached AI tutor responses.
 */
data class UserWithCachedAiResponses(
    @Embedded val user: UserDataEntity,
    @Relation(
        parentColumn = "userId",
        entityColumn = "userId"
    )
    val cachedResponses: List<AiTutorCacheEntity> = emptyList()
)

typealias UserWithCachedAiTutorResponses = UserWithCachedAiResponses

