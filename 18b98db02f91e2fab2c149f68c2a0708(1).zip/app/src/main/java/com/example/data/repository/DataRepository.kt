package com.example.data.repository

import android.content.Context
import com.example.data.local.AppDatabase
import com.example.data.local.entity.AiTutorCacheEntity
import com.example.data.local.entity.CachedAiTutorResponseAndUserData
import com.example.data.local.entity.ChatMessageEntity
import com.example.data.local.entity.SavedPromptEntity
import com.example.data.local.entity.SavedSnippetEntity
import com.example.data.local.entity.UserDataEntity
import com.example.data.local.entity.UserWithCachedAiResponses
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.SetOptions
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withContext

/**
 * DataRepository handles both local SQLite/Room persistence and remote
 * Cloud Firestore synchronization for developer workspaces and user records.
 */
class DataRepository(
    private val context: Context,
    private val firestore: FirebaseFirestore = FirebaseFirestore.getInstance()
) {
    private val database = AppDatabase.getInstance(context)
    private val promptDao = database.promptDao()
    private val chatDao = database.chatDao()
    private val snippetDao = database.snippetDao()
    private val aiTutorDao = database.aiTutorDao()
    private val userDataDao = database.userDataDao()
    private val cachedAiTutorUserDataDao = database.cachedAiTutorUserDataDao()

    // ==========================================
    // LOCAL ROOM DATA ACCESS
    // ==========================================

    fun getLocalPrompts(): Flow<List<SavedPromptEntity>> = promptDao.getAllPrompts()

    suspend fun saveLocalPrompt(prompt: SavedPromptEntity) = withContext(Dispatchers.IO) {
        promptDao.insertPrompt(prompt)
    }

    suspend fun deleteLocalPrompt(prompt: SavedPromptEntity) = withContext(Dispatchers.IO) {
        promptDao.deletePrompt(prompt)
    }

    fun getLocalChatMessages(): Flow<List<ChatMessageEntity>> = chatDao.getAllMessages()

    suspend fun saveLocalChatMessage(message: ChatMessageEntity) = withContext(Dispatchers.IO) {
        chatDao.insertMessage(message)
    }

    fun getLocalSnippets(): Flow<List<SavedSnippetEntity>> = snippetDao.getAllSnippets()

    suspend fun saveLocalSnippet(snippet: SavedSnippetEntity) = withContext(Dispatchers.IO) {
        snippetDao.insertSnippet(snippet)
    }

    // ==========================================
    // AI TUTOR RESPONSE CACHE
    // ==========================================

    fun getAllCachedTutorResponses(): Flow<List<AiTutorCacheEntity>> =
        aiTutorDao.getAllCachedResponses()

    fun getCachedTutorResponsesByCategory(category: String): Flow<List<AiTutorCacheEntity>> =
        aiTutorDao.getCachedResponsesByCategory(category)

    fun searchCachedTutorResponses(query: String): Flow<List<AiTutorCacheEntity>> =
        aiTutorDao.searchCachedResponses(query)

    fun getFavoriteTutorResponses(): Flow<List<AiTutorCacheEntity>> =
        aiTutorDao.getFavoriteResponses()

    suspend fun cacheTutorResponse(response: AiTutorCacheEntity): Long = withContext(Dispatchers.IO) {
        aiTutorDao.insertCachedResponse(response)
    }

    suspend fun deleteCachedTutorResponse(response: AiTutorCacheEntity) = withContext(Dispatchers.IO) {
        aiTutorDao.deleteCachedResponse(response)
    }

    suspend fun clearTutorResponseCache() = withContext(Dispatchers.IO) {
        aiTutorDao.clearAllCache()
    }

    // ==========================================
    // USER DATA PERSISTENCE
    // ==========================================

    fun observeUserData(userId: String): Flow<UserDataEntity?> =
        userDataDao.observeUserData(userId)

    suspend fun getUserData(userId: String): UserDataEntity? = withContext(Dispatchers.IO) {
        userDataDao.getUserData(userId)
    }

    suspend fun saveUserData(userData: UserDataEntity) = withContext(Dispatchers.IO) {
        userDataDao.insertOrUpdateUserData(userData)
    }

    suspend fun updateLessonCount(userId: String, count: Int) = withContext(Dispatchers.IO) {
        userDataDao.updateLessonCount(userId, count)
    }

    fun observeUserWithCachedResponses(userId: String): Flow<UserWithCachedAiResponses?> =
        userDataDao.getUserWithCachedResponses(userId)

    // ==========================================
    // COMBINED AI TUTOR & USER DATA CACHE
    // ==========================================

    fun getAllCachedAiTutorUserData(): Flow<List<CachedAiTutorResponseAndUserData>> =
        cachedAiTutorUserDataDao.getAll()

    fun getCachedAiTutorUserDataByUserId(userId: String): Flow<List<CachedAiTutorResponseAndUserData>> =
        cachedAiTutorUserDataDao.getByUserId(userId)

    fun searchCachedAiTutorUserData(query: String): Flow<List<CachedAiTutorResponseAndUserData>> =
        cachedAiTutorUserDataDao.searchCache(query)

    suspend fun saveCachedAiTutorUserData(item: CachedAiTutorResponseAndUserData): Long =
        withContext(Dispatchers.IO) {
            cachedAiTutorUserDataDao.insert(item)
        }

    suspend fun deleteCachedAiTutorUserData(item: CachedAiTutorResponseAndUserData) =
        withContext(Dispatchers.IO) {
            cachedAiTutorUserDataDao.delete(item)
        }

    suspend fun clearCachedAiTutorUserDataByUserId(userId: String) =
        withContext(Dispatchers.IO) {
            cachedAiTutorUserDataDao.deleteByUserId(userId)
        }

    suspend fun clearAllCachedAiTutorUserData() =
        withContext(Dispatchers.IO) {
            cachedAiTutorUserDataDao.clearAll()
        }

    // ==========================================
    // REMOTE FIRESTORE DATA ACCESS
    // ==========================================

    /**
     * Save or sync document data to Firestore remote collection.
     */
    suspend fun saveRemoteDocument(
        collectionPath: String,
        documentId: String,
        data: Map<String, Any>
    ): Result<Unit> = withContext(Dispatchers.IO) {
        try {
            firestore.collection(collectionPath)
                .document(documentId)
                .set(data, SetOptions.merge())
                .await()
            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    /**
     * Fetch document data from Firestore remote collection.
     */
    suspend fun getRemoteDocument(
        collectionPath: String,
        documentId: String
    ): Result<Map<String, Any>?> = withContext(Dispatchers.IO) {
        try {
            val snapshot = firestore.collection(collectionPath)
                .document(documentId)
                .get()
                .await()
            Result.success(snapshot.data)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    /**
     * Delete document from Firestore remote collection.
     */
    suspend fun deleteRemoteDocument(
        collectionPath: String,
        documentId: String
    ): Result<Unit> = withContext(Dispatchers.IO) {
        try {
            firestore.collection(collectionPath)
                .document(documentId)
                .delete()
                .await()
            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }
}
