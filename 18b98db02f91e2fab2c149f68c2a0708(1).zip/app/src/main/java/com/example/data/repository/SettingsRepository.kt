package com.example.data.repository

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.emptyPreferences
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.map
import java.io.IOException

// Extension property for DataStore instance
private val Context.dataStore: DataStore<Preferences> by preferencesDataStore(name = "user_settings")

/**
 * Supported Theme Modes
 */
enum class AppThemeMode {
    SYSTEM,
    LIGHT,
    DARK
}

/**
 * Data class representing user preference state
 */
data class UserSettings(
    val themeMode: AppThemeMode = AppThemeMode.SYSTEM,
    val autoSaveEnabled: Boolean = true,
    val codeWrapEnabled: Boolean = true,
    val devTerminalSoundEnabled: Boolean = false,
    val autoSyncCloud: Boolean = false
)

/**
 * SettingsRepository manages persistent user configuration using Jetpack DataStore Preferences.
 */
class SettingsRepository(private val context: Context) {

    private object PreferenceKeys {
        val THEME_MODE = stringPreferencesKey("theme_mode")
        val AUTO_SAVE = booleanPreferencesKey("auto_save_enabled")
        val CODE_WRAP = booleanPreferencesKey("code_wrap_enabled")
        val TERMINAL_SOUND = booleanPreferencesKey("terminal_sound_enabled")
        val AUTO_SYNC_CLOUD = booleanPreferencesKey("auto_sync_cloud")
    }

    /**
     * Flow of combined user settings
     */
    val userSettingsFlow: Flow<UserSettings> = context.dataStore.data
        .catch { exception ->
            if (exception is IOException) {
                emit(emptyPreferences())
            } else {
                throw exception
            }
        }
        .map { preferences ->
            val themeString = preferences[PreferenceKeys.THEME_MODE] ?: AppThemeMode.SYSTEM.name
            val themeMode = try {
                AppThemeMode.valueOf(themeString)
            } catch (e: IllegalArgumentException) {
                AppThemeMode.SYSTEM
            }

            UserSettings(
                themeMode = themeMode,
                autoSaveEnabled = preferences[PreferenceKeys.AUTO_SAVE] ?: true,
                codeWrapEnabled = preferences[PreferenceKeys.CODE_WRAP] ?: true,
                devTerminalSoundEnabled = preferences[PreferenceKeys.TERMINAL_SOUND] ?: false,
                autoSyncCloud = preferences[PreferenceKeys.AUTO_SYNC_CLOUD] ?: false
            )
        }

    /**
     * Update Theme Mode (LIGHT, DARK, SYSTEM)
     */
    suspend fun setThemeMode(mode: AppThemeMode) {
        context.dataStore.edit { preferences ->
            preferences[PreferenceKeys.THEME_MODE] = mode.name
        }
    }

    /**
     * Toggle or set Auto-Save State
     */
    suspend fun setAutoSaveEnabled(enabled: Boolean) {
        context.dataStore.edit { preferences ->
            preferences[PreferenceKeys.AUTO_SAVE] = enabled
        }
    }

    /**
     * Toggle or set Code Wrapping preference in editor
     */
    suspend fun setCodeWrapEnabled(enabled: Boolean) {
        context.dataStore.edit { preferences ->
            preferences[PreferenceKeys.CODE_WRAP] = enabled
        }
    }

    /**
     * Toggle or set Terminal Audio Feedback
     */
    suspend fun setTerminalSoundEnabled(enabled: Boolean) {
        context.dataStore.edit { preferences ->
            preferences[PreferenceKeys.TERMINAL_SOUND] = enabled
        }
    }

    /**
     * Toggle or set Cloud Auto-Synchronization
     */
    suspend fun setAutoSyncCloud(enabled: Boolean) {
        context.dataStore.edit { preferences ->
            preferences[PreferenceKeys.AUTO_SYNC_CLOUD] = enabled
        }
    }
}
