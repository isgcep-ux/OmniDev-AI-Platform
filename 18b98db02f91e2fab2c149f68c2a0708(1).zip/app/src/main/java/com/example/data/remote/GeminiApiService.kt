package com.example.data.remote

import com.example.BuildConfig
import com.squareup.moshi.Moshi
import com.squareup.moshi.kotlin.reflect.KotlinJsonAdapterFactory
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import java.util.concurrent.TimeUnit

class GeminiApiService {

    private val moshi = Moshi.Builder()
        .add(KotlinJsonAdapterFactory())
        .build()

    private val requestAdapter = moshi.adapter(GeminiRequest::class.java)
    private val responseAdapter = moshi.adapter(GeminiResponse::class.java)

    private val client = OkHttpClient.Builder()
        .connectTimeout(60, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .writeTimeout(60, TimeUnit.SECONDS)
        .build()

    suspend fun generateContent(
        prompt: String,
        systemInstruction: String = "",
        model: String = "gemini-3.5-flash",
        temperature: Float = 0.7f,
        isJsonMode: Boolean = false
    ): Result<String> = withContext(Dispatchers.IO) {
        val apiKey = try {
            BuildConfig.GEMINI_API_KEY
        } catch (e: Throwable) {
            ""
        }

        if (apiKey.isBlank() || apiKey == "MY_GEMINI_API_KEY") {
            return@withContext Result.failure(
                IllegalStateException("API_KEY_UNSET")
            )
        }

        try {
            val parts = listOf(PartPayload(text = prompt))
            val contents = listOf(ContentPayload(role = "user", parts = parts))

            val systemContent = if (systemInstruction.isNotBlank()) {
                ContentPayload(parts = listOf(PartPayload(text = systemInstruction)))
            } else null

            val genConfig = GenerationConfigPayload(
                temperature = temperature,
                responseMimeType = if (isJsonMode) "application/json" else null
            )

            val requestPayload = GeminiRequest(
                contents = contents,
                generationConfig = genConfig,
                systemInstruction = systemContent
            )

            val jsonBody = requestAdapter.toJson(requestPayload)
            val mediaType = "application/json; charset=utf-8".toMediaType()
            val requestBody = jsonBody.toRequestBody(mediaType)

            val url = "https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent?key=$apiKey"

            val httpRequest = Request.Builder()
                .url(url)
                .post(requestBody)
                .build()

            val httpResponse = client.newCall(httpRequest).execute()
            val responseString = httpResponse.body?.string() ?: ""

            if (!httpResponse.isSuccessful) {
                return@withContext Result.failure(
                    Exception("HTTP ${httpResponse.code}: $responseString")
                )
            }

            val parsedResponse = responseAdapter.fromJson(responseString)
            val generatedText = parsedResponse?.candidates?.firstOrNull()?.content?.parts?.firstOrNull()?.text

            if (!generatedText.isNullOrBlank()) {
                Result.success(generatedText)
            } else {
                Result.failure(Exception("Empty candidate response from Gemini API"))
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }
}
