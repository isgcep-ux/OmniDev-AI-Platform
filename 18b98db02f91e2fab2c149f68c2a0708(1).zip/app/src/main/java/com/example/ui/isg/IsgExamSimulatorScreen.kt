package com.example.ui.isg

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.MenuBook
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.IsgExamQuestion
import com.example.ui.components.SectionHeader
import com.example.ui.theme.GeminiGreen
import com.example.ui.theme.GeminiPurple
import com.example.ui.theme.IdxBlue

@Composable
fun IsgExamSimulatorScreen(
    questions: List<IsgExamQuestion>,
    modifier: Modifier = Modifier
) {
    var selectedCategory by remember { mutableStateOf("Tümü") }
    val userAnswers = remember { mutableStateMapOf<String, Int>() }

    val categories = listOf("Tümü", "A Sınıfı İGU", "B Sınıfı İGU", "C Sınıfı İGU", "İşyeri Hekimliği", "Diğer Sağlık Personeli (DSP)")

    val filteredQuestions = remember(questions, selectedCategory) {
        if (selectedCategory == "Tümü") questions
        else questions.filter { it.examType == selectedCategory }
    }

    val answeredCount = userAnswers.size
    val correctCount = userAnswers.count { (qId, selectedIdx) ->
        val q = questions.find { it.id == qId }
        q?.correctIndex == selectedIdx
    }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp),
        contentPadding = PaddingValues(top = 16.dp, bottom = 32.dp)
    ) {
        item {
            SectionHeader(
                title = "İSG Sınav & Deneme Simülatörü",
                subtitle = "isgcepakademi.com.tr ÖSYM formatlı sınav soru motoru"
            )
        }

        // Score Card
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.4f)
                ),
                border = CardDefaults.outlinedCardBorder()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    horizontalArrangement = Arrangement.SpaceAround,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("Çözülen Soru", style = MaterialTheme.typography.labelMedium)
                        Text(
                            text = "$answeredCount / ${filteredQuestions.size}",
                            style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold)
                        )
                    }
                    VerticalDivider(
                        modifier = Modifier.height(36.dp),
                        color = MaterialTheme.colorScheme.outline.copy(alpha = 0.3f)
                    )
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("Doğru Sayısı", style = MaterialTheme.typography.labelMedium)
                        Text(
                            text = "$correctCount",
                            style = MaterialTheme.typography.titleLarge.copy(
                                fontWeight = FontWeight.Bold,
                                color = GeminiGreen
                            )
                        )
                    }
                    VerticalDivider(
                        modifier = Modifier.height(36.dp),
                        color = MaterialTheme.colorScheme.outline.copy(alpha = 0.3f)
                    )
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("Başarı Oranı", style = MaterialTheme.typography.labelMedium)
                        val rate = if (answeredCount > 0) (correctCount * 100 / answeredCount) else 0
                        Text(
                            text = "%$rate",
                            style = MaterialTheme.typography.titleLarge.copy(
                                fontWeight = FontWeight.Bold,
                                color = if (rate >= 70) GeminiGreen else MaterialTheme.colorScheme.primary
                            )
                        )
                    }
                }
            }
        }

        // Category Filter
        item {
            LazyRow(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                items(categories) { cat ->
                    val isSelected = selectedCategory == cat
                    FilterChip(
                        selected = isSelected,
                        onClick = { selectedCategory = cat },
                        label = { Text(cat, fontSize = 12.sp) },
                        leadingIcon = {
                            if (isSelected) {
                                Icon(Icons.Default.Check, contentDescription = null, modifier = Modifier.size(14.dp))
                            }
                        },
                        modifier = Modifier.testTag("exam_cat_$cat")
                    )
                }
            }
        }

        // Question Cards
        items(filteredQuestions, key = { it.id }) { q ->
            val selectedOption = userAnswers[q.id]
            val isAnswered = selectedOption != null
            val isCorrect = selectedOption == q.correctIndex

            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("exam_card_${q.id}"),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
                ),
                border = CardDefaults.outlinedCardBorder()
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    // Header: Topic & Exam Type
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Surface(
                            color = IdxBlue.copy(alpha = 0.15f),
                            shape = RoundedCornerShape(6.dp)
                        ) {
                            Text(
                                text = q.examType,
                                style = MaterialTheme.typography.labelSmall.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = IdxBlue
                                ),
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                            )
                        }
                        Text(
                            text = q.topic,
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }

                    // Question Text
                    Text(
                        text = q.question,
                        style = MaterialTheme.typography.bodyLarge.copy(fontWeight = FontWeight.Medium),
                        color = MaterialTheme.colorScheme.onSurface
                    )

                    // Options List
                    Column(
                        modifier = Modifier.fillMaxWidth(),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        q.options.forEachIndexed { index, optionText ->
                            val isThisSelected = selectedOption == index
                            val optionBg = when {
                                !isAnswered -> MaterialTheme.colorScheme.surface
                                index == q.correctIndex -> GeminiGreen.copy(alpha = 0.2f)
                                isThisSelected -> MaterialTheme.colorScheme.errorContainer.copy(alpha = 0.4f)
                                else -> MaterialTheme.colorScheme.surface.copy(alpha = 0.5f)
                            }
                            val optionBorder = when {
                                !isAnswered && isThisSelected -> MaterialTheme.colorScheme.primary
                                isAnswered && index == q.correctIndex -> GeminiGreen
                                isAnswered && isThisSelected -> MaterialTheme.colorScheme.error
                                else -> MaterialTheme.colorScheme.outline.copy(alpha = 0.2f)
                            }

                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(10.dp))
                                    .background(optionBg)
                                    .border(1.dp, optionBorder, RoundedCornerShape(10.dp))
                                    .clickable(enabled = !isAnswered) {
                                        userAnswers[q.id] = index
                                    }
                                    .padding(12.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(24.dp)
                                        .clip(CircleShape)
                                        .background(
                                            if (isAnswered && index == q.correctIndex) GeminiGreen
                                            else MaterialTheme.colorScheme.surfaceVariant
                                        ),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(
                                        text = ('A' + index).toString(),
                                        style = MaterialTheme.typography.labelSmall.copy(
                                            fontWeight = FontWeight.Bold,
                                            color = if (isAnswered && index == q.correctIndex) Color.White else MaterialTheme.colorScheme.onSurface
                                        )
                                    )
                                }
                                Text(
                                    text = optionText,
                                    style = MaterialTheme.typography.bodyMedium,
                                    modifier = Modifier.weight(1f)
                                )
                                if (isAnswered && index == q.correctIndex) {
                                    Icon(
                                        imageVector = Icons.Default.CheckCircle,
                                        contentDescription = "Doğru",
                                        tint = GeminiGreen,
                                        modifier = Modifier.size(18.dp)
                                    )
                                } else if (isAnswered && isThisSelected) {
                                    Icon(
                                        imageVector = Icons.Default.Cancel,
                                        contentDescription = "Yanlış",
                                        tint = MaterialTheme.colorScheme.error,
                                        modifier = Modifier.size(18.dp)
                                    )
                                }
                            }
                        }
                    }

                    // Explanation Box
                    AnimatedVisibility(visible = isAnswered) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(10.dp))
                                .background(MaterialTheme.colorScheme.surface)
                                .padding(12.dp),
                            verticalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.AutoMirrored.Filled.MenuBook,
                                    contentDescription = null,
                                    tint = GeminiPurple,
                                    modifier = Modifier.size(16.dp)
                                )
                                Text(
                                    text = "Mevzuat Dayanağı: ${q.legislationReference}",
                                    style = MaterialTheme.typography.labelMedium.copy(
                                        fontWeight = FontWeight.Bold,
                                        color = GeminiPurple
                                    )
                                )
                            }
                            Text(
                                text = q.explanation,
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
            }
        }
    }
}
