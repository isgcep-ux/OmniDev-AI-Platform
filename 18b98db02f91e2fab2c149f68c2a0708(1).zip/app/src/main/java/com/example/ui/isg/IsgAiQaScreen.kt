package com.example.ui.isg

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.MenuBook
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.local.entity.IsgQuizHistoryEntity
import com.example.model.IsgAiGeneratedQuestion
import com.example.ui.components.SectionHeader
import com.example.ui.components.StatCard
import com.example.ui.theme.*
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun IsgAiQaScreen(
    questions: List<IsgAiGeneratedQuestion>,
    quizHistory: List<IsgQuizHistoryEntity>,
    onGenerateAiQuestion: suspend (String, String, String) -> IsgAiGeneratedQuestion,
    onSaveQuizResult: (String, Int, Int, String, String, String) -> Unit,
    onDeleteQuizHistory: (IsgQuizHistoryEntity) -> Unit,
    onClearAllHistory: () -> Unit,
    modifier: Modifier = Modifier
) {
    val coroutineScope = rememberCoroutineScope()
    var activeSubTab by remember { mutableStateOf(0) } // 0: AI Soru Bankası & Test, 1: Room Sınav Geçmişi
    var selectedCategory by remember { mutableStateOf("Tümü") }
    var selectedDifficulty by remember { mutableStateOf("ÖSYM Çıkmış Formatı") }
    var selectedDomain by remember { mutableStateOf("isgcepakademi.com.tr") }
    var isGenerating by remember { mutableStateOf(false) }
    var saveSuccessMessage by remember { mutableStateOf<String?>(null) }

    val userAnswers = remember { mutableStateMapOf<String, Int>() }

    val categories = listOf(
        "Tümü",
        "6331 Sayılı İSG Kanunu",
        "A Sınıfı İGU",
        "B Sınıfı İGU",
        "C Sınıfı İGU",
        "İşyeri Hekimliği",
        "Risk Metodolojileri & Fine-Kinney",
        "KKD & Standartlar"
    )

    val difficulties = listOf("Temel Seviye", "Orta Düzey", "İleri / Uzmanlık", "ÖSYM Çıkmış Formatı")
    val domains = listOf("isgcepakademi.com", "isgcepakademi.com.tr", "isgcepakademi.xyz")

    val filteredQuestions = remember(questions, selectedCategory) {
        if (selectedCategory == "Tümü") questions
        else questions.filter { it.category == selectedCategory }
    }

    val answeredCount = userAnswers.size
    val correctCount = userAnswers.count { (qId, selectedIdx) ->
        val q = questions.find { it.id == qId }
        q?.correctIndex == selectedIdx
    }
    val scorePercentage = if (answeredCount > 0) (correctCount.toDouble() / answeredCount) * 100.0 else 0.0

    val dateFormat = remember { SimpleDateFormat("dd MMM yyyy, HH:mm", Locale("tr")) }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp),
        contentPadding = PaddingValues(top = 16.dp, bottom = 32.dp)
    ) {
        item {
            SectionHeader(
                title = "İSG AI Soru Bankası & Room Geçmişi",
                subtitle = "isgcepakademi.com, isgcepakademi.com.tr & .xyz yapay zekâ destekli mevzuat sınav modülü",
                badge = "Room + Gemini AI",
                badgeColor = GeminiPurple
            )
        }

        // SubTab Selector (AI Test vs Room History)
        item {
            PrimaryTabRow(
                selectedTabIndex = activeSubTab,
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(12.dp)),
                containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
            ) {
                Tab(
                    selected = activeSubTab == 0,
                    onClick = { activeSubTab = 0 },
                    text = {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            Icon(Icons.Default.AutoAwesome, contentDescription = null, modifier = Modifier.size(16.dp))
                            Text("AI Soru & Test Çöz", fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                        }
                    },
                    modifier = Modifier.testTag("tab_ai_quiz")
                )
                Tab(
                    selected = activeSubTab == 1,
                    onClick = { activeSubTab = 1 },
                    text = {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            Icon(Icons.Default.History, contentDescription = null, modifier = Modifier.size(16.dp))
                            Text("Room Sınav Geçmişi (${quizHistory.size})", fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                        }
                    },
                    modifier = Modifier.testTag("tab_quiz_history")
                )
            }
        }

        if (activeSubTab == 0) {
            // Stats Row
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    StatCard(
                        title = "Başarı Oranı",
                        value = if (answeredCount > 0) "%${scorePercentage.toInt()} ($correctCount/$answeredCount)" else "Başlanmadı",
                        icon = Icons.Default.EmojiEvents,
                        accentColor = if (scorePercentage >= 70) SuccessEmerald else GeminiPurple,
                        modifier = Modifier.weight(1f)
                    )
                    StatCard(
                        title = "Aktif AI Soruları",
                        value = "${filteredQuestions.size} Soru",
                        icon = Icons.Default.Psychology,
                        accentColor = IdxBlue,
                        modifier = Modifier.weight(1f)
                    )
                }
            }

            // AI Question Generator Controls
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f)),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.2f))
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "✨ Gemini AI ile Soru Üretici",
                                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                            )
                            Surface(
                                shape = RoundedCornerShape(6.dp),
                                color = GeminiPurple.copy(alpha = 0.15f)
                            ) {
                                Text(
                                    text = "6331 Uyumlu",
                                    color = GeminiPurple,
                                    style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(10.dp))
                        Text(
                            text = "Kaynak İSG Portalı & Müfredat:",
                            style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.SemiBold)
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            items(domains) { dom ->
                                FilterChip(
                                    selected = selectedDomain == dom,
                                    onClick = { selectedDomain = dom },
                                    label = { Text(dom, fontSize = 11.sp) },
                                    modifier = Modifier.testTag("filter_domain_$dom")
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(10.dp))
                        Text(
                            text = "Zorluk Derecesi:",
                            style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.SemiBold)
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            items(difficulties) { diff ->
                                FilterChip(
                                    selected = selectedDifficulty == diff,
                                    onClick = { selectedDifficulty = diff },
                                    label = { Text(diff, fontSize = 11.sp) },
                                    modifier = Modifier.testTag("filter_diff_$diff")
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(12.dp))
                        Button(
                            onClick = {
                                coroutineScope.launch {
                                    isGenerating = true
                                    val catToGenerate = if (selectedCategory == "Tümü") "6331 Sayılı İSG Kanunu" else selectedCategory
                                    onGenerateAiQuestion(catToGenerate, selectedDifficulty, selectedDomain)
                                    isGenerating = false
                                }
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = GeminiPurple),
                            enabled = !isGenerating,
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("btn_generate_ai_isg_question")
                        ) {
                            if (isGenerating) {
                                CircularProgressIndicator(modifier = Modifier.size(18.dp), color = Color.White, strokeWidth = 2.dp)
                                Spacer(modifier = Modifier.width(8.dp))
                                Text("AI Soru Üretiyor & Mevzuat Doğrulanıyor...")
                            } else {
                                Icon(Icons.Default.AutoAwesome, contentDescription = null, modifier = Modifier.size(18.dp))
                                Spacer(modifier = Modifier.width(8.dp))
                                Text("⚡ Yeni AI İSG Sorusu Üret ($selectedDomain)")
                            }
                        }
                    }
                }
            }

            // Category Filter
            item {
                Column {
                    Text(
                        text = "Konu & Sınav Kategorisi Filtresi:",
                        style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold),
                        modifier = Modifier.padding(bottom = 6.dp)
                    )
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        items(categories) { cat ->
                            FilterChip(
                                selected = selectedCategory == cat,
                                onClick = { selectedCategory = cat },
                                label = { Text(cat, fontSize = 12.sp) },
                                modifier = Modifier.testTag("filter_cat_$cat")
                            )
                        }
                    }
                }
            }

            // Save Quiz Results to Room Database action
            if (answeredCount > 0) {
                item {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.4f)),
                        shape = RoundedCornerShape(12.dp),
                        border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.3f))
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(12.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = "Sonuç: $correctCount / $answeredCount Doğru (%${scorePercentage.toInt()})",
                                    style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold)
                                )
                                Text(
                                    text = "Oturumu yerel SQLite/Room veritabanına kaydedin.",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                            Button(
                                onClick = {
                                    onSaveQuizResult(
                                        if (selectedCategory == "Tümü") "Genel İSG Karma Deneme" else selectedCategory,
                                        answeredCount,
                                        correctCount,
                                        selectedDifficulty,
                                        selectedDomain,
                                        "İSG Cep Akademi AI Sınav Oturumu"
                                    )
                                    saveSuccessMessage = "Sınav sonucu Room veritabanına kaydedildi!"
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = SuccessEmerald),
                                modifier = Modifier.testTag("btn_save_quiz_to_room")
                            ) {
                                Icon(Icons.Default.Save, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("Room'a Kaydet", fontSize = 12.sp)
                            }
                        }
                    }
                }
            }

            saveSuccessMessage?.let { msg ->
                item {
                    Surface(
                        color = SuccessEmerald.copy(alpha = 0.15f),
                        shape = RoundedCornerShape(8.dp),
                        border = BorderStroke(1.dp, SuccessEmerald),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier.padding(10.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.CheckCircle, contentDescription = null, tint = SuccessEmerald, modifier = Modifier.size(18.dp))
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(msg, color = SuccessEmerald, style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.SemiBold))
                            }
                            IconButton(onClick = { saveSuccessMessage = null }, modifier = Modifier.size(24.dp)) {
                                Icon(Icons.Default.Close, contentDescription = "Kapat", tint = SuccessEmerald, modifier = Modifier.size(16.dp))
                            }
                        }
                    }
                }
            }

            // Questions List
            items(filteredQuestions) { q ->
                val userAnswer = userAnswers[q.id]
                val isAnswered = userAnswer != null

                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.25f))
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                Surface(
                                    shape = RoundedCornerShape(4.dp),
                                    color = GeminiPurple.copy(alpha = 0.15f)
                                ) {
                                    Text(
                                        text = q.category,
                                        color = GeminiPurple,
                                        style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                    )
                                }
                                Surface(
                                    shape = RoundedCornerShape(4.dp),
                                    color = GeminiGreen.copy(alpha = 0.15f)
                                ) {
                                    Text(
                                        text = q.domain,
                                        color = GeminiGreen,
                                        style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.SemiBold),
                                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                    )
                                }
                            }

                            if (isAnswered) {
                                val isCorrect = userAnswer == q.correctIndex
                                Surface(
                                    shape = RoundedCornerShape(4.dp),
                                    color = if (isCorrect) SuccessEmerald.copy(alpha = 0.15f) else ErrorRose.copy(alpha = 0.15f)
                                ) {
                                    Text(
                                        text = if (isCorrect) "✓ DOĞRU" else "✗ YANLIŞ",
                                        color = if (isCorrect) SuccessEmerald else ErrorRose,
                                        style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                    )
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(10.dp))
                        Text(
                            text = q.topic,
                            style = MaterialTheme.typography.labelMedium.copy(color = MaterialTheme.colorScheme.onSurfaceVariant)
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = q.question,
                            style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.SemiBold, lineHeight = 22.sp)
                        )

                        Spacer(modifier = Modifier.height(14.dp))
                        q.options.forEachIndexed { index, option ->
                            val isSelected = userAnswer == index
                            val isCorrectChoice = isAnswered && index == q.correctIndex
                            val isWrongChoice = isAnswered && isSelected && index != q.correctIndex

                            Surface(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 4.dp)
                                    .clickable(enabled = !isAnswered) {
                                        userAnswers[q.id] = index
                                    }
                                    .testTag("isg_opt_${q.id}_$index"),
                                shape = RoundedCornerShape(10.dp),
                                color = when {
                                    isCorrectChoice -> SuccessEmerald.copy(alpha = 0.15f)
                                    isWrongChoice -> ErrorRose.copy(alpha = 0.15f)
                                    isSelected -> IdxBlue.copy(alpha = 0.15f)
                                    else -> MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
                                },
                                border = BorderStroke(
                                    1.dp,
                                    when {
                                        isCorrectChoice -> SuccessEmerald
                                        isWrongChoice -> ErrorRose
                                        isSelected -> IdxBlue
                                        else -> Color.Transparent
                                    }
                                )
                            ) {
                                Row(
                                    modifier = Modifier.padding(12.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    Box(
                                        modifier = Modifier
                                            .size(24.dp)
                                            .clip(CircleShape)
                                            .background(
                                                when {
                                                    isCorrectChoice -> SuccessEmerald
                                                    isWrongChoice -> ErrorRose
                                                    isSelected -> IdxBlue
                                                    else -> MaterialTheme.colorScheme.outline.copy(alpha = 0.2f)
                                                }
                                            ),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Text(
                                            text = "${('A' + index)}",
                                            style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                                            color = if (isSelected || isCorrectChoice || isWrongChoice) Color.White else MaterialTheme.colorScheme.onSurface
                                        )
                                    }
                                    Text(
                                        text = option,
                                        style = MaterialTheme.typography.bodyMedium,
                                        color = MaterialTheme.colorScheme.onSurface
                                    )
                                }
                            }
                        }

                        AnimatedVisibility(visible = isAnswered) {
                            Column(modifier = Modifier.padding(top = 12.dp)) {
                                Surface(
                                    shape = RoundedCornerShape(10.dp),
                                    color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.8f),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Column(modifier = Modifier.padding(14.dp)) {
                                        Row(verticalAlignment = Alignment.CenterVertically) {
                                            Icon(
                                                Icons.AutoMirrored.Filled.MenuBook,
                                                contentDescription = null,
                                                tint = GeminiPurple,
                                                modifier = Modifier.size(18.dp)
                                            )
                                            Spacer(modifier = Modifier.width(6.dp))
                                            Text(
                                                text = "Mevzuat Dayanağı & Açıklama:",
                                                style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold),
                                                color = GeminiPurple
                                            )
                                        }
                                        Spacer(modifier = Modifier.height(6.dp))
                                        Text(
                                            text = q.explanation,
                                            style = MaterialTheme.typography.bodySmall.copy(lineHeight = 18.sp)
                                        )
                                        Spacer(modifier = Modifier.height(4.dp))
                                        Text(
                                            text = "📌 Madde: ${q.legislationReference}",
                                            style = MaterialTheme.typography.labelSmall.copy(
                                                fontWeight = FontWeight.Bold,
                                                color = MaterialTheme.colorScheme.onSurfaceVariant
                                            )
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        } else {
            // Room Quiz History Tab
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "Room SQLite Sınav Geçmişi",
                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                        )
                        Text(
                            text = "Cihazda saklanan sınav oturumları ve başarı grafiği",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    if (quizHistory.isNotEmpty()) {
                        OutlinedButton(
                            onClick = onClearAllHistory,
                            colors = ButtonDefaults.outlinedButtonColors(contentColor = ErrorRose),
                            modifier = Modifier.testTag("btn_clear_quiz_history")
                        ) {
                            Icon(Icons.Default.DeleteSweep, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Tümünü Temizle", fontSize = 11.sp)
                        }
                    }
                }
            }

            if (quizHistory.isEmpty()) {
                item {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(32.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Icon(
                                Icons.Default.FolderOpen,
                                contentDescription = null,
                                modifier = Modifier.size(48.dp),
                                tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.5f)
                            )
                            Spacer(modifier = Modifier.height(12.dp))
                            Text(
                                text = "Henüz Kayıtlı Sınav Geçmişi Yok",
                                style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold)
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "'AI Soru & Test Çöz' sekmesinden soruları çözüp Room veritabanına kaydedebilirsiniz.",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
            } else {
                items(quizHistory) { item ->
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.25f))
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                    Surface(
                                        shape = RoundedCornerShape(4.dp),
                                        color = GeminiPurple.copy(alpha = 0.15f)
                                    ) {
                                        Text(
                                            text = item.examCategory,
                                            color = GeminiPurple,
                                            style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                        )
                                    }
                                    val domainColor = when {
                                        item.sourceDomain == "isgcepakademi.com" -> GeminiGreen
                                        item.sourceDomain.contains("xyz") -> GeminiPurple
                                        else -> IdxBlue
                                    }
                                    Surface(
                                        shape = RoundedCornerShape(4.dp),
                                        color = domainColor.copy(alpha = 0.15f)
                                    ) {
                                        Text(
                                            text = item.sourceDomain,
                                            color = domainColor,
                                            style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.SemiBold),
                                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                        )
                                    }
                                }

                                IconButton(
                                    onClick = { onDeleteQuizHistory(item) },
                                    modifier = Modifier
                                        .size(28.dp)
                                        .testTag("delete_history_${item.id}")
                                ) {
                                    Icon(
                                        Icons.Default.DeleteOutline,
                                        contentDescription = "Sil",
                                        tint = ErrorRose,
                                        modifier = Modifier.size(18.dp)
                                    )
                                }
                            }

                            Spacer(modifier = Modifier.height(10.dp))
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column {
                                    Text(
                                        text = "Skor: ${item.correctAnswers} / ${item.totalQuestions} Doğru",
                                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                                    )
                                    Text(
                                        text = "Zorluk: ${item.difficulty}",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }

                                Surface(
                                    shape = RoundedCornerShape(8.dp),
                                    color = if (item.scorePercentage >= 70) SuccessEmerald.copy(alpha = 0.15f) else ErrorRose.copy(alpha = 0.15f)
                                ) {
                                    Text(
                                        text = "%${item.scorePercentage.toInt()}",
                                        color = if (item.scorePercentage >= 70) SuccessEmerald else ErrorRose,
                                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace),
                                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                                    )
                                }
                            }

                            Spacer(modifier = Modifier.height(8.dp))
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = dateFormat.format(Date(item.timestamp)),
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                                Text(
                                    text = "Room ID: #${item.id}",
                                    style = MaterialTheme.typography.labelSmall.copy(fontFamily = FontFamily.Monospace),
                                    color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f)
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}
