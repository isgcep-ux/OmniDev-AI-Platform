package com.example.ui.idx

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.local.entity.TestHistoryEntity
import com.example.model.TestCase
import com.example.model.TestStatus
import com.example.ui.components.CodeViewerCard
import com.example.ui.components.SectionHeader
import com.example.ui.components.StatCard
import com.example.ui.theme.ErrorRose
import com.example.ui.theme.IdxBlue
import com.example.ui.theme.SuccessEmerald
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

@Composable
fun IdxTestsScreen(
    initialTests: List<TestCase>,
    testHistory: List<TestHistoryEntity>,
    onRecordTestRun: (TestHistoryEntity) -> Unit,
    modifier: Modifier = Modifier
) {
    val coroutineScope = rememberCoroutineScope()
    var tests by remember { mutableStateOf(initialTests) }
    var isRunningAll by remember { mutableStateOf(false) }

    val passedCount = tests.count { it.status == TestStatus.PASSED }
    val totalCount = tests.size

    val testSuiteCode = """
// Flutter Widget Test (Flutter Web WASM)
testWidgets('Counter increment verification', (WidgetTester tester) async {
  await tester.pumpWidget(const ProviderScope(child: IdxSaaSApp()));
  expect(find.text('Live WebAssembly Render:'), findsOneWidget);
  
  await tester.tap(find.byIcon(Icons.add_task));
  await tester.pumpAndSettle();
  expect(find.text('1'), findsOneWidget);
});

// Next.js Vitest Unit Test
describe('Gemini Server Action', () => {
  it('should summarize code diff securely', async () => {
    const formData = new FormData();
    formData.append('code', 'const a = 10;');
    const res = await summarizeCode(formData);
    expect(res.summary).toBeDefined();
  });
});
    """.trimIndent()

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            SectionHeader(
                title = "Tests Suite",
                subtitle = "idx.google.com ├── Tests (Flutter, Next.js Vitest & Firebase Emulators)",
                badge = "100% Passing",
                badgeColor = SuccessEmerald
            )
        }

        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                StatCard(
                    title = "Test Status",
                    value = "$passedCount / $totalCount Passed",
                    icon = Icons.Default.CheckCircle,
                    accentColor = SuccessEmerald,
                    modifier = Modifier.weight(1f)
                )
                StatCard(
                    title = "Code Coverage",
                    value = "94.2%",
                    icon = Icons.Default.PieChart,
                    accentColor = IdxBlue,
                    modifier = Modifier.weight(1f)
                )
            }
        }

        // Action Bar
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Active Test Cases",
                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.SemiBold)
                )

                Button(
                    onClick = {
                        coroutineScope.launch {
                            isRunningAll = true
                            tests = tests.map { it.copy(status = TestStatus.RUNNING) }
                            delay(600)
                            tests = tests.map { it.copy(status = TestStatus.PASSED) }
                            isRunningAll = false

                            onRecordTestRun(
                                TestHistoryEntity(
                                    suiteName = "Full CI Test Pipeline",
                                    framework = "All Frameworks",
                                    totalTests = tests.size,
                                    passedTests = tests.size,
                                    failedTests = 0,
                                    durationMs = 1293
                                )
                            )
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = SuccessEmerald),
                    enabled = !isRunningAll,
                    modifier = Modifier.testTag("run_all_tests_button")
                ) {
                    Icon(
                        imageVector = if (isRunningAll) Icons.Default.Refresh else Icons.Default.PlayArrow,
                        contentDescription = null,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(if (isRunningAll) "Running..." else "Run All Suites", fontSize = 12.sp)
                }
            }
        }

        // Test Cases List
        items(tests) { testCase ->
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(10.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                border = androidx.compose.foundation.BorderStroke(
                    1.dp,
                    when (testCase.status) {
                        TestStatus.PASSED -> SuccessEmerald.copy(alpha = 0.4f)
                        TestStatus.FAILED -> ErrorRose.copy(alpha = 0.4f)
                        TestStatus.RUNNING -> IdxBlue.copy(alpha = 0.4f)
                        TestStatus.PENDING -> MaterialTheme.colorScheme.outline.copy(alpha = 0.2f)
                    }
                )
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(12.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = testCase.title,
                            style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.SemiBold)
                        )
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = "${testCase.suite} • ${testCase.framework} (${testCase.durationMs}ms)",
                            style = MaterialTheme.typography.labelSmall.copy(fontFamily = FontFamily.Monospace),
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }

                    Surface(
                        color = when (testCase.status) {
                            TestStatus.PASSED -> SuccessEmerald.copy(alpha = 0.15f)
                            TestStatus.FAILED -> ErrorRose.copy(alpha = 0.15f)
                            TestStatus.RUNNING -> IdxBlue.copy(alpha = 0.15f)
                            TestStatus.PENDING -> MaterialTheme.colorScheme.outline.copy(alpha = 0.15f)
                        },
                        shape = RoundedCornerShape(6.dp)
                    ) {
                        Text(
                            text = testCase.status.name,
                            color = when (testCase.status) {
                                TestStatus.PASSED -> SuccessEmerald
                                TestStatus.FAILED -> ErrorRose
                                TestStatus.RUNNING -> IdxBlue
                                TestStatus.PENDING -> MaterialTheme.colorScheme.onSurfaceVariant
                            },
                            style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                        )
                    }
                }
            }
        }

        // Test Spec Code
        item {
            CodeViewerCard(
                title = "test/widget_test.dart & vitest.spec.ts",
                language = "typescript",
                code = testSuiteCode
            )
        }
    }
}
