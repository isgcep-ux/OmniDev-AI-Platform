package com.example.ui.isg

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.IsgRiskAssessment
import com.example.ui.components.SectionHeader
import com.example.ui.theme.GeminiGreen
import com.example.ui.theme.GeminiPurple
import com.example.ui.theme.IdxBlue
import kotlinx.coroutines.launch

@Composable
fun IsgRiskCalculatorScreen(
    assessments: List<IsgRiskAssessment>,
    onAddRisk: (String, String, String, Double, Double, Double, String) -> Unit,
    onAnalyzeWithGemini: suspend (String) -> String,
    modifier: Modifier = Modifier
) {
    var method by remember { mutableStateOf("Fine-Kinney") }
    var activityText by remember { mutableStateOf("") }
    var dangerSourceText by remember { mutableStateOf("") }
    var riskDescriptionText by remember { mutableStateOf("") }

    // Fine-Kinney parameters
    var probability by remember { mutableStateOf(3.0) } // 0.2, 0.5, 1, 3, 6, 10
    var severity by remember { mutableStateOf(7.0) }    // 1, 3, 7, 15, 40, 100
    var frequency by remember { mutableStateOf(6.0) }   // 0.5, 1, 2, 3, 6, 10

    // Gemini Incident Analyzer state
    var incidentText by remember { mutableStateOf("") }
    var isAnalyzingIncident by remember { mutableStateOf(false) }
    var incidentAiResult by remember { mutableStateOf<String?>(null) }
    val coroutineScope = rememberCoroutineScope()

    val currentScore = if (method == "Fine-Kinney") {
        probability * severity * frequency
    } else {
        probability * severity
    }

    val riskLevel = if (method == "Fine-Kinney") {
        when {
            currentScore >= 400 -> "Tolerans Edilemez Risk"
            currentScore >= 200 -> "Esaslı Risk"
            currentScore >= 70 -> "Önemli Risk"
            currentScore >= 20 -> "Olası Risk"
            else -> "Kabul Edilebilir Risk"
        }
    } else {
        when {
            currentScore >= 16 -> "Tolerans Edilemez (Yüksek)"
            currentScore >= 9 -> "Önemli Risk (Orta)"
            currentScore >= 4 -> "Düşük Risk"
            else -> "Önemsiz Risk"
        }
    }

    val riskColor = when {
        currentScore >= 400 || (method == "5x5 Matris" && currentScore >= 16) -> Color(0xFFD32F2F)
        currentScore >= 200 || (method == "5x5 Matris" && currentScore >= 9) -> Color(0xFFF57C00)
        currentScore >= 70 || (method == "5x5 Matris" && currentScore >= 4) -> Color(0xFFFBC02D)
        else -> GeminiGreen
    }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp),
        contentPadding = PaddingValues(top = 16.dp, bottom = 32.dp)
    ) {
        item {
            SectionHeader(
                title = "İSG Risk Değerlendirme & AI Analizörü",
                subtitle = "isgcepakademi.xyz Fine-Kinney, 5x5 Matris ve Gemini Kaza Kök Neden Motoru"
            )
        }

        // Live Risk Score Display
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(
                    containerColor = riskColor.copy(alpha = 0.12f)
                ),
                border = CardDefaults.outlinedCardBorder()
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Text(
                        text = "CANLI RİSK DERECESİ ($method)",
                        style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold),
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Text(
                        text = "R = %.1f".format(currentScore),
                        style = MaterialTheme.typography.headlineLarge.copy(
                            fontWeight = FontWeight.Black,
                            color = riskColor
                        )
                    )
                    Surface(
                        color = riskColor,
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Text(
                            text = riskLevel,
                            color = Color.White,
                            style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 4.dp)
                        )
                    }
                    Text(
                        text = if (method == "Fine-Kinney") "Formül: Risk = İhtimal (%.1f) x Şiddet (%.1f) x Frekans (%.1f)".format(probability, severity, frequency)
                        else "Formül: Risk = İhtimal (%.1f) x Şiddet (%.1f)".format(probability, severity),
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }

        // Method Selector & Parameter Inputs
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f)
                ),
                border = CardDefaults.outlinedCardBorder()
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Text(
                        text = "Risk Değerlendirme Parametreleri",
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                    )

                    // Method toggle
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        FilterChip(
                            selected = method == "Fine-Kinney",
                            onClick = {
                                method = "Fine-Kinney"
                                probability = 3.0
                                severity = 7.0
                                frequency = 6.0
                            },
                            label = { Text("Fine-Kinney (İ x Ş x F)") },
                            modifier = Modifier.weight(1f)
                        )
                        FilterChip(
                            selected = method == "5x5 Matris",
                            onClick = {
                                method = "5x5 Matris"
                                probability = 3.0
                                severity = 3.0
                            },
                            label = { Text("5x5 L Matris (İ x Ş)") },
                            modifier = Modifier.weight(1f)
                        )
                    }

                    // Activity & Hazard text fields
                    OutlinedTextField(
                        value = activityText,
                        onValueChange = { activityText = it },
                        label = { Text("Faaliyet / İş İstasyonu") },
                        placeholder = { Text("Örn: Yüksekte çatı kaplama montajı") },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true,
                        shape = RoundedCornerShape(10.dp)
                    )

                    OutlinedTextField(
                        value = dangerSourceText,
                        onValueChange = { dangerSourceText = it },
                        label = { Text("Tehlike Kaynağı") },
                        placeholder = { Text("Örn: Emniyet kemersiz çalışma / Kaygan zemin") },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true,
                        shape = RoundedCornerShape(10.dp)
                    )

                    OutlinedTextField(
                        value = riskDescriptionText,
                        onValueChange = { riskDescriptionText = it },
                        label = { Text("Olası Risk & Sonuç") },
                        placeholder = { Text("Örn: Düşme sonucu ağır kırık veya can kaybı") },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true,
                        shape = RoundedCornerShape(10.dp)
                    )

                    // Sliders
                    Column {
                        Text(
                            text = "İhtimal (Olasılık): %.1f".format(probability),
                            style = MaterialTheme.typography.labelMedium
                        )
                        Slider(
                            value = probability.toFloat(),
                            onValueChange = { probability = it.toDouble() },
                            valueRange = if (method == "Fine-Kinney") 0.2f..10f else 1f..5f,
                            steps = if (method == "Fine-Kinney") 5 else 3
                        )
                    }

                    Column {
                        Text(
                            text = "Şiddet (Derece): %.1f".format(severity),
                            style = MaterialTheme.typography.labelMedium
                        )
                        Slider(
                            value = severity.toFloat(),
                            onValueChange = { severity = it.toDouble() },
                            valueRange = if (method == "Fine-Kinney") 1f..100f else 1f..5f,
                            steps = if (method == "Fine-Kinney") 5 else 3
                        )
                    }

                    if (method == "Fine-Kinney") {
                        Column {
                            Text(
                                text = "Frekans (Maruziyet): %.1f".format(frequency),
                                style = MaterialTheme.typography.labelMedium
                            )
                            Slider(
                                value = frequency.toFloat(),
                                onValueChange = { frequency = it.toDouble() },
                                valueRange = 0.5f..10f,
                                steps = 5
                            )
                        }
                    }

                    Button(
                        onClick = {
                            if (activityText.isNotBlank()) {
                                onAddRisk(
                                    activityText,
                                    dangerSourceText.ifBlank { "Genel Tehlike" },
                                    riskDescriptionText.ifBlank { "İş kazası riski" },
                                    probability,
                                    severity,
                                    frequency,
                                    method
                                )
                                activityText = ""
                                dangerSourceText = ""
                                riskDescriptionText = ""
                            }
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("add_risk_assessment_btn"),
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Icon(Icons.Default.Add, contentDescription = null)
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Risk Değerlendirmesine Kaydet & DÖF Planla")
                    }
                }
            }
        }

        // Gemini AI Incident Root Cause Analyzer
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(
                    containerColor = GeminiPurple.copy(alpha = 0.08f)
                ),
                border = CardDefaults.outlinedCardBorder()
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.AutoAwesome,
                            contentDescription = null,
                            tint = GeminiPurple
                        )
                        Text(
                            text = "Gemini AI Kaza & Ramak Kala Analizörü",
                            style = MaterialTheme.typography.titleMedium.copy(
                                fontWeight = FontWeight.Bold,
                                color = GeminiPurple
                            )
                        )
                    }

                    Text(
                        text = "Yaşanan iş kazası veya ramak kala olayını girin; Gemini 3.5 Flash 6331 mevzuatı, 5 Neden kök analiz ve SGK bildirim rehberini oluştursun.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )

                    OutlinedTextField(
                        value = incidentText,
                        onValueChange = { incidentText = it },
                        placeholder = { Text("Örn: Pres operatörünün eli çift el kumandayı bypass ettiği sırada kalıp arasına sıkıştı...") },
                        modifier = Modifier.fillMaxWidth(),
                        minLines = 3,
                        maxLines = 5,
                        shape = RoundedCornerShape(10.dp)
                    )

                    Button(
                        onClick = {
                            if (incidentText.isNotBlank()) {
                                isAnalyzingIncident = true
                                incidentAiResult = null
                                coroutineScope.launch {
                                    incidentAiResult = onAnalyzeWithGemini(incidentText)
                                    isAnalyzingIncident = false
                                }
                            }
                        },
                        enabled = incidentText.isNotBlank() && !isAnalyzingIncident,
                        modifier = Modifier.fillMaxWidth(),
                        colors = ButtonDefaults.buttonColors(containerColor = GeminiPurple),
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        if (isAnalyzingIncident) {
                            CircularProgressIndicator(modifier = Modifier.size(18.dp), color = Color.White)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Gemini Kök Neden Analizi Yapılıyor...")
                        } else {
                            Icon(Icons.Default.Psychology, contentDescription = null)
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Kök Neden & SGK Bildirim Raporu Üret")
                        }
                    }

                    incidentAiResult?.let { result ->
                        Surface(
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(10.dp),
                            color = MaterialTheme.colorScheme.surface
                        ) {
                            Column(modifier = Modifier.padding(12.dp)) {
                                Text(
                                    text = "Gemini AI İSG Raporu:",
                                    style = MaterialTheme.typography.labelMedium.copy(
                                        fontWeight = FontWeight.Bold,
                                        color = GeminiPurple
                                    )
                                )
                                Spacer(modifier = Modifier.height(6.dp))
                                Text(
                                    text = result,
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                            }
                        }
                    }
                }
            }
        }

        // Recorded Assessments List
        item {
            Text(
                text = "Kayıtlı Risk Matrisi & DÖF Listesi (${assessments.size})",
                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
            )
        }

        items(assessments, key = { it.id }) { item ->
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.45f)
                ),
                border = CardDefaults.outlinedCardBorder()
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(14.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = item.activity,
                            style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                            modifier = Modifier.weight(1f)
                        )
                        Surface(
                            color = if (item.score >= 400 || item.score >= 16 && item.method == "5x5 Matris") Color(0xFFD32F2F)
                            else if (item.score >= 70) Color(0xFFF57C00) else GeminiGreen,
                            shape = RoundedCornerShape(6.dp)
                        ) {
                            Text(
                                text = "Skor: %.0f • %s".format(item.score, item.riskLevel),
                                color = Color.White,
                                style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                            )
                        }
                    }

                    Text(
                        text = "Tehlike: ${item.dangerSource}",
                        style = MaterialTheme.typography.bodySmall.copy(color = MaterialTheme.colorScheme.primary)
                    )
                    Text(
                        text = item.riskDescription,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )

                    // Actions
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(8.dp))
                            .background(MaterialTheme.colorScheme.surface)
                            .padding(8.dp),
                        verticalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Text(
                            text = "Önerilen DÖF & Eylem Planı:",
                            style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold)
                        )
                        item.recommendedActions.forEach { act ->
                            Row(
                                verticalAlignment = Alignment.Top,
                                horizontalArrangement = Arrangement.spacedBy(4.dp)
                            ) {
                                Text("•", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.primary)
                                Text(act, style = MaterialTheme.typography.bodySmall)
                            }
                        }
                    }
                }
            }
        }
    }
}
