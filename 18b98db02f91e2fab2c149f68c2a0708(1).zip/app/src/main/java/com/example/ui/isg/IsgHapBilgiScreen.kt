package com.example.ui.isg

import androidx.compose.animation.*
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.IsgHapBilgi
import com.example.ui.components.SectionHeader
import com.example.ui.components.StatCard
import com.example.ui.theme.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun IsgHapBilgiScreen(
    hapBilgiler: List<IsgHapBilgi>,
    onToggleFavorite: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    var activeSubTab by remember { mutableIntStateOf(0) }
    val subTabs = listOf("💡 Hap Bilgiler & Özetler", "🎯 ÖSYM Sınav Puanı", "⚖️ İSG-KÂTİP Hesaplama")

    Column(
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp)
    ) {
        Spacer(modifier = Modifier.height(16.dp))
        SectionHeader(
            title = "İSG Mevzuat, Hap Bilgiler & Hesaplama",
            subtitle = "Sınav hap notları, 6331 formülleri, ÖSYM puanlama ve İSG-KÂTİP zorunlu süre hesaplayıcı",
            badge = "Hap Bilgi & Araçlar",
            badgeColor = WarningYellow
        )
        Spacer(modifier = Modifier.height(12.dp))

        // Segmented Sub-Tab Switcher
        SecondaryTabRow(
            selectedTabIndex = activeSubTab,
            containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
            contentColor = MaterialTheme.colorScheme.primary,
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(12.dp))
        ) {
            subTabs.forEachIndexed { index, title ->
                Tab(
                    selected = activeSubTab == index,
                    onClick = { activeSubTab = index },
                    text = {
                        Text(
                            text = title,
                            style = MaterialTheme.typography.labelMedium.copy(
                                fontWeight = if (activeSubTab == index) FontWeight.Bold else FontWeight.Normal
                            ),
                            maxLines = 1
                        )
                    },
                    modifier = Modifier.testTag("tab_sub_hap_$index")
                )
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        when (activeSubTab) {
            0 -> HapBilgilerView(hapBilgiler = hapBilgiler, onToggleFavorite = onToggleFavorite)
            1 -> OsymScoreCalculatorView()
            2 -> IsgKatipCalculatorView()
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HapBilgilerView(
    hapBilgiler: List<IsgHapBilgi>,
    onToggleFavorite: (String) -> Unit
) {
    var searchQuery by remember { mutableStateOf("") }
    var selectedCategory by remember { mutableStateOf("Tümü") }
    var showOnlyFavorites by remember { mutableStateOf(false) }

    val categories = listOf(
        "Tümü",
        "Kritik Süreler & Periyotlar",
        "Çalışan & Temsilci Sayıları",
        "Eşik & Eylem Değerleri",
        "İSG Kurulları & Kâtip",
        "Yangın & Acil Durum"
    )

    val filteredList = remember(hapBilgiler, searchQuery, selectedCategory, showOnlyFavorites) {
        hapBilgiler.filter { item ->
            val matchesCategory = selectedCategory == "Tümü" || item.category == selectedCategory
            val matchesFavorite = !showOnlyFavorites || item.isFavorite
            val matchesSearch = searchQuery.isBlank() ||
                    item.title.contains(searchQuery, ignoreCase = true) ||
                    item.summary.contains(searchQuery, ignoreCase = true) ||
                    item.keyPoints.any { it.contains(searchQuery, ignoreCase = true) } ||
                    item.lawReference.contains(searchQuery, ignoreCase = true)
            matchesCategory && matchesFavorite && matchesSearch
        }
    }

    LazyColumn(
        verticalArrangement = Arrangement.spacedBy(14.dp),
        contentPadding = PaddingValues(bottom = 32.dp)
    ) {
        item {
            OutlinedTextField(
                value = searchQuery,
                onValueChange = { searchQuery = it },
                placeholder = { Text("Örn: gürültü, temsilci sayısı, yangın sınıfları...") },
                leadingIcon = {
                    Icon(Icons.Default.Search, contentDescription = "Ara", tint = MaterialTheme.colorScheme.onSurfaceVariant)
                },
                trailingIcon = {
                    if (searchQuery.isNotEmpty()) {
                        IconButton(onClick = { searchQuery = "" }) {
                            Icon(Icons.Default.Clear, contentDescription = "Temizle")
                        }
                    }
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("input_search_hap_bilgi"),
                shape = RoundedCornerShape(12.dp),
                singleLine = true
            )
        }

        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                LazyRow(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    items(categories) { cat ->
                        FilterChip(
                            selected = selectedCategory == cat,
                            onClick = { selectedCategory = cat },
                            label = { Text(cat, fontSize = 12.sp) },
                            modifier = Modifier.testTag("chip_cat_$cat")
                        )
                    }
                }

                Spacer(modifier = Modifier.width(8.dp))
                IconButton(
                    onClick = { showOnlyFavorites = !showOnlyFavorites },
                    modifier = Modifier.testTag("btn_filter_favorites")
                ) {
                    Icon(
                        if (showOnlyFavorites) Icons.Default.Bookmark else Icons.Default.BookmarkBorder,
                        contentDescription = "Favoriler",
                        tint = if (showOnlyFavorites) WarningYellow else MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }

        items(filteredList) { item ->
            var isExpanded by remember { mutableStateOf(true) }

            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("card_hap_${item.id}"),
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.2f))
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
                            Surface(
                                shape = RoundedCornerShape(6.dp),
                                color = MaterialTheme.colorScheme.primary.copy(alpha = 0.12f)
                            ) {
                                Text(
                                    text = item.category,
                                    color = MaterialTheme.colorScheme.primary,
                                    style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                )
                            }
                            Surface(
                                shape = RoundedCornerShape(6.dp),
                                color = WarningYellow.copy(alpha = 0.15f)
                            ) {
                                Text(
                                    text = item.badge,
                                    color = WarningYellow,
                                    style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.SemiBold),
                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                )
                            }
                        }

                        Row(verticalAlignment = Alignment.CenterVertically) {
                            IconButton(
                                onClick = { onToggleFavorite(item.id) },
                                modifier = Modifier.size(32.dp)
                            ) {
                                Icon(
                                    if (item.isFavorite) Icons.Default.Bookmark else Icons.Default.BookmarkBorder,
                                    contentDescription = "Kaydet",
                                    tint = if (item.isFavorite) WarningYellow else MaterialTheme.colorScheme.onSurfaceVariant,
                                    modifier = Modifier.size(18.dp)
                                )
                            }
                            IconButton(
                                onClick = { isExpanded = !isExpanded },
                                modifier = Modifier.size(32.dp)
                            ) {
                                Icon(
                                    if (isExpanded) Icons.Default.ExpandLess else Icons.Default.ExpandMore,
                                    contentDescription = "Genişlet",
                                    modifier = Modifier.size(20.dp)
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = item.title,
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = item.summary,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )

                    AnimatedVisibility(
                        visible = isExpanded,
                        enter = fadeIn() + expandVertically(),
                        exit = fadeOut() + shrinkVertically()
                    ) {
                        Column(modifier = Modifier.padding(top = 10.dp)) {
                            HorizontalDivider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.15f))
                            Spacer(modifier = Modifier.height(10.dp))

                            item.keyPoints.forEach { point ->
                                Row(
                                    modifier = Modifier.padding(vertical = 3.dp),
                                    verticalAlignment = Alignment.Top,
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    Text("📌", fontSize = 12.sp)
                                    Text(
                                        text = point,
                                        style = MaterialTheme.typography.bodySmall.copy(lineHeight = 18.sp, fontSize = 12.5.sp),
                                        color = MaterialTheme.colorScheme.onSurface
                                    )
                                }
                            }

                            Spacer(modifier = Modifier.height(8.dp))
                            Surface(
                                shape = RoundedCornerShape(6.dp),
                                color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Row(
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 5.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                                ) {
                                    Icon(Icons.Default.Gavel, contentDescription = null, tint = IdxBlue, modifier = Modifier.size(14.dp))
                                    Text(
                                        text = "Yasal Dayanak: ${item.lawReference}",
                                        style = MaterialTheme.typography.labelSmall.copy(fontSize = 11.sp),
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun OsymScoreCalculatorView() {
    var examType by remember { mutableStateOf("C Sınıfı İGU") }
    var correctCountText by remember { mutableStateOf("38") }
    var incorrectCountText by remember { mutableStateOf("8") }

    val correctCount = correctCountText.toIntOrNull() ?: 0
    val incorrectCount = incorrectCountText.toIntOrNull() ?: 0
    val totalAnswered = (correctCount + incorrectCount).coerceAtMost(50)
    val emptyCount = (50 - totalAnswered).coerceAtLeast(0)

    // ÖSYM İSG Sınavlarında yanlış doğruyu götürmez; her soru 2 puandır (50 soru x 2 = 100 puan)
    // Baraj 70 puandır (35 doğru).
    val score = (correctCount.coerceIn(0, 50) * 2).toDouble()
    val isPassed = score >= 70.0
    val neededToPass = (35 - correctCount).coerceAtLeast(0)

    val examTypes = listOf("A Sınıfı İGU", "B Sınıfı İGU", "C Sınıfı İGU", "İşyeri Hekimliği", "DSP")

    LazyColumn(
        verticalArrangement = Arrangement.spacedBy(16.dp),
        contentPadding = PaddingValues(bottom = 32.dp)
    ) {
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.2f))
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "🎯 ÖSYM İSG Sınav Puanı & Baraj Hesaplama",
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "ÖSYM İSG sınavlarında 50 çoktan seçmeli soru sorulur. Yanlış cevaplar doğruyu götürmez. Başarılı sayılmak için 70 puan (en az 35 doğru) alınmalıdır.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }

        // Exam Type Selector
        item {
            Column {
                Text(
                    text = "Sınav Türü Seçin:",
                    style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold),
                    modifier = Modifier.padding(bottom = 6.dp)
                )
                LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(examTypes) { type ->
                        FilterChip(
                            selected = examType == type,
                            onClick = { examType = type },
                            label = { Text(type, fontSize = 12.sp) },
                            modifier = Modifier.testTag("filter_exam_type_$type")
                        )
                    }
                }
            }
        }

        // Inputs
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.25f))
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        OutlinedTextField(
                            value = correctCountText,
                            onValueChange = { if (it.length <= 2) correctCountText = it.filter { char -> char.isDigit() } },
                            label = { Text("Doğru Sayısı (0-50)") },
                            modifier = Modifier
                                .weight(1f)
                                .testTag("input_correct_count"),
                            shape = RoundedCornerShape(10.dp),
                            singleLine = true
                        )
                        OutlinedTextField(
                            value = incorrectCountText,
                            onValueChange = { if (it.length <= 2) incorrectCountText = it.filter { char -> char.isDigit() } },
                            label = { Text("Yanlış Sayısı") },
                            modifier = Modifier
                                .weight(1f)
                                .testTag("input_incorrect_count"),
                            shape = RoundedCornerShape(10.dp),
                            singleLine = true
                        )
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("Boş Bırakılan: $emptyCount soru", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Text("Toplam Soru: 50", style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }

        // Result Score Card
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(
                    containerColor = if (isPassed) SuccessEmerald.copy(alpha = 0.12f)
                    else MaterialTheme.colorScheme.error.copy(alpha = 0.12f)
                ),
                border = BorderStroke(
                    1.5.dp,
                    if (isPassed) SuccessEmerald else MaterialTheme.colorScheme.error
                )
            ) {
                Column(
                    modifier = Modifier.padding(20.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        text = if (isPassed) "🎉 TEBRİKLER! BARAJI GEÇTİNİZ" else "⚠️ BARAJIN ALTINDA KALDINIZ",
                        style = MaterialTheme.typography.titleMedium.copy(
                            fontWeight = FontWeight.Bold,
                            color = if (isPassed) SuccessEmerald else MaterialTheme.colorScheme.error
                        )
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    Text(
                        text = "${score.toInt()} Puan",
                        style = MaterialTheme.typography.headlineLarge.copy(
                            fontWeight = FontWeight.ExtraBold,
                            fontSize = 38.sp,
                            color = if (isPassed) SuccessEmerald else MaterialTheme.colorScheme.error
                        )
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "$correctCount Doğru • $incorrectCount Yanlış • $emptyCount Boş",
                        style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.SemiBold)
                    )

                    Spacer(modifier = Modifier.height(12.dp))
                    HorizontalDivider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.2f))
                    Spacer(modifier = Modifier.height(12.dp))

                    if (isPassed) {
                        Text(
                            text = "✅ 35 doğru barajını ${(correctCount - 35)} soru farkla aştınız. Sınav sonucunuz Başarılıdır.",
                            style = MaterialTheme.typography.bodySmall,
                            color = SuccessEmerald,
                            fontWeight = FontWeight.SemiBold
                        )
                    } else {
                        Text(
                            text = "❌ 70 puana ulaşmak için en az $neededToPass net/doğruya daha ihtiyacınız var.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.error,
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun IsgKatipCalculatorView() {
    var employeeCountText by remember { mutableStateOf("120") }
    var hazardClass by remember { mutableStateOf("Tehlikeli") } // "Az Tehlikeli", "Tehlikeli", "Çok Tehlikeli"

    val employeeCount = employeeCountText.toIntOrNull() ?: 1

    // Minute rates per employee
    val (iguMinutesPerEmployee, iguFullTimeThreshold) = when (hazardClass) {
        "Az Tehlikeli" -> Pair(10, 1000)
        "Tehlikeli" -> Pair(20, 500)
        else -> Pair(40, 250) // Çok Tehlikeli
    }

    val (doctorMinutesPerEmployee, doctorFullTimeThreshold) = when (hazardClass) {
        "Az Tehlikeli" -> Pair(5, 2000)
        "Tehlikeli" -> Pair(10, 1000)
        else -> Pair(15, 750) // Çok Tehlikeli
    }

    val totalIguMinutes = employeeCount * iguMinutesPerEmployee
    val totalIguHours = totalIguMinutes / 60.0
    val fullTimeIguCount = employeeCount / iguFullTimeThreshold

    val totalDoctorMinutes = employeeCount * doctorMinutesPerEmployee
    val totalDoctorHours = totalDoctorMinutes / 60.0
    val fullTimeDoctorCount = employeeCount / doctorFullTimeThreshold

    // DSP Calculation: Required if Çok Tehlikeli and 10+ employees
    val dspInfo = if (hazardClass == "Çok Tehlikeli" && employeeCount >= 10) {
        val dspMinRate = when {
            employeeCount in 10..49 -> 35
            employeeCount in 50..249 -> 40
            else -> 50
        }
        val dspTotalMin = employeeCount * dspMinRate
        "Zorunlu (${dspTotalMin} dk/ay - ${(dspTotalMin / 60.0).toInt()} saat)"
    } else {
        "Zorunlu Değil"
    }

    // Employee Representative calculation
    val repCount = when {
        employeeCount in 2..50 -> 1
        employeeCount in 51..100 -> 2
        employeeCount in 101..500 -> 3
        employeeCount in 501..1000 -> 4
        employeeCount in 1001..2000 -> 5
        employeeCount >= 2001 -> 6
        else -> 0
    }

    // ISG Board (Kurul) requirement
    val isBoardRequired = employeeCount >= 50

    val hazardClasses = listOf("Az Tehlikeli", "Tehlikeli", "Çok Tehlikeli")

    LazyColumn(
        verticalArrangement = Arrangement.spacedBy(16.dp),
        contentPadding = PaddingValues(bottom = 32.dp)
    ) {
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.2f))
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "⚖️ İSG-KÂTİP Çalışma Süresi & Atama Matrisi",
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "6331 Sayılı Kanun ve İSG Hizmetleri Yönetmeliği uyarınca çalışan sayısı ve tehlike sınıfına göre asgari sözleşme sürelerini anında hesaplayın.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }

        // Inputs
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.25f))
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    OutlinedTextField(
                        value = employeeCountText,
                        onValueChange = { if (it.length <= 5) employeeCountText = it.filter { char -> char.isDigit() } },
                        label = { Text("Toplam Çalışan Sayısı") },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("input_katip_employees"),
                        shape = RoundedCornerShape(10.dp),
                        singleLine = true
                    )

                    Column {
                        Text(
                            text = "Tehlike Sınıfı:",
                            style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold),
                            modifier = Modifier.padding(bottom = 6.dp)
                        )
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            hazardClasses.forEach { cls ->
                                val isSelected = hazardClass == cls
                                val chipColor = when (cls) {
                                    "Az Tehlikeli" -> SuccessEmerald
                                    "Tehlikeli" -> WarningYellow
                                    else -> MaterialTheme.colorScheme.error
                                }

                                FilterChip(
                                    selected = isSelected,
                                    onClick = { hazardClass = cls },
                                    label = { Text(cls, fontSize = 12.sp) },
                                    modifier = Modifier
                                        .weight(1f)
                                        .testTag("chip_hazard_$cls")
                                )
                            }
                        }
                    }
                }
            }
        }

        // Computed Results
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                StatCard(
                    title = "İGU Zorunlu Süre",
                    value = "${totalIguHours.toInt()} sa/ay",
                    icon = Icons.Default.Engineering,
                    accentColor = IdxBlue,
                    modifier = Modifier.weight(1f)
                )
                StatCard(
                    title = "Hekim Zorunlu Süre",
                    value = "${totalDoctorHours.toInt()} sa/ay",
                    icon = Icons.Default.MedicalServices,
                    accentColor = GeminiGreen,
                    modifier = Modifier.weight(1f)
                )
            }
        }

        // Detailed Breakdown
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.25f))
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text(
                        text = "📋 Yasal Zorunluluk Özeti",
                        style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold)
                    )

                    BreakdownRow(
                        title = "İş Güvenliği Uzmanı Süresi",
                        value = "$totalIguMinutes dk/ay (~${String.format("%.1f", totalIguHours)} saat) (Kişi başı $iguMinutesPerEmployee dk)"
                    )
                    BreakdownRow(
                        title = "Tam Zamanlı İGU İhtiyacı",
                        value = if (fullTimeIguCount > 0) "$fullTimeIguCount Tam Zamanlı Uzman + Kalan Süre" else "Kısmi Süreli (Her $iguFullTimeThreshold çalışanda 1 tam gün)"
                    )
                    BreakdownRow(
                        title = "İşyeri Hekimi Süresi",
                        value = "$totalDoctorMinutes dk/ay (~${String.format("%.1f", totalDoctorHours)} saat) (Kişi başı $doctorMinutesPerEmployee dk)"
                    )
                    BreakdownRow(
                        title = "Tam Zamanlı Hekim İhtiyacı",
                        value = if (fullTimeDoctorCount > 0) "$fullTimeDoctorCount Tam Zamanlı Hekim" else "Kısmi Süreli (Her $doctorFullTimeThreshold çalışanda 1 tam gün)"
                    )
                    BreakdownRow(
                        title = "Diğer Sağlık Personeli (DSP)",
                        value = dspInfo
                    )
                    BreakdownRow(
                        title = "İSG Kurulu Kurma Zorunluluğu",
                        value = if (isBoardRequired) "✅ Zorunlu (50+ çalışan)" else "❌ Zorunlu Değil (<50 çalışan)"
                    )
                    BreakdownRow(
                        title = "Çalışan Temsilcisi Sayısı",
                        value = "$repCount Temsilci ($employeeCount çalışan baremi)"
                    )
                }
            }
        }
    }
}

@Composable
fun BreakdownRow(title: String, value: String) {
    Column(modifier = Modifier.fillMaxWidth()) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(title, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Text(value, style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold))
        }
        Spacer(modifier = Modifier.height(4.dp))
        HorizontalDivider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.1f))
    }
}
