package com.example.ui.isg

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.IsgApiEndpoint
import com.example.ui.components.CodeViewerCard
import com.example.ui.components.SectionHeader
import com.example.ui.theme.GeminiGreen
import com.example.ui.theme.GeminiPurple
import com.example.ui.theme.IdxBlue

@Composable
fun IsgApiSuiteScreen(
    endpoints: List<IsgApiEndpoint>,
    modifier: Modifier = Modifier
) {
    var selectedDomain by remember { mutableStateOf("Tümü") }
    val clipboard = LocalClipboardManager.current
    var copiedMessage by remember { mutableStateOf<String?>(null) }

    val filteredEndpoints = remember(endpoints, selectedDomain) {
        if (selectedDomain == "Tümü") endpoints
        else endpoints.filter { it.domain == selectedDomain }
    }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp),
        contentPadding = PaddingValues(top = 16.dp, bottom = 32.dp)
    ) {
        item {
            SectionHeader(
                title = "İSG API & Webhook Geliştirici Paketi",
                subtitle = "isgcepakademi.com, isgcepakademi.com.tr & isgcepakademi.xyz REST ve Webhook API entegrasyonu"
            )
        }

        // Domain Selector
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                listOf("Tümü", "isgcepakademi.com", "isgcepakademi.com.tr", "isgcepakademi.xyz").forEach { dom ->
                    val isSelected = selectedDomain == dom
                    FilterChip(
                        selected = isSelected,
                        onClick = { selectedDomain = dom },
                        label = { Text(dom) },
                        modifier = Modifier.testTag("api_filter_$dom")
                    )
                }
            }
        }

        // Endpoints List
        items(filteredEndpoints, key = { it.path }) { ep ->
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("api_card_${ep.path}"),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.45f)
                ),
                border = CardDefaults.outlinedCardBorder()
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Surface(
                                color = if (ep.method == "GET") GeminiGreen.copy(alpha = 0.2f) else IdxBlue.copy(alpha = 0.2f),
                                shape = RoundedCornerShape(6.dp)
                            ) {
                                Text(
                                    text = ep.method,
                                    color = if (ep.method == "GET") GeminiGreen else IdxBlue,
                                    style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                )
                            }
                            Text(
                                text = ep.path,
                                style = MaterialTheme.typography.titleSmall.copy(
                                    fontFamily = FontFamily.Monospace,
                                    fontWeight = FontWeight.Bold
                                )
                            )
                        }

                        val domainColor = when {
                            ep.domain == "isgcepakademi.com" -> GeminiGreen
                            ep.domain.contains("xyz") -> GeminiPurple
                            else -> IdxBlue
                        }
                        Surface(
                            color = domainColor.copy(alpha = 0.15f),
                            shape = RoundedCornerShape(6.dp)
                        ) {
                            Text(
                                text = ep.domain,
                                style = MaterialTheme.typography.labelSmall.copy(
                                    color = domainColor,
                                    fontWeight = FontWeight.SemiBold
                                ),
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                            )
                        }
                    }

                    Text(
                        text = ep.title,
                        style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.SemiBold)
                    )

                    Text(
                        text = ep.description,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )

                    // Request Sample Code
                    Text(
                        text = "cURL İstek Örneği:",
                        style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold)
                    )
                    CodeViewerCard(
                        title = "${ep.method} ${ep.path}",
                        language = "bash",
                        code = ep.requestSample
                    )

                    // Response Sample Code
                    Text(
                        text = "JSON Yanıt Örneği:",
                        style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold)
                    )
                    CodeViewerCard(
                        title = "200 OK Response",
                        language = "json",
                        code = ep.responseSample
                    )
                }
            }
        }
    }
}
