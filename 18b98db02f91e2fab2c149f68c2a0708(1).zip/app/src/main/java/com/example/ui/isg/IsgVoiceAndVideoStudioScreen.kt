package com.example.ui.isg

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.widget.Toast
import androidx.compose.animation.*
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.ClonedVoiceProfile
import com.example.model.VideoGenerationPipelineJob
import com.example.model.VideoJobStatus
import com.example.ui.theme.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun IsgVoiceAndVideoStudioScreen(
    voiceProfiles: List<ClonedVoiceProfile>,
    pipelineJobs: List<VideoGenerationPipelineJob>,
    activeJobStatus: VideoJobStatus,
    activeProgressPercent: Int,
    activeProgressMessage: String,
    onStartPipeline: (String, String, ClonedVoiceProfile, String, String, String) -> Unit,
    onCreateVoiceProfile: (String, String, String, String, String, Float, Float) -> Unit,
    onDeleteJob: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    var activeTab by remember { mutableIntStateOf(0) } // 0: Video Stüdyosu (Üretim & Prompt), 1: Klon Ses Havuzu (Voice Cloning), 2: Üretilen Videolar & İndirme

    var videoTitle by remember { mutableStateOf("Yüksekte Çalışma İSG Hap Bilgi") }
    var scriptText by remember {
        mutableStateOf(
            "Merhaba İSG profesyonelleri! Yüksekte çalışmalarda düşmeyi durdurucu sistemler ve dikey yaşam hatları EN 795 standardına tam uygun olmalıdır. Emniyet kemerlerinizi çift kollu lanyard ile bağlamayı unutmayın."
        )
    }

    var selectedVoice by remember(voiceProfiles) {
        mutableStateOf(voiceProfiles.firstOrNull() ?: ClonedVoiceProfile(
            id = "default_v",
            name = "Ahmet Bey",
            provider = "ElevenLabs",
            voiceId = "21m00Tcm4TlvDq8ikWAM",
            description = "İSG Baş Denetçi Ses Tonu",
            gender = "Erkek"
        ))
    }

    var selectedAvatar by remember { mutableStateOf("3D İSG Baş Denetçisi") }
    val avatarOptions = listOf(
        "3D İSG Baş Denetçisi",
        "Gerçekçi Şantiye Şefi Avatarı",
        "Minimalist Akademik Eğitmen",
        "Hap Bilgi Reels Karakteri"
    )

    var selectedFormat by remember { mutableStateOf("9:16 Dikey (Shorts/Reels/TikTok)") }
    val formatOptions = listOf(
        "9:16 Dikey (Shorts/Reels/TikTok)",
        "16:9 Yatay (YouTube/LMS)"
    )

    var selectedDomain by remember { mutableStateOf("isgcepakademi.com.tr") }
    val domainOptions = listOf("isgcepakademi.com.tr", "isgcepakademi.com", "isgcepakademi.xyz")

    var showNewVoiceDialog by remember { mutableStateOf(false) }

    // Dialog for adding a custom cloned voice
    if (showNewVoiceDialog) {
        CreateVoiceProfileDialog(
            onDismiss = { showNewVoiceDialog = false },
            onCreate = { name, prov, vId, gender, desc, stab, sim ->
                onCreateVoiceProfile(name, prov, vId, gender, desc, stab, sim)
                showNewVoiceDialog = false
                Toast.makeText(context, "Klon ses profili başarıyla kaydedildi!", Toast.LENGTH_SHORT).show()
            }
        )
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .padding(16.dp)
            .testTag("screen_isg_voice_video_studio")
    ) {
        // Header
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Icon(
                        Icons.Default.RecordVoiceOver,
                        contentDescription = null,
                        tint = GeminiPurple,
                        modifier = Modifier.size(24.dp)
                    )
                    Text(
                        text = "Klon Ses & AI Video Stüdyosu",
                        style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold)
                    )
                }
                Text(
                    text = "ElevenLabs & Google TTS Klon Ses Motoru • AI Konuşan Avatar Video Boru Hattı",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            Surface(
                shape = RoundedCornerShape(12.dp),
                color = GeminiPurple.copy(alpha = 0.15f),
                border = BorderStroke(1.dp, GeminiPurple.copy(alpha = 0.3f))
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(8.dp)
                            .background(SuccessEmerald, CircleShape)
                    )
                    Text(
                        text = "TTS v2 Aktif",
                        style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold, color = GeminiPurple)
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(14.dp))

        // Navigation Mode Tabs
        TabRow(
            selectedTabIndex = activeTab,
            containerColor = MaterialTheme.colorScheme.surface,
            contentColor = MaterialTheme.colorScheme.primary,
            modifier = Modifier.clip(RoundedCornerShape(12.dp))
        ) {
            Tab(
                selected = activeTab == 0,
                onClick = { activeTab = 0 },
                text = { Text("Video Stüdyosu", fontWeight = FontWeight.SemiBold) },
                icon = { Icon(Icons.Default.VideoCameraFront, contentDescription = null, modifier = Modifier.size(18.dp)) },
                modifier = Modifier.testTag("tab_video_generator")
            )
            Tab(
                selected = activeTab == 1,
                onClick = { activeTab = 1 },
                text = { Text("Klon Sesler (${voiceProfiles.size})", fontWeight = FontWeight.SemiBold) },
                icon = { Icon(Icons.Default.Mic, contentDescription = null, modifier = Modifier.size(18.dp)) },
                modifier = Modifier.testTag("tab_voice_library")
            )
            Tab(
                selected = activeTab == 2,
                onClick = { activeTab = 2 },
                text = { Text("Kayıtlar (${pipelineJobs.size})", fontWeight = FontWeight.SemiBold) },
                icon = { Icon(Icons.Default.VideoLibrary, contentDescription = null, modifier = Modifier.size(18.dp)) },
                modifier = Modifier.testTag("tab_video_history")
            )
        }

        Spacer(modifier = Modifier.height(16.dp))

        when (activeTab) {
            0 -> {
                // Tab 0: Video Production Studio Studio
                VideoStudioGeneratorSection(
                    videoTitle = videoTitle,
                    onTitleChange = { videoTitle = it },
                    scriptText = scriptText,
                    onScriptChange = { scriptText = it },
                    selectedVoice = selectedVoice,
                    voiceProfiles = voiceProfiles,
                    onSelectVoice = { selectedVoice = it },
                    selectedAvatar = selectedAvatar,
                    avatarOptions = avatarOptions,
                    onSelectAvatar = { selectedAvatar = it },
                    selectedFormat = selectedFormat,
                    formatOptions = formatOptions,
                    onSelectFormat = { selectedFormat = it },
                    selectedDomain = selectedDomain,
                    domainOptions = domainOptions,
                    onSelectDomain = { selectedDomain = it },
                    activeJobStatus = activeJobStatus,
                    activeProgressPercent = activeProgressPercent,
                    activeProgressMessage = activeProgressMessage,
                    onStartGeneration = {
                        onStartPipeline(videoTitle, scriptText, selectedVoice, selectedAvatar, selectedFormat, selectedDomain)
                    },
                    onOpenNewVoiceDialog = { showNewVoiceDialog = true }
                )
            }
            1 -> {
                // Tab 1: Cloned Voice Management
                VoiceProfilesSection(
                    voiceProfiles = voiceProfiles,
                    selectedVoice = selectedVoice,
                    onSelectVoice = { selectedVoice = it },
                    onAddNewVoice = { showNewVoiceDialog = true }
                )
            }
            2 -> {
                // Tab 2: Generated Video Library & Playback
                GeneratedVideosSection(
                    jobs = pipelineJobs,
                    onDeleteJob = onDeleteJob
                )
            }
        }
    }
}

@Composable
fun VideoStudioGeneratorSection(
    videoTitle: String,
    onTitleChange: (String) -> Unit,
    scriptText: String,
    onScriptChange: (String) -> Unit,
    selectedVoice: ClonedVoiceProfile,
    voiceProfiles: List<ClonedVoiceProfile>,
    onSelectVoice: (ClonedVoiceProfile) -> Unit,
    selectedAvatar: String,
    avatarOptions: List<String>,
    onSelectAvatar: (String) -> Unit,
    selectedFormat: String,
    formatOptions: List<String>,
    onSelectFormat: (String) -> Unit,
    selectedDomain: String,
    domainOptions: List<String>,
    onSelectDomain: (String) -> Unit,
    activeJobStatus: VideoJobStatus,
    activeProgressPercent: Int,
    activeProgressMessage: String,
    onStartGeneration: () -> Unit,
    onOpenNewVoiceDialog: () -> Unit
) {
    val scrollState = rememberScrollState()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(scrollState),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // Active Rendering Progress Banner (when pipeline is running)
        if (activeJobStatus != VideoJobStatus.IDLE && activeJobStatus != VideoJobStatus.COMPLETED) {
            Card(
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.6f)),
                border = BorderStroke(1.5.dp, MaterialTheme.colorScheme.primary)
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            CircularProgressIndicator(
                                modifier = Modifier.size(20.dp),
                                strokeWidth = 2.5.dp,
                                color = MaterialTheme.colorScheme.primary
                            )
                            Text(
                                text = "Boru Hattı Çalışıyor (%$activeProgressPercent)",
                                style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold)
                            )
                        }
                        Text(
                            text = when (activeJobStatus) {
                                VideoJobStatus.SYNTHESIZING_AUDIO -> "1/4: Ses Sentezi"
                                VideoJobStatus.GENERATING_AVATAR_LIPSYNC -> "2/4: Lip-Sync"
                                VideoJobStatus.COMPOSITING_SLIDES_BROLL -> "3/4: Görsel Katman"
                                VideoJobStatus.RENDERING_FINAL_MP4 -> "4/4: MP4 Render"
                                else -> "İşleniyor"
                            },
                            style = MaterialTheme.typography.labelSmall.copy(
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.primary
                            )
                        )
                    }

                    Spacer(modifier = Modifier.height(8.dp))
                    LinearProgressIndicator(
                        progress = { activeProgressPercent / 100f },
                        modifier = Modifier.fillMaxWidth().height(6.dp).clip(RoundedCornerShape(3.dp)),
                        color = GeminiPurple
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = activeProgressMessage,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }

        // Title and Script Editor Card
        Card(
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.2f))
        ) {
            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text(
                    text = "1. Video Senaryosu & Başlık",
                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                )

                OutlinedTextField(
                    value = videoTitle,
                    onValueChange = onTitleChange,
                    label = { Text("Video Başlığı") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth().testTag("input_video_title")
                )

                OutlinedTextField(
                    value = scriptText,
                    onValueChange = onScriptChange,
                    label = { Text("Klon Sesin Okuyacağı İSG Eğitim Metni / Senaryo") },
                    minLines = 4,
                    maxLines = 8,
                    modifier = Modifier.fillMaxWidth().testTag("input_video_script")
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Kelime: ${scriptText.split(" ").filter { it.isNotBlank() }.size} • Tahmini Süre: ~${(scriptText.split(" ").size / 2.5).toInt().coerceAtLeast(5)} sn",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )

                    FilledTonalButton(
                        onClick = {
                            onScriptChange("İskelelerde çalışma platformları en az 60 santimetre genişliğinde olmalı, ana korkuluk 100 cm, ara korkuluk 50 cm ve taban tahtası (tekmelik) 15 cm yüksekliğinde monte edilmelidir. TS EN 12810 standardına tam uyum aranır.")
                        },
                        shape = RoundedCornerShape(8.dp),
                        contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp)
                    ) {
                        Icon(Icons.Default.AutoFixHigh, contentDescription = null, modifier = Modifier.size(14.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Örnek Şablon", fontSize = 11.sp)
                    }
                }
            }
        }

        // Voice Engine & Profile Selector Card
        Card(
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.2f))
        ) {
            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "2. Klon Ses Seçimi (TTS Engine)",
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                    )
                    TextButton(onClick = onOpenNewVoiceDialog) {
                        Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("+ Yeni Ses Klonla", fontSize = 12.sp)
                    }
                }

                // Voice Chips
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    voiceProfiles.forEach { profile ->
                        val isSelected = selectedVoice.id == profile.id
                        Surface(
                            shape = RoundedCornerShape(12.dp),
                            color = if (isSelected) MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.5f) else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.35f),
                            border = BorderStroke(
                                if (isSelected) 1.5.dp else 1.dp,
                                if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outline.copy(alpha = 0.2f)
                            ),
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { onSelectVoice(profile) }
                        ) {
                            Row(
                                modifier = Modifier.padding(12.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                                ) {
                                    Surface(
                                        shape = CircleShape,
                                        color = if (profile.gender == "Kadın") GeminiPurple.copy(alpha = 0.2f) else IdxBlue.copy(alpha = 0.2f),
                                        modifier = Modifier.size(36.dp)
                                    ) {
                                        Box(contentAlignment = Alignment.Center) {
                                            Icon(
                                                if (profile.gender == "Kadın") Icons.Default.Female else Icons.Default.Male,
                                                contentDescription = null,
                                                tint = if (profile.gender == "Kadın") GeminiPurple else IdxBlue,
                                                modifier = Modifier.size(20.dp)
                                            )
                                        }
                                    }

                                    Column {
                                        Text(
                                            text = profile.name,
                                            style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold)
                                        )
                                        Text(
                                            text = "${profile.provider} • Stabilite: %${(profile.stability * 100).toInt()}",
                                            style = MaterialTheme.typography.labelSmall,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    }
                                }

                                RadioButton(
                                    selected = isSelected,
                                    onClick = { onSelectVoice(profile) }
                                )
                            }
                        }
                    }
                }
            }
        }

        // Avatar & Output Settings Card
        Card(
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.2f))
        ) {
            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text(
                    text = "3. Avatar Stili & Video Formatı",
                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                )

                Text(
                    text = "Konuşan AI Avatar Stili:",
                    style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.SemiBold)
                )
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    avatarOptions.take(2).forEach { avatar ->
                        val isSelected = selectedAvatar == avatar
                        FilterChip(
                            selected = isSelected,
                            onClick = { onSelectAvatar(avatar) },
                            label = { Text(avatar, fontSize = 11.5.sp) },
                            modifier = Modifier.weight(1f)
                        )
                    }
                }
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    avatarOptions.drop(2).forEach { avatar ->
                        val isSelected = selectedAvatar == avatar
                        FilterChip(
                            selected = isSelected,
                            onClick = { onSelectAvatar(avatar) },
                            label = { Text(avatar, fontSize = 11.5.sp) },
                            modifier = Modifier.weight(1f)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "Video Çıktı Formatı & Dağıtım:",
                    style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.SemiBold)
                )
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    formatOptions.forEach { format ->
                        val isSelected = selectedFormat == format
                        FilterChip(
                            selected = isSelected,
                            onClick = { onSelectFormat(format) },
                            label = { Text(format, fontSize = 11.sp) },
                            leadingIcon = {
                                Icon(
                                    if (format.contains("9:16")) Icons.Default.PhoneAndroid else Icons.Default.Tv,
                                    contentDescription = null,
                                    modifier = Modifier.size(16.dp)
                                )
                            },
                            modifier = Modifier.weight(1f)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "Hedef İSG Akademi Portali:",
                    style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.SemiBold)
                )
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    domainOptions.forEach { dom ->
                        val isSelected = selectedDomain == dom
                        FilterChip(
                            selected = isSelected,
                            onClick = { onSelectDomain(dom) },
                            label = { Text(dom, fontSize = 11.sp) },
                            modifier = Modifier.weight(1f)
                        )
                    }
                }
            }
        }

        // Action Trigger Button
        Button(
            onClick = onStartGeneration,
            enabled = activeJobStatus == VideoJobStatus.IDLE || activeJobStatus == VideoJobStatus.COMPLETED || activeJobStatus == VideoJobStatus.FAILED,
            modifier = Modifier
                .fillMaxWidth()
                .height(52.dp)
                .testTag("btn_start_video_pipeline"),
            shape = RoundedCornerShape(14.dp),
            colors = ButtonDefaults.buttonColors(
                containerColor = GeminiPurple
            )
        ) {
            Icon(Icons.Default.AutoAwesome, contentDescription = null, modifier = Modifier.size(20.dp))
            Spacer(modifier = Modifier.width(8.dp))
            Text(
                text = if (activeJobStatus == VideoJobStatus.IDLE || activeJobStatus == VideoJobStatus.COMPLETED) {
                    "🎬 Klon Sesle AI Video Üretimini Başlat"
                } else {
                    "⚙️ Video Üretiliyor..."
                },
                style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold)
            )
        }

        Spacer(modifier = Modifier.height(20.dp))
    }
}

@Composable
fun VoiceProfilesSection(
    voiceProfiles: List<ClonedVoiceProfile>,
    selectedVoice: ClonedVoiceProfile,
    onSelectVoice: (ClonedVoiceProfile) -> Unit,
    onAddNewVoice: () -> Unit
) {
    val context = LocalContext.current

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f)),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.2f))
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "Ses Klonlama Laboratuvarı",
                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                        )
                        Text(
                            text = "10-30 saniyelik temiz ses kaydıyla ElevenLabs ve Cloud TTS üzerinden eğitilmiş profiller.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    Button(
                        onClick = onAddNewVoice,
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.testTag("btn_add_voice_profile")
                    ) {
                        Icon(Icons.Default.Mic, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Yeni Profil", fontSize = 12.sp)
                    }
                }
            }
        }

        items(voiceProfiles) { profile ->
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.2f))
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Surface(
                                shape = CircleShape,
                                color = if (profile.gender == "Kadın") GeminiPurple.copy(alpha = 0.15f) else IdxBlue.copy(alpha = 0.15f),
                                modifier = Modifier.size(42.dp)
                            ) {
                                Box(contentAlignment = Alignment.Center) {
                                    Icon(
                                        Icons.Default.GraphicEq,
                                        contentDescription = null,
                                        tint = if (profile.gender == "Kadın") GeminiPurple else IdxBlue,
                                        modifier = Modifier.size(24.dp)
                                    )
                                }
                            }

                            Column {
                                Text(
                                    text = profile.name,
                                    style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold)
                                )
                                Text(
                                    text = "${profile.provider} • ID: ${profile.voiceId.take(12)}...",
                                    style = MaterialTheme.typography.labelSmall.copy(fontFamily = FontFamily.Monospace),
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }

                        Surface(
                            shape = RoundedCornerShape(6.dp),
                            color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.5f)
                        ) {
                            Text(
                                text = "${profile.gender} • ${profile.language}",
                                style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary),
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))
                    Text(
                        text = profile.description,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurface
                    )

                    Spacer(modifier = Modifier.height(12.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Stabilite: %${(profile.stability * 100).toInt()} • Benzerlik: %${(profile.similarityBoost * 100).toInt()}",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )

                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedButton(
                                onClick = {
                                    Toast.makeText(context, "${profile.name} ses örneği çalınıyor... (44.1kHz Hi-Res)", Toast.LENGTH_SHORT).show()
                                },
                                shape = RoundedCornerShape(8.dp),
                                contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp)
                            ) {
                                Icon(Icons.Default.PlayArrow, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("Ses Örneği Dinle", fontSize = 11.sp)
                            }

                            Button(
                                onClick = { onSelectVoice(profile) },
                                shape = RoundedCornerShape(8.dp),
                                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp),
                                colors = if (selectedVoice.id == profile.id) ButtonDefaults.buttonColors(containerColor = SuccessEmerald) else ButtonDefaults.buttonColors()
                            ) {
                                Text(if (selectedVoice.id == profile.id) "Seçili Ses" else "Seç", fontSize = 11.sp)
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun GeneratedVideosSection(
    jobs: List<VideoGenerationPipelineJob>,
    onDeleteJob: (String) -> Unit
) {
    val context = LocalContext.current

    if (jobs.isEmpty()) {
        Box(
            modifier = Modifier.fillMaxSize(),
            contentAlignment = Alignment.Center
        ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Icon(
                    Icons.Default.VideoLibrary,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.5f),
                    modifier = Modifier.size(56.dp)
                )
                Spacer(modifier = Modifier.height(10.dp))
                Text(
                    text = "Henüz üretilmiş bir video bulunmuyor.",
                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                )
                Text(
                    text = "Video Stüdyosu sekmesinden senaryonuzu girip klon sesle video üretebilirsiniz.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    } else {
        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            items(jobs) { job ->
                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.2f))
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = job.title,
                                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                                Text(
                                    text = "${job.courseDomain} • ${job.createdAt} • ${job.durationSeconds} sn",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }

                            IconButton(onClick = { onDeleteJob(job.id) }) {
                                Icon(Icons.Default.DeleteOutline, contentDescription = "Sil", tint = ErrorRose)
                            }
                        }

                        Spacer(modifier = Modifier.height(8.dp))

                        // Video Mock Player Visual Container
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(130.dp)
                                .clip(RoundedCornerShape(10.dp))
                                .background(Color(0xFF0F172A)),
                            contentAlignment = Alignment.Center
                        ) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Surface(
                                    shape = CircleShape,
                                    color = MaterialTheme.colorScheme.primary,
                                    modifier = Modifier
                                        .size(44.dp)
                                        .clickable {
                                            Toast.makeText(context, "H.264 Video Önizlemesi Oynatılıyor: ${job.outputVideoUrl}", Toast.LENGTH_SHORT).show()
                                        }
                                ) {
                                    Box(contentAlignment = Alignment.Center) {
                                        Icon(Icons.Default.PlayArrow, contentDescription = "Oynat", tint = Color.White)
                                    }
                                }
                                Spacer(modifier = Modifier.height(6.dp))
                                Text(
                                    text = "AI Avatar: ${job.avatarStyle} • ${job.voiceProfile.name}",
                                    style = MaterialTheme.typography.labelSmall.copy(color = Color.LightGray, fontSize = 10.sp)
                                )
                            }

                            Surface(
                                shape = RoundedCornerShape(4.dp),
                                color = Color.Black.copy(alpha = 0.7f),
                                modifier = Modifier
                                    .align(Alignment.BottomEnd)
                                    .padding(8.dp)
                            ) {
                                Text(
                                    text = "00:${job.durationSeconds} / MP4",
                                    style = MaterialTheme.typography.labelSmall.copy(color = Color.White, fontSize = 9.sp),
                                    modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp)
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(10.dp))
                        Text(
                            text = job.scriptText,
                            style = MaterialTheme.typography.bodySmall,
                            maxLines = 2,
                            overflow = TextOverflow.Ellipsis,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )

                        Spacer(modifier = Modifier.height(12.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            OutlinedButton(
                                onClick = {
                                    val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                                    val clip = ClipData.newPlainText("Video URL", job.outputVideoUrl)
                                    clipboard.setPrimaryClip(clip)
                                    Toast.makeText(context, "Video indirme linki kopyalandı!", Toast.LENGTH_SHORT).show()
                                },
                                shape = RoundedCornerShape(8.dp),
                                modifier = Modifier.weight(1f)
                            ) {
                                Icon(Icons.Default.Link, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("Linki Kopyala", fontSize = 11.sp)
                            }

                            Button(
                                onClick = {
                                    Toast.makeText(context, "Video LMS & Portal'a aktarıldı: ${job.courseDomain}", Toast.LENGTH_SHORT).show()
                                },
                                shape = RoundedCornerShape(8.dp),
                                colors = ButtonDefaults.buttonColors(containerColor = SuccessEmerald),
                                modifier = Modifier.weight(1f)
                            ) {
                                Icon(Icons.Default.CloudUpload, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("LMS'e Aktar", fontSize = 11.sp)
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun CreateVoiceProfileDialog(
    onDismiss: () -> Unit,
    onCreate: (String, String, String, String, String, Float, Float) -> Unit
) {
    var name by remember { mutableStateOf("") }
    var provider by remember { mutableStateOf("ElevenLabs Instant Voice Clone") }
    val providerOptions = listOf(
        "ElevenLabs Instant Voice Clone",
        "Google Cloud Custom Voice",
        "Gemini Multimodal Live Voice"
    )
    var voiceId by remember { mutableStateOf("") }
    var gender by remember { mutableStateOf("Erkek") }
    var description by remember { mutableStateOf("") }
    var stability by remember { mutableFloatStateOf(0.75f) }
    var similarityBoost by remember { mutableFloatStateOf(0.85f) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text(
                text = "🎙️ Yeni Klon Ses Profili Ekle",
                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
            )
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text("Eğitmen / Profil Adı") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                Text("TTS Sağlayıcı Motoru:", style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold))
                providerOptions.forEach { opt ->
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { provider = opt }
                    ) {
                        RadioButton(selected = provider == opt, onClick = { provider = opt })
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(opt, style = MaterialTheme.typography.bodySmall)
                    }
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    FilterChip(
                        selected = gender == "Erkek",
                        onClick = { gender = "Erkek" },
                        label = { Text("Erkek Sesi") },
                        modifier = Modifier.weight(1f)
                    )
                    FilterChip(
                        selected = gender == "Kadın",
                        onClick = { gender = "Kadın" },
                        label = { Text("Kadın Sesi") },
                        modifier = Modifier.weight(1f)
                    )
                }

                OutlinedTextField(
                    value = voiceId,
                    onValueChange = { voiceId = it },
                    label = { Text("Model / Voice ID (Opsiyonel)") },
                    placeholder = { Text("Örn: 21m00Tcm4TlvDq8ikWAM") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = description,
                    onValueChange = { description = it },
                    label = { Text("Ses Karakteri & Açıklama") },
                    placeholder = { Text("Örn: Otoriter saha şefi tonu") },
                    minLines = 2,
                    modifier = Modifier.fillMaxWidth()
                )

                Text("Stabilite Ayarı: %${(stability * 100).toInt()}", style = MaterialTheme.typography.labelSmall)
                Slider(
                    value = stability,
                    onValueChange = { stability = it },
                    valueRange = 0.1f..1.0f
                )

                Text("Benzerlik Artışı: %${(similarityBoost * 100).toInt()}", style = MaterialTheme.typography.labelSmall)
                Slider(
                    value = similarityBoost,
                    onValueChange = { similarityBoost = it },
                    valueRange = 0.1f..1.0f
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    onCreate(name, provider, voiceId, gender, description, stability, similarityBoost)
                },
                enabled = name.isNotBlank()
            ) {
                Text("Profili Kaydet")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("İptal")
            }
        }
    )
}
