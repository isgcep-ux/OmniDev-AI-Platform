package com.example.ui.isg

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Assignment
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.IsgPlugin
import com.example.ui.components.SectionHeader
import com.example.ui.theme.GeminiGreen
import com.example.ui.theme.GeminiPurple
import com.example.ui.theme.IdxBlue

@Composable
fun IsgPluginsScreen(
    plugins: List<IsgPlugin>,
    onToggleInstall: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    var searchQuery by remember { mutableStateOf("") }
    var selectedDomain by remember { mutableStateOf("Tümü") }
    var viewingManifestPlugin by remember { mutableStateOf<IsgPlugin?>(null) }
    val clipboard = LocalClipboardManager.current
    var snackbarMessage by remember { mutableStateOf<String?>(null) }

    val filteredPlugins = remember(plugins, searchQuery, selectedDomain) {
        plugins.filter { plugin ->
            val matchesDomain = when (selectedDomain) {
                "isgcepakademi.com" -> plugin.domain == "isgcepakademi.com"
                "isgcepakademi.com.tr" -> plugin.domain == "isgcepakademi.com.tr"
                "isgcepakademi.xyz" -> plugin.domain == "isgcepakademi.xyz"
                else -> true
            }
            val matchesQuery = plugin.title.contains(searchQuery, ignoreCase = true) ||
                    plugin.description.contains(searchQuery, ignoreCase = true) ||
                    plugin.category.contains(searchQuery, ignoreCase = true)
            matchesDomain && matchesQuery
        }
    }

    Scaffold(
        snackbarHost = {
            snackbarMessage?.let { msg ->
                Snackbar(
                    modifier = Modifier.padding(16.dp),
                    action = {
                        TextButton(onClick = { snackbarMessage = null }) {
                            Text("Tamam", color = Color.White)
                        }
                    }
                ) {
                    Text(msg)
                }
            }
        }
    ) { innerPadding ->
        LazyColumn(
            modifier = modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp),
            contentPadding = PaddingValues(top = 16.dp, bottom = 32.dp)
        ) {
            item {
                SectionHeader(
                    title = "İSG Cep Akademi Eklenti Merkezi",
                    subtitle = "isgcepakademi.com, isgcepakademi.com.tr & isgcepakademi.xyz resmi uzantıları"
                )
            }

            // Domain Badge Banner
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.35f)
                    ),
                    border = CardDefaults.outlinedCardBorder()
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(44.dp)
                                .clip(CircleShape)
                                .background(MaterialTheme.colorScheme.primary),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.Extension,
                                contentDescription = null,
                                tint = Color.White
                            )
                        }
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "Entegre İSG Portalları & Servisleri",
                                style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold)
                            )
                            Row(
                                horizontalArrangement = Arrangement.spacedBy(6.dp),
                                modifier = Modifier.padding(top = 4.dp)
                            ) {
                                Surface(
                                    color = GeminiGreen.copy(alpha = 0.15f),
                                    shape = RoundedCornerShape(6.dp)
                                ) {
                                    Text(
                                        text = "🎓 isgcepakademi.com",
                                        style = MaterialTheme.typography.labelSmall.copy(
                                            fontWeight = FontWeight.SemiBold,
                                            color = GeminiGreen
                                        ),
                                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                    )
                                }
                                Surface(
                                    color = IdxBlue.copy(alpha = 0.15f),
                                    shape = RoundedCornerShape(6.dp)
                                ) {
                                    Text(
                                        text = "🌐 .com.tr",
                                        style = MaterialTheme.typography.labelSmall.copy(
                                            fontWeight = FontWeight.SemiBold,
                                            color = IdxBlue
                                        ),
                                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                    )
                                }
                                Surface(
                                    color = GeminiPurple.copy(alpha = 0.15f),
                                    shape = RoundedCornerShape(6.dp)
                                ) {
                                    Text(
                                        text = "⚡ .xyz",
                                        style = MaterialTheme.typography.labelSmall.copy(
                                            fontWeight = FontWeight.SemiBold,
                                            color = GeminiPurple
                                        ),
                                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                    )
                                }
                            }
                        }
                    }
                }
            }

            // Search Bar & Filter Chips
            item {
                OutlinedTextField(
                    value = searchQuery,
                    onValueChange = { searchQuery = it },
                    placeholder = { Text("Eklenti, mevzuat, risk veya konu ara...") },
                    leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                    trailingIcon = {
                        if (searchQuery.isNotEmpty()) {
                            IconButton(onClick = { searchQuery = "" }) {
                                Icon(Icons.Default.Clear, contentDescription = "Temizle")
                            }
                        }
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("isg_plugin_search"),
                    shape = RoundedCornerShape(12.dp),
                    singleLine = true
                )
            }

            // Domain filter chips
            item {
                LazyRow(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    val domains = listOf("Tümü", "isgcepakademi.com", "isgcepakademi.com.tr", "isgcepakademi.xyz")
                    items(domains) { dom ->
                        val isSelected = selectedDomain == dom
                        FilterChip(
                            selected = isSelected,
                            onClick = { selectedDomain = dom },
                            label = { Text(dom) },
                            leadingIcon = {
                                if (isSelected) {
                                    Icon(Icons.Default.Check, contentDescription = null, modifier = Modifier.size(16.dp))
                                }
                            },
                            modifier = Modifier.testTag("filter_$dom")
                        )
                    }
                }
            }

            // Plugins List
            items(filteredPlugins, key = { it.id }) { plugin ->
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("plugin_card_${plugin.id}"),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.45f)
                    ),
                    border = CardDefaults.outlinedCardBorder()
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(8.dp),
                                modifier = Modifier.weight(1f)
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(36.dp)
                                        .clip(RoundedCornerShape(8.dp))
                                        .background(
                                            when {
                                                plugin.domain == "isgcepakademi.com" -> GeminiGreen.copy(alpha = 0.2f)
                                                plugin.domain.contains("xyz") -> GeminiPurple.copy(alpha = 0.2f)
                                                else -> IdxBlue.copy(alpha = 0.2f)
                                            }
                                        ),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        imageVector = when (plugin.category) {
                                            "Mevzuat" -> Icons.Default.Gavel
                                            "Risk Analizi" -> Icons.Default.Shield
                                            "Sınav & Eğitim", "Eğitim & Global" -> Icons.Default.School
                                            "Kâtip & Atama" -> Icons.AutoMirrored.Filled.Assignment
                                            "Raporlama & AI" -> Icons.Default.AutoAwesome
                                            else -> Icons.Default.Extension
                                        },
                                        contentDescription = null,
                                        tint = when {
                                            plugin.domain == "isgcepakademi.com" -> GeminiGreen
                                            plugin.domain.contains("xyz") -> GeminiPurple
                                            else -> IdxBlue
                                        },
                                        modifier = Modifier.size(20.dp)
                                    )
                                }
                                Column {
                                    Text(
                                        text = plugin.title,
                                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                                    )
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                                    ) {
                                        Text(
                                            text = plugin.domain,
                                            style = MaterialTheme.typography.labelSmall.copy(
                                                color = when {
                                                    plugin.domain == "isgcepakademi.com" -> GeminiGreen
                                                    plugin.domain.contains("xyz") -> GeminiPurple
                                                    else -> IdxBlue
                                                },
                                                fontWeight = FontWeight.SemiBold
                                            )
                                        )
                                        Text(
                                            text = "• v${plugin.version}",
                                            style = MaterialTheme.typography.labelSmall,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                        Text(
                                            text = "• ★ ${plugin.rating}",
                                            style = MaterialTheme.typography.labelSmall.copy(color = GeminiGreen)
                                        )
                                    }
                                }
                            }

                            FilledTonalButton(
                                onClick = { onToggleInstall(plugin.id) },
                                colors = ButtonDefaults.filledTonalButtonColors(
                                    containerColor = if (plugin.isInstalled) GeminiGreen.copy(alpha = 0.2f)
                                    else MaterialTheme.colorScheme.primaryContainer,
                                    contentColor = if (plugin.isInstalled) GeminiGreen
                                    else MaterialTheme.colorScheme.primary
                                ),
                                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                                shape = RoundedCornerShape(8.dp),
                                modifier = Modifier.testTag("install_btn_${plugin.id}")
                            ) {
                                Icon(
                                    imageVector = if (plugin.isInstalled) Icons.Default.CheckCircle else Icons.Default.Download,
                                    contentDescription = null,
                                    modifier = Modifier.size(16.dp)
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(if (plugin.isInstalled) "Aktif" else "Yükle")
                            }
                        }

                        Text(
                            text = plugin.description,
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )

                        // Features List
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(8.dp))
                                .background(MaterialTheme.colorScheme.surface)
                                .padding(10.dp),
                            verticalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            Text(
                                text = "Öne Çıkan Özellikler:",
                                style = MaterialTheme.typography.labelSmall.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.primary
                                )
                            )
                            plugin.features.forEach { feature ->
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.CheckCircleOutline,
                                        contentDescription = null,
                                        modifier = Modifier.size(14.dp),
                                        tint = GeminiGreen
                                    )
                                    Text(
                                        text = feature,
                                        style = MaterialTheme.typography.bodySmall
                                    )
                                }
                            }
                        }

                        // Bottom Actions: Manifest Viewer & API Copy
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            OutlinedButton(
                                onClick = { viewingManifestPlugin = plugin },
                                modifier = Modifier.weight(1f),
                                shape = RoundedCornerShape(8.dp),
                                contentPadding = PaddingValues(vertical = 6.dp)
                            ) {
                                Icon(Icons.Default.Code, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("Manifest.json", fontSize = 12.sp)
                            }
                            OutlinedButton(
                                onClick = {
                                    clipboard.setText(AnnotatedString(plugin.apiEndpoints.joinToString("\n")))
                                    snackbarMessage = "${plugin.title} API uç noktaları panoya kopyalandı."
                                },
                                modifier = Modifier.weight(1f),
                                shape = RoundedCornerShape(8.dp),
                                contentPadding = PaddingValues(vertical = 6.dp)
                            ) {
                                Icon(Icons.Default.ContentCopy, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("API Kopyala", fontSize = 12.sp)
                            }
                        }
                    }
                }
            }
        }
    }

    // Manifest Dialog
    viewingManifestPlugin?.let { plugin ->
        AlertDialog(
            onDismissRequest = { viewingManifestPlugin = null },
            title = {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Icon(Icons.Default.Extension, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                    Text(text = "${plugin.title} - Manifest")
                }
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        text = "Kaynak Domain: ${plugin.domain}",
                        style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold)
                    )
                    Surface(
                        modifier = Modifier
                            .fillMaxWidth()
                            .heightIn(max = 260.dp),
                        shape = RoundedCornerShape(8.dp),
                        color = Color(0xFF1E1E2E)
                    ) {
                        Text(
                            text = plugin.manifestJson,
                            fontFamily = FontFamily.Monospace,
                            fontSize = 11.sp,
                            color = Color(0xFFCDD6F4),
                            modifier = Modifier.padding(12.dp)
                        )
                    }
                }
            },
            confirmButton = {
                TextButton(
                    onClick = {
                        clipboard.setText(AnnotatedString(plugin.manifestJson))
                        viewingManifestPlugin = null
                        snackbarMessage = "Manifest.json kopyalandı!"
                    }
                ) {
                    Text("Panoya Kopyala")
                }
            },
            dismissButton = {
                TextButton(onClick = { viewingManifestPlugin = null }) {
                    Text("Kapat")
                }
            }
        )
    }
}
