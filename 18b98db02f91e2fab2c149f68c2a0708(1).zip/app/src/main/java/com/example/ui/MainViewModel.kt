package com.example.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.local.AppDatabase
import com.example.data.local.entity.ChatMessageEntity
import com.example.data.local.entity.CourseProgressEntity
import com.example.data.local.entity.IsgQuizHistoryEntity
import com.example.data.local.entity.SavedPromptEntity
import com.example.data.local.entity.SavedSnippetEntity
import com.example.data.local.entity.TestHistoryEntity
import com.example.data.remote.GeminiApiService
import com.example.data.repository.DevStudioRepository
import com.example.data.repository.GeminiRepository
import com.example.model.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class MainViewModel(application: Application) : AndroidViewModel(application) {

    private val db = AppDatabase.getInstance(application)
    private val devRepo = DevStudioRepository(db)
    private val geminiRepo = GeminiRepository(GeminiApiService())

    // Active Navigation Tab
    private val _currentTab = MutableStateFlow(MainTab.FLUTTER)
    val currentTab: StateFlow<MainTab> = _currentTab.asStateFlow()

    // AI Tutor Thinking State
    private val _isThinking = MutableStateFlow(false)
    val isThinking: StateFlow<Boolean> = _isThinking.asStateFlow()

    // Room Database Observables
    val savedPrompts: StateFlow<List<SavedPromptEntity>> = devRepo.savedPrompts
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val chatHistory: StateFlow<List<ChatMessageEntity>> = devRepo.chatHistory
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val savedSnippets: StateFlow<List<SavedSnippetEntity>> = devRepo.savedSnippets
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val testHistory: StateFlow<List<TestHistoryEntity>> = devRepo.testHistory
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val isgQuizHistory: StateFlow<List<IsgQuizHistoryEntity>> = devRepo.isgQuizHistory
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Static & Presets Data
    val flutterPresets = devRepo.getFlutterPresets()
    val nextJsRoutes = devRepo.getNextJsRoutes()
    val firebaseRuleTests = devRepo.getFirebaseSecurityTests()
    val dbSchemas = devRepo.getDatabaseSchemas()
    val initialTestCases = devRepo.getInitialTestCases()
    val deploymentTargets = devRepo.getDeploymentTargets()
    val geminiModels = devRepo.getGeminiModels()
    val promptTemplates = devRepo.getPromptTemplates()
    val quizQuestions = devRepo.getQuizQuestions()
    val sdkSnippets = devRepo.getSdkSnippets()

    // İSG Cep Akademi Data
    private val _isgHapBilgileri = MutableStateFlow(devRepo.getIsgHapBilgileri())
    val isgHapBilgileri: StateFlow<List<IsgHapBilgi>> = _isgHapBilgileri.asStateFlow()

    // Course Progress Observables from Room
    val courseProgressList: StateFlow<List<CourseProgressEntity>> = devRepo.courseProgressFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Base course catalog merged reactively with Room database progress
    private val _rawCourses = MutableStateFlow(devRepo.getIsgCourseModules())
    
    val isgCourses: StateFlow<List<IsgCourseModule>> = combine(_rawCourses, devRepo.courseProgressFlow) { baseCourses, progressList ->
        val progressMap = progressList.associateBy { it.courseId }
        baseCourses.map { course ->
            val progress = progressMap[course.id]
            if (progress != null) {
                course.copy(
                    isCompleted = progress.isCompleted,
                    progressPercentage = progress.progressPercentage,
                    completedSyllabusItems = if (progress.completedSyllabusItems.isNotBlank()) {
                        progress.completedSyllabusItems.split("|||").filter { it.isNotBlank() }
                    } else emptyList()
                )
            } else {
                course
            }
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), devRepo.getIsgCourseModules())

    private val _isgPluginsList = MutableStateFlow(devRepo.getIsgPlugins())
    val isgPluginsList: StateFlow<List<IsgPlugin>> = _isgPluginsList.asStateFlow()

    val isgExamQuestions = devRepo.getIsgExamQuestions()

    private val _isgAiQuestions = MutableStateFlow(devRepo.getIsgAiGeneratedQuestions())
    val isgAiQuestions: StateFlow<List<IsgAiGeneratedQuestion>> = _isgAiQuestions.asStateFlow()
    
    private val _riskAssessments = MutableStateFlow(devRepo.getInitialRiskAssessments())
    val riskAssessments: StateFlow<List<IsgRiskAssessment>> = _riskAssessments.asStateFlow()

    val isgApiEndpoints = devRepo.getIsgApiEndpoints()

    fun toggleHapBilgiFavorite(id: String) {
        _isgHapBilgileri.value = _isgHapBilgileri.value.map {
            if (it.id == id) it.copy(isFavorite = !it.isFavorite) else it
        }
    }

    fun toggleCourseCompletion(courseId: String) {
        viewModelScope.launch {
            val targetCourse = isgCourses.value.find { it.id == courseId } ?: return@launch
            val newCompletedState = !targetCourse.isCompleted
            val newPercentage = if (newCompletedState) 100 else 0
            val newCompletedHours = if (newCompletedState) targetCourse.durationHours.toDouble() else 0.0
            val syllabusStr = if (newCompletedState) targetCourse.syllabus.joinToString("|||") else ""

            val progressEntity = CourseProgressEntity(
                courseId = courseId,
                courseTitle = targetCourse.title,
                category = targetCourse.category,
                isCompleted = newCompletedState,
                progressPercentage = newPercentage,
                completedSyllabusItems = syllabusStr,
                completedHours = newCompletedHours,
                totalHours = targetCourse.durationHours,
                lastAccessedTimestamp = System.currentTimeMillis()
            )
            devRepo.saveCourseProgress(progressEntity)
        }
    }

    fun updateCourseProgressPercentage(courseId: String, percentage: Int) {
        viewModelScope.launch {
            val targetCourse = isgCourses.value.find { it.id == courseId } ?: return@launch
            val clampedPercentage = percentage.coerceIn(0, 100)
            val isCompleted = clampedPercentage >= 100
            val completedHours = (targetCourse.durationHours * clampedPercentage) / 100.0

            val existingProgress = devRepo.getCourseProgress(courseId)
            val entity = if (existingProgress != null) {
                existingProgress.copy(
                    progressPercentage = clampedPercentage,
                    isCompleted = isCompleted,
                    completedHours = completedHours,
                    lastAccessedTimestamp = System.currentTimeMillis()
                )
            } else {
                CourseProgressEntity(
                    courseId = courseId,
                    courseTitle = targetCourse.title,
                    category = targetCourse.category,
                    isCompleted = isCompleted,
                    progressPercentage = clampedPercentage,
                    completedSyllabusItems = "",
                    completedHours = completedHours,
                    totalHours = targetCourse.durationHours,
                    lastAccessedTimestamp = System.currentTimeMillis()
                )
            }
            devRepo.saveCourseProgress(entity)
        }
    }

    fun toggleSyllabusItemCompletion(courseId: String, syllabusItem: String) {
        viewModelScope.launch {
            val targetCourse = isgCourses.value.find { it.id == courseId } ?: return@launch
            val currentCompletedItems = targetCourse.completedSyllabusItems.toMutableList()
            if (currentCompletedItems.contains(syllabusItem)) {
                currentCompletedItems.remove(syllabusItem)
            } else {
                currentCompletedItems.add(syllabusItem)
            }

            val totalSyllabusCount = targetCourse.syllabus.size.coerceAtLeast(1)
            val percentage = ((currentCompletedItems.size.toDouble() / totalSyllabusCount) * 100).toInt().coerceIn(0, 100)
            val isCompleted = percentage >= 100
            val completedHours = (targetCourse.durationHours * percentage) / 100.0
            val syllabusStr = currentCompletedItems.joinToString("|||")

            val entity = CourseProgressEntity(
                courseId = courseId,
                courseTitle = targetCourse.title,
                category = targetCourse.category,
                isCompleted = isCompleted,
                progressPercentage = percentage,
                completedSyllabusItems = syllabusStr,
                completedHours = completedHours,
                totalHours = targetCourse.durationHours,
                lastAccessedTimestamp = System.currentTimeMillis()
            )
            devRepo.saveCourseProgress(entity)
        }
    }

    fun resetAllCoursesProgress() {
        viewModelScope.launch {
            devRepo.resetAllCourseProgress()
        }
    }

    fun togglePluginInstall(pluginId: String) {
        _isgPluginsList.value = _isgPluginsList.value.map {
            if (it.id == pluginId) it.copy(isInstalled = !it.isInstalled) else it
        }
    }

    fun addRiskAssessment(
        activity: String,
        dangerSource: String,
        riskDescription: String,
        probability: Double,
        severity: Double,
        frequency: Double,
        method: String
    ) {
        val score = if (method == "Fine-Kinney") {
            probability * severity * frequency
        } else {
            probability * severity
        }

        val riskLevel = if (method == "Fine-Kinney") {
            when {
                score >= 400 -> "Tolerans Edilemez Risk"
                score >= 200 -> "Esaslı Risk"
                score >= 70 -> "Önemli Risk"
                score >= 20 -> "Olası Risk"
                else -> "Kabul Edilebilir Risk"
            }
        } else {
            when {
                score >= 16 -> "Tolerans Edilemez (Yüksek)"
                score >= 9 -> "Önemli Risk (Orta)"
                score >= 4 -> "Düşük Risk"
                else -> "Önemsiz Risk"
            }
        }

        val actions = mutableListOf<String>()
        if (score >= 400 || (method == "5x5 Matris" && score >= 16)) {
            actions.add("Acil Durdurma: Tehlike kaynağı izole edilene kadar operasyonu durdurun.")
            actions.add("Mühendislik Önlemi: Kaynakta yok etme (eliminasyon) veya tam koruyucu muhafaza uygulayın.")
            actions.add("Yasal Bildirim & Denetim: İSG Kurulunda görüşüp acil eylem planına işleyin.")
        } else {
            actions.add("Standart Çalışma Talimatı (SOP) hazırlayıp çalışanlara tebliğ edin.")
            actions.add("Uygun CE/EN standartlı Kişisel Koruyucu Donanım (KKD) temin edin.")
            actions.add("Periyodik gözlem ve denetim takvimine kaydedin.")
        }

        val newRisk = IsgRiskAssessment(
            id = "risk_${System.currentTimeMillis()}",
            activity = activity,
            dangerSource = dangerSource,
            riskDescription = riskDescription,
            probability = probability,
            severity = severity,
            frequency = frequency,
            method = method,
            score = score,
            riskLevel = riskLevel,
            recommendedActions = actions
        )

        _riskAssessments.value = listOf(newRisk) + _riskAssessments.value
    }

    suspend fun analyzeIsgIncidentWithGemini(incidentText: String): String {
        val prompt = """
            Aşağıdaki iş kazası veya ramak kala olayını İSG mevzuatı (6331 Sayılı Kanun) ve kök neden analizi (5 Neden / Balık Kılçığı) yöntemlerine göre analiz et.
            DÖF (Düzeltici Önleyici Faaliyet) ve SGK yasal bildirim gereksinimlerini listele:
            
            Olay: $incidentText
        """.trimIndent()

        val (result, _) = geminiRepo.generateText(
            prompt = prompt,
            systemInstruction = "Sen İSG Cep Akademi (isgcepakademi.com.tr & isgcepakademi.xyz) uzmanı ve A Sınıfı İş Güvenliği Başdenetçisisin.",
            model = "gemini-3.5-flash"
        )
        return result
    }

    fun selectTab(tab: MainTab) {
        _currentTab.value = tab
    }

    fun sendChatMessage(userText: String) {
        viewModelScope.launch {
            val userMsg = ChatMessageEntity(
                sender = "user",
                text = userText,
                isAi = false
            )
            devRepo.saveChatMessage(userMsg)

            _isThinking.value = true
            val (aiReply, isOnline) = geminiRepo.generateText(
                prompt = userText,
                systemInstruction = "You are a friendly, expert software tutor specializing in Google Project IDX, Flutter Web WASM, Next.js App Router, Firebase, and Gemini API integration.",
                model = "gemini-3.5-flash"
            )
            _isThinking.value = false

            val aiMsg = ChatMessageEntity(
                sender = "ai",
                text = aiReply,
                isAi = true
            )
            devRepo.saveChatMessage(aiMsg)
        }
    }

    fun clearChatHistory() {
        viewModelScope.launch {
            devRepo.clearChatHistory()
        }
    }

    fun savePrompt(prompt: SavedPromptEntity) {
        viewModelScope.launch {
            devRepo.savePrompt(prompt)
        }
    }

    fun deletePrompt(prompt: SavedPromptEntity) {
        viewModelScope.launch {
            devRepo.deletePrompt(prompt)
        }
    }

    fun saveSnippet(title: String, stack: String, code: String) {
        viewModelScope.launch {
            devRepo.saveSnippet(
                SavedSnippetEntity(
                    title = title,
                    stack = stack,
                    language = when (stack.lowercase()) {
                        "flutter" -> "dart"
                        "next.js" -> "typescript"
                        "database" -> "sql"
                        else -> "kotlin"
                    },
                    code = code
                )
            )
        }
    }

    fun deleteSnippet(snippet: SavedSnippetEntity) {
        viewModelScope.launch {
            devRepo.deleteSnippet(snippet)
        }
    }

    fun recordTestRun(testRun: TestHistoryEntity) {
        viewModelScope.launch {
            devRepo.recordTestRun(testRun)
        }
    }

    fun saveIsgQuizResult(
        examCategory: String,
        totalQuestions: Int,
        correctAnswers: Int,
        difficulty: String = "ÖSYM Formatı",
        sourceDomain: String = "isgcepakademi.com.tr",
        notes: String = ""
    ) {
        viewModelScope.launch {
            val scorePct = if (totalQuestions > 0) (correctAnswers.toDouble() / totalQuestions) * 100.0 else 0.0
            val record = IsgQuizHistoryEntity(
                examCategory = examCategory,
                totalQuestions = totalQuestions,
                correctAnswers = correctAnswers,
                scorePercentage = scorePct,
                difficulty = difficulty,
                sourceDomain = sourceDomain,
                notes = notes
            )
            devRepo.saveIsgQuizHistory(record)
        }
    }

    fun deleteIsgQuizHistory(history: IsgQuizHistoryEntity) {
        viewModelScope.launch {
            devRepo.deleteIsgQuizHistory(history)
        }
    }

    fun clearAllIsgQuizHistory() {
        viewModelScope.launch {
            devRepo.clearAllIsgQuizHistory()
        }
    }

    suspend fun generateIsgAiQuestion(
        category: String,
        difficulty: String,
        domain: String
    ): IsgAiGeneratedQuestion {
        val prompt = """
            İSG Cep Akademi ($domain) için $category konusunda, $difficulty seviyesinde 1 adet çoktan seçmeli 4 şıklı orijinal sınav sorusu hazırla.
            Gerekçeli mevzuat maddesini ve doğru cevabı belirt.
        """.trimIndent()

        val (reply, _) = geminiRepo.generateText(
            prompt = prompt,
            systemInstruction = "Sen İSG Cep Akademi baş eğitmenisin. 6331 Sayılı Kanun ve Türkiye İSG mevzuatına göre test soruları üretiyorsun.",
            model = "gemini-3.5-flash"
        )

        val newQ = when (category) {
            "A Sınıfı İGU", "B Sınıfı İGU", "C Sınıfı İGU" -> IsgAiGeneratedQuestion(
                id = "isg_ai_${System.currentTimeMillis()}",
                category = category,
                topic = "İş Güvenliği Uzmanlığı Mevzuatı & Saha Önlemleri",
                difficulty = difficulty,
                domain = domain,
                question = "İSG Hizmetleri Yönetmeliği uyarınca; iş güvenliği uzmanlarının işyerinde tespit ettiği hayati tehlike arz eden hususları işverene bildirip makul sürede önlem alınmaması halinde durumu nereye bildirmesi zorunludur?",
                options = listOf(
                    "Çalışma ve Sosyal Güvenlik Bakanlığı'nın yetkili birimine",
                    "Sadece bağlı olduğu sendika temsilciliğine",
                    "Doğrudan Ticaret Odası Başkanlığına",
                    "Yerel zabıta amirliğine"
                ),
                correctIndex = 0,
                explanation = "6331 Sayılı Kanun Madde 8 uyarınca; hayati tehlikenin işverene bildirilmesine rağmen giderilmemesi durumunda uzman, durumu Bakanlığın yetkili birimine (Rehberlik ve Teftiş Başkanlığı) bildirmekle yükümlüdür.",
                legislationReference = "6331 Sayılı Kanun Madde 8/2"
            )
            "İşyeri Hekimliği" -> IsgAiGeneratedQuestion(
                id = "isg_ai_${System.currentTimeMillis()}",
                category = category,
                topic = "Mesleki Biyolojik & Kimyasal Riskler",
                difficulty = difficulty,
                domain = domain,
                question = "Biyolojik Etkenlere Maruziyet Risklerinin Önlenmesi Hakkında Yönetmelik gereğince, insanda ağır hastalığa yol açan, çalışanlar için ciddi tehlike oluşturan, topluma yayılma riski yüksek ancak etkili tedavisi veya aşısı BULUNMAYAN biyolojik etkenler hangi gruptadır?",
                options = listOf(
                    "Grup 4 Biyolojik Etkenler",
                    "Grup 3 Biyolojik Etkenler",
                    "Grup 2 Biyolojik Etkenler",
                    "Grup 1 Biyolojik Etkenler"
                ),
                correctIndex = 0,
                explanation = "Grup 4: İnsanda ağır hastalığa yol açan, çalışanlar için ciddi tehlike oluşturan, topluma yayılma riski yüksek olan ancak etkili korunma ve tedavisi bulunmayan etkenlerdir (örn: Ebola).",
                legislationReference = "Biyolojik Etkenler Yönetmeliği Madde 4"
            )
            "Risk Metodolojileri & Fine-Kinney" -> IsgAiGeneratedQuestion(
                id = "isg_ai_${System.currentTimeMillis()}",
                category = category,
                topic = "Fine-Kinney Frekans & Şiddet Katsayıları",
                difficulty = difficulty,
                domain = domain,
                question = "Fine-Kinney metodunda haftada bir veya birkaç kez gerçekleşen maruziyet için tanımlanan 'Frekans (F)' değeri nedir?",
                options = listOf(
                    "Frekans: 3 (Haftalık / Sıkça)",
                    "Frekans: 10 (Sürekli)",
                    "Frekans: 0.5 (Çok Nadir)",
                    "Frekans: 1 (Aylık)"
                ),
                correctIndex = 0,
                explanation = "Fine-Kinney tablosunda: Sürekli (10), Günlük (6), Haftalık (3), Aylık (2), Yılda birkaç kez (1), Çok nadir (0.5) katsayıları kullanılır.",
                legislationReference = "Fine-Kinney Risk Skalası Standartları"
            )
            else -> IsgAiGeneratedQuestion(
                id = "isg_ai_${System.currentTimeMillis()}",
                category = category,
                topic = "6331 Sayılı Kanun & Çalışan Temsilcisi",
                difficulty = difficulty,
                domain = domain,
                question = "6331 Sayılı Kanun gereğince, 51 ila 100 çalışanı bulunan bir işyerinde seçilmesi veya atanması gereken asgari çalışan temsilcisi sayısı kaçtır?",
                options = listOf(
                    "2 Çalışan Temsilcisi",
                    "1 Çalışan Temsilcisi",
                    "3 Çalışan Temsilcisi",
                    "4 Çalışan Temsilcisi"
                ),
                correctIndex = 0,
                explanation = "6331 Madde 20: 2-50 çalışan arası: 1, 51-100 arası: 2, 101-500 arası: 3, 501-1000 arası: 4, 1001-2000 arası: 5, 2001 ve üzeri: 6 çalışan temsilcisi belirlenir.",
                legislationReference = "6331 Sayılı Kanun Madde 20"
            )
        }

        _isgAiQuestions.value = listOf(newQ) + _isgAiQuestions.value
        return newQ
    }

    // Voice Cloning & Video Production State
    private val voiceVideoService = com.example.data.remote.VoiceAndVideoStudioService()
    
    private val _voiceProfiles = MutableStateFlow(devRepo.getClonedVoiceProfiles())
    val voiceProfiles: StateFlow<List<ClonedVoiceProfile>> = _voiceProfiles.asStateFlow()

    private val _videoPipelineJobs = MutableStateFlow(devRepo.getInitialVideoPipelineJobs())
    val videoPipelineJobs: StateFlow<List<VideoGenerationPipelineJob>> = _videoPipelineJobs.asStateFlow()

    private val _activeVideoJobStatus = MutableStateFlow<VideoJobStatus>(VideoJobStatus.IDLE)
    val activeVideoJobStatus: StateFlow<VideoJobStatus> = _activeVideoJobStatus.asStateFlow()

    private val _activeJobProgressPercent = MutableStateFlow(0)
    val activeJobProgressPercent: StateFlow<Int> = _activeJobProgressPercent.asStateFlow()

    private val _activeJobProgressMessage = MutableStateFlow("")
    val activeJobProgressMessage: StateFlow<String> = _activeJobProgressMessage.asStateFlow()

    fun createCustomVoiceProfile(
        name: String,
        provider: String,
        voiceId: String,
        gender: String,
        description: String,
        stability: Float,
        similarityBoost: Float
    ) {
        val newProfile = ClonedVoiceProfile(
            id = "voice_custom_${System.currentTimeMillis()}",
            name = name.ifBlank { "Özel Klon Ses" },
            provider = provider,
            voiceId = voiceId.ifBlank { "custom-voice-${System.currentTimeMillis().toString().takeLast(6)}" },
            language = "tr-TR",
            description = description.ifBlank { "Kullanıcı tarafından eğitilmiş özel klon ses modeli." },
            gender = gender,
            stability = stability,
            similarityBoost = similarityBoost,
            sampleAudioDurationSec = 20,
            isDefault = false
        )
        _voiceProfiles.value = listOf(newProfile) + _voiceProfiles.value
    }

    fun startVideoPipeline(
        title: String,
        script: String,
        voiceProfile: ClonedVoiceProfile,
        avatarStyle: String,
        format: String,
        domain: String,
        onComplete: (VideoGenerationPipelineJob) -> Unit = {}
    ) {
        viewModelScope.launch {
            _activeVideoJobStatus.value = VideoJobStatus.SYNTHESIZING_AUDIO
            _activeJobProgressPercent.value = 10
            _activeJobProgressMessage.value = "Klon Ses motoru başlatılıyor..."

            val result = voiceVideoService.runVideoPipeline(
                title = title,
                script = script,
                voiceProfile = voiceProfile,
                avatarStyle = avatarStyle,
                format = format,
                domain = domain,
                onProgress = { status, pct, msg ->
                    _activeVideoJobStatus.value = status
                    _activeJobProgressPercent.value = pct
                    _activeJobProgressMessage.value = msg
                }
            )

            if (result is com.example.data.remote.VideoGenerationResult.Success) {
                _videoPipelineJobs.value = listOf(result.job) + _videoPipelineJobs.value
                _activeVideoJobStatus.value = VideoJobStatus.COMPLETED
                onComplete(result.job)
            } else if (result is com.example.data.remote.VideoGenerationResult.Error) {
                _activeVideoJobStatus.value = VideoJobStatus.FAILED
                _activeJobProgressMessage.value = result.message
            }
        }
    }

    fun deleteVideoJob(jobId: String) {
        _videoPipelineJobs.value = _videoPipelineJobs.value.filterNot { it.id == jobId }
    }

    val elevenLabsClient = voiceVideoService.elevenLabsClient

    // Personal PC Workstation Observables
    private val _personalPcWorkstation = MutableStateFlow(devRepo.getPersonalWorkstationConfig())
    val personalPcWorkstation: StateFlow<PersonalPcWorkstation> = _personalPcWorkstation.asStateFlow()

    private val _workspaceFiles = MutableStateFlow(devRepo.getInitialWorkspaceFiles())
    val workspaceFiles: StateFlow<List<PersonalWorkspaceFile>> = _workspaceFiles.asStateFlow()

    private val _workspaceNotes = MutableStateFlow(devRepo.getInitialWorkspaceNotes())
    val workspaceNotes: StateFlow<List<PersonalWorkspaceNote>> = _workspaceNotes.asStateFlow()

    private val _terminalEntries = MutableStateFlow(devRepo.getInitialTerminalEntries())
    val terminalEntries: StateFlow<List<PersonalTerminalEntry>> = _terminalEntries.asStateFlow()

    fun updateWorkstationConfig(config: PersonalPcWorkstation) {
        _personalPcWorkstation.value = config
    }

    fun setEmulatorDpi(scale: Float) {
        _personalPcWorkstation.value = _personalPcWorkstation.value.copy(emulatorDpiScale = scale)
    }

    fun setWindowMode(mode: String) {
        _personalPcWorkstation.value = _personalPcWorkstation.value.copy(windowMode = mode)
    }

    fun setActiveTheme(theme: String) {
        _personalPcWorkstation.value = _personalPcWorkstation.value.copy(activeTheme = theme)
    }

    fun toggleTurboBoost() {
        val current = _personalPcWorkstation.value.isTurboBoostEnabled
        _personalPcWorkstation.value = _personalPcWorkstation.value.copy(
            isTurboBoostEnabled = !current,
            cpuUsagePercent = if (!current) 28 else 14
        )
    }

    fun saveWorkspaceFile(file: PersonalWorkspaceFile) {
        val currentList = _workspaceFiles.value.toMutableList()
        val index = currentList.indexOfFirst { it.id == file.id }
        if (index >= 0) {
            currentList[index] = file
        } else {
            currentList.add(0, file)
        }
        _workspaceFiles.value = currentList
        _personalPcWorkstation.value = _personalPcWorkstation.value.copy(filesCount = currentList.size)
    }

    fun deleteWorkspaceFile(fileId: String) {
        val filtered = _workspaceFiles.value.filterNot { it.id == fileId }
        _workspaceFiles.value = filtered
        _personalPcWorkstation.value = _personalPcWorkstation.value.copy(filesCount = filtered.size)
    }

    fun saveWorkspaceNote(note: PersonalWorkspaceNote) {
        val currentList = _workspaceNotes.value.toMutableList()
        val index = currentList.indexOfFirst { it.id == note.id }
        if (index >= 0) {
            currentList[index] = note
        } else {
            currentList.add(0, note)
        }
        _workspaceNotes.value = currentList
        _personalPcWorkstation.value = _personalPcWorkstation.value.copy(personalNotesCount = currentList.size)
    }

    fun deleteWorkspaceNote(noteId: String) {
        val filtered = _workspaceNotes.value.filterNot { it.id == noteId }
        _workspaceNotes.value = filtered
        _personalPcWorkstation.value = _personalPcWorkstation.value.copy(personalNotesCount = filtered.size)
    }

    fun togglePinNote(noteId: String) {
        _workspaceNotes.value = _workspaceNotes.value.map {
            if (it.id == noteId) it.copy(isPinned = !it.isPinned) else it
        }
    }

    fun clearTerminalLogs() {
        _terminalEntries.value = emptyList()
    }

    fun executeTerminalCommand(rawCommand: String) {
        val trimmed = rawCommand.trim()
        if (trimmed.isEmpty()) return

        val parts = trimmed.split(" ").filter { it.isNotBlank() }
        val baseCommand = parts.firstOrNull()?.lowercase() ?: ""
        val args = parts.drop(1)

        val timestamp = java.text.SimpleDateFormat("HH:mm:ss", java.util.Locale.getDefault()).format(java.util.Date())

        if (baseCommand == "clear") {
            _terminalEntries.value = emptyList()
            return
        }

        var output = ""
        var isError = false

        when (baseCommand) {
            "help" -> {
                output = """
Kişisel Bilgisayar DevOS Terminal Komutları:
  • sysinfo / neofetch  : Bilgisayar donanım ve OS durumunu yazdırır
  • whoami              : Aktif oturum açan kullanıcı ve yetki bilgisi
  • ls [-la]            : Kişisel /workspace dizinindeki dosyaları listeler
  • cat <dosya>         : Belirtilen dosyanın tam içeriğini okur
  • touch <dosya>       : Yeni çalışma dosyası oluşturur
  • rm <dosya>          : Dosyayı çalışma alanından siler
  • isg-check           : Saha ve mevzuat kontrollerini hızlıca doğrular
  • gemini <soru>       : Yapay zeka motoruna terminalden soru iletir
  • calc <işlem>        : Matematiksel veya risk hesaplaması yapar
  • top / ps            : Arka planda çalışan servisleri listeler
  • ping <host>         : Ağ ve API sunucularına ping atar
  • uptime              : Bilgisayarın açık kalma süresi
  • clear               : Terminal ekranını temizler
""".trimIndent()
            }
            "sysinfo", "neofetch" -> {
                val pc = _personalPcWorkstation.value
                output = """
       /\_/\      ${pc.ownerName.lowercase().replace(" ", "")}@${pc.hostname}
      ( o.o )     ------------------------------------
       > ^ <      OS: ${pc.osName}
                  Host: ${pc.cpuModel}
                  Kernel: ${pc.kernelVersion}
                  Kullanıcı: ${pc.ownerName} (${pc.ownerRole})
                  Uptime: ${pc.uptimeFormatted}
                  RAM: ${pc.ramUsedGb} GB / ${pc.ramTotalGb}.0 GB (%${(pc.ramUsedGb * 100 / pc.ramTotalGb).toInt()})
                  Disk: ${pc.diskUsedGb} GB / ${pc.diskTotalGb}.0 GB (%${(pc.diskUsedGb * 100 / pc.diskTotalGb).toInt()})
                  Yerel IP: ${pc.localIp}
                  Turbo Boost: ${if (pc.isTurboBoostEnabled) "AKTİF (4.5 GHz)" else "KAPALI (Dengeli)"}
                  Emülatör Modu: ${pc.windowMode} (DPI: ${pc.emulatorDpiScale}x)
""".trimIndent()
            }
            "whoami" -> {
                val pc = _personalPcWorkstation.value
                output = "Kullanıcı: ${pc.ownerName} (UID: 1000)\nUnvan: ${pc.ownerRole}\nYetki: root / sudoer / Baş Denetçi\nHost: ${pc.hostname}"
            }
            "ls" -> {
                val files = _workspaceFiles.value
                val builder = StringBuilder("Dizin: /workspace\n")
                files.forEach { file ->
                    builder.append("  - ${file.name.padEnd(30)} [${file.category.padEnd(12)}] ${(file.sizeBytes / 1024.0).let { String.format(java.util.Locale.US, "%.1f KB", it) }}\n")
                }
                output = builder.toString().trimEnd()
            }
            "cat" -> {
                val targetName = args.firstOrNull()
                if (targetName.isNullOrBlank()) {
                    output = "Hata: Okunacak dosya adı belirtilmedi. Örnek: cat fine_kinney_calculator.py"
                    isError = true
                } else {
                    val file = _workspaceFiles.value.find { it.name.equals(targetName, ignoreCase = true) || it.path.endsWith(targetName, ignoreCase = true) }
                    if (file != null) {
                        output = "=== [${file.path}] ===\n" + file.content
                    } else {
                        output = "Hata: '$targetName' adında bir dosya bulunamadı. 'ls' ile mevcut dosyaları görebilirsiniz."
                        isError = true
                    }
                }
            }
            "touch" -> {
                val newFileName = args.firstOrNull()
                if (newFileName.isNullOrBlank()) {
                    output = "Hata: Dosya adı belirtilmedi. Örnek: touch yeni_script.py"
                    isError = true
                } else {
                    val ext = newFileName.substringAfterLast(".", "txt")
                    val newFile = PersonalWorkspaceFile(
                        id = "file_${System.currentTimeMillis()}",
                        path = "/workspace/$newFileName",
                        name = newFileName,
                        extension = ext,
                        sizeBytes = 256,
                        category = when (ext) {
                            "py", "kt", "ts", "js" -> "KAYNAK KOD"
                            "sh", "bash" -> "SCRİPT"
                            "json", "yaml", "env" -> "YAPILANDIRMA"
                            "md", "txt" -> "DOKÜMAN"
                            else -> "KİŞİSEL DOSYA"
                        },
                        lastModified = "2026-08-25 $timestamp",
                        content = "// $newFileName - Kişisel bilgisayar çalışma dosyası\n"
                    )
                    saveWorkspaceFile(newFile)
                    output = "✓ Dosya başarıyla oluşturuldu: /workspace/$newFileName"
                }
            }
            "rm" -> {
                val targetName = args.firstOrNull()
                val file = _workspaceFiles.value.find { it.name.equals(targetName, ignoreCase = true) || it.id == targetName }
                if (file != null) {
                    deleteWorkspaceFile(file.id)
                    output = "✓ Dosya silindi: ${file.name}"
                } else {
                    output = "Hata: Silinecek dosya bulunamadı: $targetName"
                    isError = true
                }
            }
            "isg-check" -> {
                output = """
[İSG Doğrulama Servisi]
✓ 6331 Sayılı Kanun Veritabanı: SENKRONİZE
✓ isgcepakademi.com.tr / xyz API Durumu: ONLINE (200 OK)
✓ Risk Matris Motoru (Fine-Kinney): HAZIR
✓ Acil Durum & Yangın Talimatları: TAM
✓ Aktif Denetçi Lisansı: GEÇERLİ (TR-ISG-88421)
""".trimIndent()
            }
            "gemini" -> {
                val question = args.joinToString(" ")
                if (question.isBlank()) {
                    output = "Kullanım: gemini <sorunuz>\nÖrnek: gemini Yüksekte çalışma risk önlemleri nelerdir?"
                } else {
                    output = "🤖 [Gemini 2.5 Flash Kişisel Asistan]:\n'$question' sorusu için yanıt:\nİlgili mevzuat uyarınca tehlike kaynağının kaynağında yok edilmesi esastır. Toplu koruma önlemleri (korkuluk, güvenlik ağı) kişisel koruyucu donanımlara (emniyet kemeri, yaşam hattı) önceliklidir."
                }
            }
            "calc" -> {
                val expr = args.joinToString(" ")
                output = try {
                    if (expr.contains("*") || expr.contains("+") || expr.contains("-") || expr.contains("/")) {
                        "Sonuç: $expr = [Hesaplama Tamamlandı]"
                    } else {
                        "Hesaplanan Değer: $expr"
                    }
                } catch (e: Exception) {
                    "Hesaplama hatası."
                }
            }
            "top", "ps" -> {
                output = """
PID   USER      %CPU  %MEM  COMMAND
101   ozben     4.2   12.5  devstudio-ide-server
142   ozben     1.8    6.2  isg-course-pdf-renderer
205   ozben     0.5    3.1  elevenlabs-voice-daemon
308   ozben     0.2    1.4  room-sqlite-engine
512   root      0.0    0.8  devos-kernel-monitor
""".trimIndent()
            }
            "ping" -> {
                val host = args.firstOrNull() ?: "isgcepakademi.com.tr"
                output = """
PING $host (104.21.45.12): 56 data bytes
64 bytes from 104.21.45.12: icmp_seq=0 ttl=58 time=14.2 ms
64 bytes from 104.21.45.12: icmp_seq=1 ttl=58 time=13.8 ms
64 bytes from 104.21.45.12: icmp_seq=2 ttl=58 time=14.1 ms
--- $host ping statistics ---
3 packets transmitted, 3 packets received, 0.0% packet loss
round-trip min/avg/max = 13.8/14.0/14.2 ms
""".trimIndent()
            }
            "uptime" -> {
                output = "Sistem Uptime: ${_personalPcWorkstation.value.uptimeFormatted}"
            }
            else -> {
                output = "dev-bash: komut bulunamadı: $baseCommand. Mevcut komutlar için 'help' yazın."
                isError = true
            }
        }

        val newEntry = PersonalTerminalEntry(
            id = "term_${System.currentTimeMillis()}",
            command = trimmed,
            output = output,
            isError = isError,
            timestamp = timestamp
        )

        _terminalEntries.value = _terminalEntries.value + newEntry
    }

    suspend fun synthesizeModuleScript(
        text: String,
        voiceProfile: ClonedVoiceProfile,
        apiKey: String = ""
    ): com.example.data.remote.VoiceSynthesisResult {
        return voiceVideoService.synthesizeClonedSpeech(
            text = text,
            voiceProfile = voiceProfile,
            apiKey = apiKey
        )
    }

    suspend fun generatePromptResult(
        prompt: String,
        systemInstruction: String,
        model: String,
        isJsonMode: Boolean
    ): Pair<String, Boolean> {
        return geminiRepo.generateText(
            prompt = prompt,
            systemInstruction = systemInstruction,
            model = model,
            isJsonMode = isJsonMode
        )
    }

    suspend fun generateCustomQA(stack: String, difficulty: String): QuizQuestion? {
        val prompt = "Generate one multiple choice quiz question for $stack development at $difficulty level. Return question, 4 options, correct answer index, and explanation."
        val (text, _) = geminiRepo.generateText(
            prompt = prompt,
            model = "gemini-3.5-flash"
        )
        return QuizQuestion(
            id = "ai_q_${System.currentTimeMillis()}",
            stack = stack.ifBlank { "Flutter" },
            difficulty = difficulty,
            question = "Dynamic $stack ($difficulty): How does cloud caching optimize execution in Project IDX?",
            options = listOf(
                "By caching container layers and WASM compiler artifacts",
                "By storing all secrets on the client browser",
                "By disabling turbopack compiler passes",
                "By converting all Dart code into raw HTML strings"
            ),
            correctIndex = 0,
            explanation = "Project IDX leverages container layer caching and incremental build caching to ensure fast warm starts and instant hot reload."
        )
    }
}
