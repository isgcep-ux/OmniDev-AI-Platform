package com.example.ui.isg

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.IsgCourseModule
import com.example.ui.theme.*

data class CategoryProgressItem(
    val categoryName: String,
    val totalCourses: Int,
    val completedCourses: Int,
    val averagePercentage: Float,
    val color: Color
)

@Composable
fun IsgProgressRadialChart(
    courses: List<IsgCourseModule>,
    modifier: Modifier = Modifier
) {
    var chartMode by remember { mutableIntStateOf(0) } // 0: Çoklu Halka (Multi-Ring), 1: Tekli Gauge (Radial Gauge)

    // Calculate aggregated metrics from Room data
    val totalCoursesCount = courses.size.coerceAtLeast(1)
    val completedCoursesCount = courses.count { it.isCompleted }
    val overallPercentage = if (courses.isNotEmpty()) {
        (courses.sumOf { it.progressPercentage } / courses.size.toFloat()).coerceIn(0f, 100f)
    } else 0f

    val totalHours = courses.sumOf { it.durationHours }
    val completedHours = courses.sumOf { (it.durationHours * it.progressPercentage) / 100.0 }

    // Category progress metrics
    val categoryColors = listOf(
        Pair("Mevzuat & Hukuk", IdxBlue),
        Pair("Risk & Metodoloji", ErrorRose),
        Pair("Saha Güvenliği & KKD", FlutterCyan),
        Pair("Sağlık & İlkyardım", GeminiGreen),
        Pair("Global & Sertifikasyon", GeminiPurple)
    )

    val categoryProgressList = remember(courses) {
        val grouped = courses.groupBy { it.category }
        categoryColors.mapNotNull { (catName, color) ->
            val catCourses = grouped[catName]
            if (catCourses != null && catCourses.isNotEmpty()) {
                val catAvg = (catCourses.sumOf { it.progressPercentage } / catCourses.size.toFloat()).coerceIn(0f, 100f)
                val catCompleted = catCourses.count { it.isCompleted }
                CategoryProgressItem(
                    categoryName = catName,
                    totalCourses = catCourses.size,
                    completedCourses = catCompleted,
                    averagePercentage = catAvg,
                    color = color
                )
            } else null
        }
    }

    Card(
        modifier = modifier
            .fillMaxWidth()
            .testTag("card_isg_radial_progress"),
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.25f))
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            // Header with Room Live Sync badge and view toggle
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Text(
                            text = "📊 Akademik İlerleme Göstergesi",
                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                        )
                    }
                    Text(
                        text = "Room SQLite canlı veri akışı (Recharts RadialBar)",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }

                Surface(
                    shape = RoundedCornerShape(20.dp),
                    color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f),
                    modifier = Modifier.clip(RoundedCornerShape(20.dp))
                ) {
                    Row(
                        modifier = Modifier.padding(2.dp),
                        horizontalArrangement = Arrangement.spacedBy(2.dp)
                    ) {
                        IconButton(
                            onClick = { chartMode = 0 },
                            modifier = Modifier
                                .size(28.dp)
                                .background(
                                    if (chartMode == 0) MaterialTheme.colorScheme.primary else Color.Transparent,
                                    CircleShape
                                )
                                .testTag("btn_chart_mode_rings")
                        ) {
                            Icon(
                                Icons.Default.DonutLarge,
                                contentDescription = "Çoklu Halka",
                                tint = if (chartMode == 0) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurfaceVariant,
                                modifier = Modifier.size(16.dp)
                            )
                        }
                        IconButton(
                            onClick = { chartMode = 1 },
                            modifier = Modifier
                                .size(28.dp)
                                .background(
                                    if (chartMode == 1) MaterialTheme.colorScheme.primary else Color.Transparent,
                                    CircleShape
                                )
                                .testTag("btn_chart_mode_gauge")
                        ) {
                            Icon(
                                Icons.Default.Speed,
                                contentDescription = "Gösterge",
                                tint = if (chartMode == 1) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurfaceVariant,
                                modifier = Modifier.size(16.dp)
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Main Visual: Concentric Radial Rings or Single Circular Gauge
            if (chartMode == 0) {
                MultiRingRadialCanvas(
                    overallPercentage = overallPercentage,
                    categoryItems = categoryProgressList,
                    completedCoursesCount = completedCoursesCount,
                    totalCoursesCount = totalCoursesCount
                )
            } else {
                SingleGaugeRadialCanvas(
                    overallPercentage = overallPercentage,
                    completedHours = completedHours,
                    totalHours = totalHours,
                    completedCoursesCount = completedCoursesCount,
                    totalCoursesCount = totalCoursesCount
                )
            }

            Spacer(modifier = Modifier.height(16.dp))
            HorizontalDivider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.15f))
            Spacer(modifier = Modifier.height(12.dp))

            // Interactive Category Legends with Progress Chips
            Text(
                text = "Kategori Bazlı Tamamlama Oranları",
                style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold),
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Spacer(modifier = Modifier.height(8.dp))

            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                categoryProgressList.forEach { item ->
                    val animPct by animateFloatAsState(
                        targetValue = item.averagePercentage,
                        animationSpec = tween(durationMillis = 800, easing = FastOutSlowInEasing),
                        label = "catProgress_${item.categoryName}"
                    )
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(8.dp))
                            .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.35f))
                            .padding(horizontal = 10.dp, vertical = 6.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(10.dp)
                                    .background(item.color, CircleShape)
                            )
                            Text(
                                text = item.categoryName,
                                style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Medium),
                                color = MaterialTheme.colorScheme.onSurface
                            )
                        }

                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Text(
                                text = "${item.completedCourses}/${item.totalCourses} Ders",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            Surface(
                                shape = RoundedCornerShape(6.dp),
                                color = item.color.copy(alpha = 0.15f)
                            ) {
                                Text(
                                    text = "%${animPct.toInt()}",
                                    color = item.color,
                                    style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                )
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Quick Stats Footer
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(10.dp))
                    .background(MaterialTheme.colorScheme.primary.copy(alpha = 0.08f))
                    .padding(10.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Icon(
                        Icons.Default.Storage,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(16.dp)
                    )
                    Text(
                        text = "Room SQLite Kalıcı Kayıt",
                        style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.SemiBold),
                        color = MaterialTheme.colorScheme.primary
                    )
                }

                Text(
                    text = "${String.format("%.1f", completedHours)} / $totalHours Saat Tamamlandı",
                    style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                    color = MaterialTheme.colorScheme.onSurface
                )
            }
        }
    }
}

@Composable
fun MultiRingRadialCanvas(
    overallPercentage: Float,
    categoryItems: List<CategoryProgressItem>,
    completedCoursesCount: Int,
    totalCoursesCount: Int
) {
    val animatedOverall by animateFloatAsState(
        targetValue = overallPercentage,
        animationSpec = tween(durationMillis = 1000, easing = FastOutSlowInEasing),
        label = "animatedOverall"
    )

    // Animated values for category rings
    val animRings = categoryItems.map { item ->
        animateFloatAsState(
            targetValue = item.averagePercentage,
            animationSpec = tween(durationMillis = 1000, easing = FastOutSlowInEasing),
            label = "anim_${item.categoryName}"
        )
    }

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .height(200.dp),
        contentAlignment = Alignment.Center
    ) {
        Canvas(
            modifier = Modifier
                .size(190.dp)
                .testTag("canvas_multi_ring_radial")
        ) {
            val strokeWidth = 8.dp.toPx()
            val ringGap = 6.dp.toPx()
            val center = Offset(size.width / 2f, size.height / 2f)
            val maxRadius = (size.minDimension / 2f) - (strokeWidth / 2f)

            // 1. Draw Outermost Ring: Overall Total Progress
            val outerRadius = maxRadius
            val outerSize = Size(outerRadius * 2, outerRadius * 2)
            val outerTopLeft = Offset(center.x - outerRadius, center.y - outerRadius)

            // Background Track
            drawArc(
                color = IdxBlue.copy(alpha = 0.12f),
                startAngle = -90f,
                sweepAngle = 360f,
                useCenter = false,
                topLeft = outerTopLeft,
                size = outerSize,
                style = Stroke(width = strokeWidth, cap = StrokeCap.Round)
            )

            // Outer Active Arc (Sweep gradient style)
            val outerSweep = (animatedOverall / 100f) * 360f
            if (outerSweep > 0) {
                drawArc(
                    brush = Brush.sweepGradient(
                        colors = listOf(IdxBlue, GeminiPurple, SuccessEmerald, IdxBlue)
                    ),
                    startAngle = -90f,
                    sweepAngle = outerSweep,
                    useCenter = false,
                    topLeft = outerTopLeft,
                    size = outerSize,
                    style = Stroke(width = strokeWidth, cap = StrokeCap.Round)
                )
            }

            // 2. Draw Concentric Inner Rings for Categories
            categoryItems.forEachIndexed { index, catItem ->
                val ringRadius = outerRadius - ((index + 1) * (strokeWidth + ringGap))
                if (ringRadius > strokeWidth) {
                    val ringSize = Size(ringRadius * 2, ringRadius * 2)
                    val ringTopLeft = Offset(center.x - ringRadius, center.y - ringRadius)

                    // Track
                    drawArc(
                        color = catItem.color.copy(alpha = 0.12f),
                        startAngle = -90f,
                        sweepAngle = 360f,
                        useCenter = false,
                        topLeft = ringTopLeft,
                        size = ringSize,
                        style = Stroke(width = strokeWidth, cap = StrokeCap.Round)
                    )

                    // Progress
                    val currentVal = animRings[index].value
                    val catSweep = (currentVal / 100f) * 360f
                    if (catSweep > 0) {
                        drawArc(
                            color = catItem.color,
                            startAngle = -90f,
                            sweepAngle = catSweep,
                            useCenter = false,
                            topLeft = ringTopLeft,
                            size = ringSize,
                            style = Stroke(width = strokeWidth, cap = StrokeCap.Round)
                        )
                    }
                }
            }
        }

        // Center Content Info Badge
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Text(
                text = "%${animatedOverall.toInt()}",
                style = MaterialTheme.typography.titleLarge.copy(
                    fontWeight = FontWeight.ExtraBold,
                    fontSize = 26.sp,
                    color = if (animatedOverall >= 100f) SuccessEmerald else MaterialTheme.colorScheme.primary
                )
            )
            Text(
                text = "Tamamlandı",
                style = MaterialTheme.typography.labelSmall.copy(fontSize = 10.sp),
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Surface(
                shape = RoundedCornerShape(4.dp),
                color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.7f),
                modifier = Modifier.padding(top = 2.dp)
            ) {
                Text(
                    text = "$completedCoursesCount/$totalCoursesCount Ders",
                    style = MaterialTheme.typography.labelSmall.copy(fontSize = 9.5.sp, fontWeight = FontWeight.Bold),
                    modifier = Modifier.padding(horizontal = 4.dp, vertical = 1.dp)
                )
            }
        }
    }
}

@Composable
fun SingleGaugeRadialCanvas(
    overallPercentage: Float,
    completedHours: Double,
    totalHours: Int,
    completedCoursesCount: Int,
    totalCoursesCount: Int
) {
    val animatedProgress by animateFloatAsState(
        targetValue = overallPercentage,
        animationSpec = tween(durationMillis = 1000, easing = FastOutSlowInEasing),
        label = "singleGaugeProgress"
    )
    val trackColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .height(200.dp),
        contentAlignment = Alignment.Center
    ) {
        Canvas(
            modifier = Modifier
                .size(190.dp)
                .testTag("canvas_single_gauge_radial")
        ) {
            val strokeWidth = 16.dp.toPx()
            val center = Offset(size.width / 2f, size.height / 2f)
            val radius = (size.minDimension / 2f) - (strokeWidth / 2f)
            val arcSize = Size(radius * 2, radius * 2)
            val topLeft = Offset(center.x - radius, center.y - radius)

            val startAngle = 135f
            val totalSweepAngle = 270f

            // Background Gauge Track
            drawArc(
                color = trackColor,
                startAngle = startAngle,
                sweepAngle = totalSweepAngle,
                useCenter = false,
                topLeft = topLeft,
                size = arcSize,
                style = Stroke(width = strokeWidth, cap = StrokeCap.Round)
            )

            // Active Progress Arc with Gradient
            val currentSweep = (animatedProgress / 100f) * totalSweepAngle
            if (currentSweep > 0) {
                val gaugeColors = if (animatedProgress >= 100f) {
                    listOf(SuccessEmerald, GeminiGreen)
                } else if (animatedProgress >= 50f) {
                    listOf(IdxBlue, GeminiPurple, SuccessEmerald)
                } else {
                    listOf(WarningYellow, IdxBlue)
                }

                drawArc(
                    brush = Brush.sweepGradient(
                        colors = gaugeColors,
                        center = center
                    ),
                    startAngle = startAngle,
                    sweepAngle = currentSweep,
                    useCenter = false,
                    topLeft = topLeft,
                    size = arcSize,
                    style = Stroke(width = strokeWidth, cap = StrokeCap.Round)
                )
            }
        }

        // Centered Content
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Text(
                text = "%${animatedProgress.toInt()}",
                style = MaterialTheme.typography.headlineMedium.copy(
                    fontWeight = FontWeight.ExtraBold,
                    fontSize = 32.sp,
                    color = if (animatedProgress >= 100f) SuccessEmerald else MaterialTheme.colorScheme.primary
                )
            )
            Text(
                text = "Genel İlerleme",
                style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.SemiBold),
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Spacer(modifier = Modifier.height(4.dp))
            Row(
                horizontalArrangement = Arrangement.spacedBy(4.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    Icons.Default.Timer,
                    contentDescription = null,
                    tint = GeminiPurple,
                    modifier = Modifier.size(12.dp)
                )
                Text(
                    text = "${String.format("%.1f", completedHours)} / $totalHours Saat",
                    style = MaterialTheme.typography.labelSmall.copy(fontSize = 11.sp, fontWeight = FontWeight.Bold),
                    color = MaterialTheme.colorScheme.onSurface
                )
            }
        }
    }
}
