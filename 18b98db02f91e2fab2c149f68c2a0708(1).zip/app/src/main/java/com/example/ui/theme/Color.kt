package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Primary IDX & Cloud Blue
val IdxBlue = Color(0xFF3B82F6)
val IdxBlueDark = Color(0xFF1D4ED8)
val IdxBlueLight = Color(0xFF93C5FD)

// Gemini AI Violet
val GeminiPurple = Color(0xFF8B5CF6)
val GeminiPurpleDark = Color(0xFF6D28D9)
val GeminiPurpleLight = Color(0xFFC4B5FD)

// Flutter Cyan
val FlutterCyan = Color(0xFF06B6D4)
val FlutterCyanLight = Color(0xFF67E8F9)

// Firebase & Amber
val FirebaseAmber = Color(0xFFF59E0B)
val FirebaseAmberDark = Color(0xFFD97706)

// Next.js & Slate
val Slate50 = Color(0xFFF8FAFC)
val Slate100 = Color(0xFFF1F5F9)
val Slate200 = Color(0xFFE2E8F0)
val Slate700 = Color(0xFF334155)
val Slate800 = Color(0xFF1E293B)
val Slate900 = Color(0xFF0F172A)
val Slate950 = Color(0xFF090D16)

// Status & Accents
val SuccessEmerald = Color(0xFF10B981)
val GeminiGreen = Color(0xFF10B981)
val ErrorRose = Color(0xFFF43F5E)
val WarningYellow = Color(0xFFFBBF24)

// Code editor background
val CodeBgDark = Color(0xFF0D1117)
val CodeKeyword = Color(0xFFFF7B72)
val CodeString = Color(0xFFA5D6FF)
val CodeFunction = Color(0xFFD2A8FF)
val CodeComment = Color(0xFF8B949E)
