package com.example.ui.aistudio

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.local.entity.SavedPromptEntity
import com.example.model.PromptTemplate
import com.example.ui.components.CodeViewerCard
import com.example.ui.components.SectionHeader
import com.example.ui.theme.GeminiPurple
import com.example.ui.theme.IdxBlue
import com.example.ui.theme.SuccessEmerald
import kotlinx.coroutines.launch

@Composable
fun AiPromptStudioScreen(
    templates: List<PromptTemplate>,
    savedPrompts: List<SavedPromptEntity>,
    onSavePrompt: (SavedPromptEntity) -> Unit,
    onDeletePrompt: (SavedPromptEntity) -> Unit,
    onGenerate: suspend (String, String, String, Boolean) -> Pair<String, Boolean>,
    modifier: Modifier = Modifier
) {
    val coroutineScope = rememberCoroutineScope()
    var systemInstruction by remember {
        mutableStateOf("You are a senior full-stack architect specializing in Project IDX and Google AI Studio.")
    }
    var userPrompt by remember {
        mutableStateOf("Generate a clean Kotlin Room DAO with reactive Flow queries and error handling.")
    }
    var selectedModel by remember { mutableStateOf("gemini-3.5-flash") }
    var isJsonMode by remember { mutableStateOf(false) }
    var isGenerating by remember { mutableStateOf(false) }
    var generationOutput by remember { mutableStateOf("") }
    var isOnlineApi by remember { mutableStateOf(false) }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            SectionHeader(
                title = "Prompt Engineering Studio",
                subtitle = "aistudio.google.com ├── Prompt Engineering (System Instructions & Structured Output)",
                badge = "Studio Workbench",
                badgeColor = GeminiPurple
            )
        }

        // Quick Preset Templates
        item {
            Text(
                text = "Curated System Prompt Templates",
                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.SemiBold)
            )
            Spacer(modifier = Modifier.height(8.dp))
            LazyRow(
                horizontalArrangement = Arrangement.spacedBy(10.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                items(templates) { template ->
                    Card(
                        modifier = Modifier
                            .width(200.dp)
                            .clickable {
                                systemInstruction = template.systemInstruction
                                userPrompt = template.userPrompt
                                isJsonMode = template.category == "Structured Output"
                            }
                            .testTag("prompt_template_${template.id}"),
                        shape = RoundedCornerShape(10.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                        border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.3f))
                    ) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Text(
                                text = template.title,
                                style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                                color = GeminiPurple
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = template.category,
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
            }
        }

        // Prompt Editor Box
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.3f))
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "System Instruction",
                        style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold)
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    OutlinedTextField(
                        value = systemInstruction,
                        onValueChange = { systemInstruction = it },
                        modifier = Modifier.fillMaxWidth().testTag("system_instruction_input"),
                        minLines = 2,
                        textStyle = MaterialTheme.typography.bodySmall
                    )

                    Spacer(modifier = Modifier.height(12.dp))
                    Text(
                        text = "User Prompt",
                        style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold)
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    OutlinedTextField(
                        value = userPrompt,
                        onValueChange = { userPrompt = it },
                        modifier = Modifier.fillMaxWidth().testTag("user_prompt_input"),
                        minLines = 3,
                        textStyle = MaterialTheme.typography.bodySmall
                    )

                    Spacer(modifier = Modifier.height(12.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Checkbox(
                                checked = isJsonMode,
                                onCheckedChange = { isJsonMode = it },
                                modifier = Modifier.testTag("json_mode_checkbox")
                            )
                            Text("Structured JSON Mode", style = MaterialTheme.typography.bodySmall)
                        }

                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            IconButton(
                                onClick = {
                                    onSavePrompt(
                                        SavedPromptEntity(
                                            title = userPrompt.take(30) + "...",
                                            promptText = userPrompt,
                                            systemInstruction = systemInstruction,
                                            model = selectedModel,
                                            category = if (isJsonMode) "JSON" else "Engineering"
                                        )
                                    )
                                },
                                modifier = Modifier.testTag("save_prompt_to_db_button")
                            ) {
                                Icon(Icons.Default.BookmarkBorder, contentDescription = "Save to Room DB", tint = GeminiPurple)
                            }

                            Button(
                                onClick = {
                                    coroutineScope.launch {
                                        isGenerating = true
                                        val (text, isOnline) = onGenerate(userPrompt, systemInstruction, selectedModel, isJsonMode)
                                        generationOutput = text
                                        isOnlineApi = isOnline
                                        isGenerating = false
                                    }
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = GeminiPurple),
                                enabled = !isGenerating && userPrompt.isNotBlank(),
                                modifier = Modifier.testTag("run_prompt_button")
                            ) {
                                Icon(Icons.Default.AutoAwesome, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(if (isGenerating) "Generating..." else "Run Prompt", fontSize = 12.sp)
                            }
                        }
                    }
                }
            }
        }

        // Generation Output Box
        if (generationOutput.isNotBlank()) {
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                    border = androidx.compose.foundation.BorderStroke(1.dp, GeminiPurple.copy(alpha = 0.4f))
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "Model Output",
                                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                            )
                            Surface(
                                color = if (isOnlineApi) SuccessEmerald.copy(alpha = 0.15f) else IdxBlue.copy(alpha = 0.15f),
                                shape = RoundedCornerShape(4.dp)
                            ) {
                                Text(
                                    text = if (isOnlineApi) "LIVE GEMINI API" else "OFFLINE STUDIO FALLBACK",
                                    color = if (isOnlineApi) SuccessEmerald else IdxBlue,
                                    style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(10.dp))
                        Text(
                            text = generationOutput,
                            style = MaterialTheme.typography.bodyMedium.copy(
                                fontFamily = if (isJsonMode) FontFamily.Monospace else FontFamily.Default,
                                lineHeight = 20.sp
                            )
                        )
                    }
                }
            }
        }

        // Saved Prompts in Local Room Database
        if (savedPrompts.isNotEmpty()) {
            item {
                Text(
                    text = "Saved Prompts in Local Room Database (${savedPrompts.size})",
                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.SemiBold)
                )
            }

            items(savedPrompts) { prompt ->
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(10.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                    border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.3f))
                ) {
                    Row(
                        modifier = Modifier.padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column(modifier = Modifier.weight(1f).clickable {
                            userPrompt = prompt.promptText
                            systemInstruction = prompt.systemInstruction
                        }) {
                            Text(
                                text = prompt.title,
                                style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold)
                            )
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(
                                text = "${prompt.category} • ${prompt.model}",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }

                        IconButton(
                            onClick = { onDeletePrompt(prompt) },
                            modifier = Modifier.size(32.dp).testTag("delete_saved_prompt_button")
                        ) {
                            Icon(Icons.Default.Delete, contentDescription = "Delete", tint = MaterialTheme.colorScheme.error, modifier = Modifier.size(18.dp))
                        }
                    }
                }
            }
        }
    }
}
