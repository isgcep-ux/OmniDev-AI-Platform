package com.example.ui.aistudio

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.SdkSnippet
import com.example.ui.components.CodeViewerCard
import com.example.ui.components.SectionHeader
import com.example.ui.components.StatCard
import com.example.ui.theme.GeminiPurple
import com.example.ui.theme.IdxBlue
import com.example.ui.theme.SuccessEmerald

@Composable
fun AiSdkWorkbenchScreen(
    sdkSnippets: List<SdkSnippet>,
    onSaveSnippet: (String, String, String) -> Unit,
    modifier: Modifier = Modifier
) {
    var selectedLanguage by remember { mutableStateOf(sdkSnippets.firstOrNull()?.language ?: "Kotlin (Android Compose)") }
    var mockExecutionResult by remember { mutableStateOf<String?>(null) }
    var isSimulatingExecution by remember { mutableStateOf(false) }

    val currentSnippet = sdkSnippets.find { it.language == selectedLanguage } ?: sdkSnippets.first()

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            SectionHeader(
                title = "Integration SDK Workbench",
                subtitle = "aistudio.google.com ├── Integration SDK (Polyglot Client Libraries)",
                badge = "5 Languages",
                badgeColor = GeminiPurple
            )
        }

        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                StatCard(
                    title = "Target Model",
                    value = "gemini-3.5-flash",
                    icon = Icons.Default.Memory,
                    accentColor = GeminiPurple,
                    modifier = Modifier.weight(1f)
                )
                StatCard(
                    title = "SDK Compatibility",
                    value = "v1beta REST & GenAI",
                    icon = Icons.Default.CheckCircle,
                    accentColor = SuccessEmerald,
                    modifier = Modifier.weight(1f)
                )
            }
        }

        // Language Selector Chips
        item {
            Text(
                text = "Select Client SDK Language",
                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.SemiBold)
            )
            Spacer(modifier = Modifier.height(8.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                sdkSnippets.take(3).forEach { snippet ->
                    FilterChip(
                        selected = selectedLanguage == snippet.language,
                        onClick = {
                            selectedLanguage = snippet.language
                            mockExecutionResult = null
                        },
                        label = { Text(snippet.language.split(" ").first(), fontSize = 11.sp) },
                        modifier = Modifier.testTag("sdk_lang_${snippet.extension}")
                    )
                }
            }
            Spacer(modifier = Modifier.height(4.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                sdkSnippets.drop(3).forEach { snippet ->
                    FilterChip(
                        selected = selectedLanguage == snippet.language,
                        onClick = {
                            selectedLanguage = snippet.language
                            mockExecutionResult = null
                        },
                        label = { Text(snippet.language.split(" ").first(), fontSize = 11.sp) },
                        modifier = Modifier.testTag("sdk_lang_${snippet.extension}")
                    )
                }
            }
        }

        // Active SDK Code Viewer
        item {
            CodeViewerCard(
                title = currentSnippet.title,
                language = currentSnippet.extension.removePrefix("."),
                code = currentSnippet.code
            )
        }

        // Action Buttons: Execute Mock Call & Save Snippet
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Button(
                    onClick = {
                        isSimulatingExecution = true
                        mockExecutionResult = "HTTP 200 OK • Latency: 242ms\nPayload: {\"candidates\": [{\"content\": {\"parts\": [{\"text\": \"Project IDX combines cloud-based multi-platform workspaces with built-in Gemini intelligence for Flutter, Next.js, and Firebase developers.\"}]}}]}"
                        isSimulatingExecution = false
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = GeminiPurple),
                    modifier = Modifier.weight(1f).testTag("simulate_sdk_call_button")
                ) {
                    Icon(Icons.Default.PlayArrow, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Test SDK Call", fontSize = 12.sp)
                }

                OutlinedButton(
                    onClick = {
                        onSaveSnippet(currentSnippet.title, "Gemini SDK", currentSnippet.code)
                    },
                    modifier = Modifier.weight(1f).testTag("save_sdk_snippet_button")
                ) {
                    Icon(Icons.Default.BookmarkBorder, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Save to Vault", fontSize = 12.sp)
                }
            }
        }

        // Simulated Execution Result
        mockExecutionResult?.let { result ->
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                    border = androidx.compose.foundation.BorderStroke(1.dp, SuccessEmerald.copy(alpha = 0.4f))
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "SDK Client Response",
                                style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                                color = SuccessEmerald
                            )
                            Surface(
                                shape = RoundedCornerShape(4.dp),
                                color = SuccessEmerald.copy(alpha = 0.15f)
                            ) {
                                Text(
                                    text = "200 SUCCESS",
                                    color = SuccessEmerald,
                                    style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = result,
                            style = MaterialTheme.typography.bodySmall.copy(
                                fontFamily = FontFamily.Monospace,
                                fontSize = 11.sp,
                                lineHeight = 16.sp
                            )
                        )
                    }
                }
            }
        }
    }
}
