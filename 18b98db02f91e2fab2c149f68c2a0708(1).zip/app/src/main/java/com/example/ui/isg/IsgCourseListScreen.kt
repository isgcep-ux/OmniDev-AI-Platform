package com.example.ui.isg

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.MenuBook
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.IsgCourseModule
import com.example.ui.components.SectionHeader
import com.example.ui.components.StatCard
import com.example.ui.theme.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun IsgCourseListScreen(
    courses: List<IsgCourseModule>,
    onToggleCompletion: (String) -> Unit,
    onToggleSyllabusItem: (String, String) -> Unit = { _, _ -> },
    onUpdateProgressPercentage: (String, Int) -> Unit = { _, _ -> },
    onResetAllProgress: () -> Unit = {},
    voiceProfiles: List<com.example.model.ClonedVoiceProfile> = emptyList(),
    onSynthesizeNarration: (suspend (String, com.example.model.ClonedVoiceProfile, String) -> com.example.data.remote.VoiceSynthesisResult)? = null,
    onSendToVideoStudio: ((String, String, com.example.model.ClonedVoiceProfile) -> Unit)? = null,
    modifier: Modifier = Modifier
) {
    var selectedCategory by remember { mutableStateOf("Tümü") }
    var selectedDomain by remember { mutableStateOf("Tümü") }
    var searchQuery by remember { mutableStateOf("") }
    var selectedCourseForDetail by remember { mutableStateOf<IsgCourseModule?>(null) }
    var selectedCourseForCertificate by remember { mutableStateOf<IsgCourseModule?>(null) }
    var selectedCourseForPdf by remember { mutableStateOf<IsgCourseModule?>(null) }
    var courseForNarration by remember { mutableStateOf<IsgCourseModule?>(null) }
    var showResetDialog by remember { mutableStateOf(false) }

    val categories = listOf(
        "Tümü",
        "Mevzuat & Hukuk",
        "Saha Güvenliği & KKD",
        "Risk & Metodoloji",
        "Sağlık & İlkyardım",
        "Global & Sertifikasyon"
    )

    val domains = listOf("Tümü", "isgcepakademi.com", "isgcepakademi.com.tr", "isgcepakademi.xyz")

    val filteredCourses = remember(courses, selectedCategory, selectedDomain, searchQuery) {
        courses.filter { course ->
            val matchesCategory = selectedCategory == "Tümü" || course.category == selectedCategory
            val matchesDomain = selectedDomain == "Tümü" || course.domain == selectedDomain
            val matchesSearch = searchQuery.isBlank() ||
                    course.title.contains(searchQuery, ignoreCase = true) ||
                    course.description.contains(searchQuery, ignoreCase = true) ||
                    course.instructor.contains(searchQuery, ignoreCase = true)
            matchesCategory && matchesDomain && matchesSearch
        }
    }

    val totalHours = courses.sumOf { it.durationHours }
    val completedCount = courses.count { it.isCompleted }
    val averageProgress = if (courses.isNotEmpty()) courses.sumOf { it.progressPercentage } / courses.size else 0

    if (showResetDialog) {
        AlertDialog(
            onDismissRequest = { showResetDialog = false },
            title = { Text("İlerlemeyi Sıfırla") },
            text = { Text("Tüm eğitim tamamlama durumları ve ilerleme yüzdeleri Room yerel veritabanından silinecektir. Emin misiniz?") },
            confirmButton = {
                Button(
                    onClick = {
                        onResetAllProgress()
                        showResetDialog = false
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error)
                ) {
                    Text("Evet, Sıfırla")
                }
            },
            dismissButton = {
                TextButton(onClick = { showResetDialog = false }) {
                    Text("İptal")
                }
            }
        )
    }

    if (selectedCourseForCertificate != null) {
        IsgCertificateDialog(
            course = selectedCourseForCertificate!!,
            onDismiss = { selectedCourseForCertificate = null }
        )
    }

    if (selectedCourseForPdf != null) {
        IsgPdfViewerDialog(
            course = selectedCourseForPdf!!,
            onDismiss = { selectedCourseForPdf = null }
        )
    }

    if (courseForNarration != null) {
        IsgModuleNarrationStudioDialog(
            initialCourse = courseForNarration,
            allCourses = courses,
            voiceProfiles = voiceProfiles,
            onSynthesize = { text, profile, key ->
                onSynthesizeNarration?.invoke(text, profile, key)
                    ?: com.example.data.remote.VoiceSynthesisResult.Success(
                        audioUrl = "https://cdn.isgcepakademi.com.tr/audio/course-preview.mp3",
                        audioBase64 = null,
                        durationSeconds = (text.split(" ").size / 2.5).toInt().coerceAtLeast(3),
                        latencyMs = 450,
                        provider = profile.provider,
                        characterCount = text.length
                    )
            },
            onDismiss = { courseForNarration = null },
            onSendToVideoStudio = onSendToVideoStudio
        )
    }

    // If detail modal/view is active, render detailed module view
    if (selectedCourseForDetail != null) {
        val currentCourse = courses.find { it.id == selectedCourseForDetail?.id } ?: selectedCourseForDetail!!
        CourseDetailView(
            course = currentCourse,
            onBack = { selectedCourseForDetail = null },
            onToggleCompletion = { onToggleCompletion(currentCourse.id) },
            onToggleSyllabusItem = { item -> onToggleSyllabusItem(currentCourse.id, item) },
            onUpdateProgressPercentage = { pct -> onUpdateProgressPercentage(currentCourse.id, pct) },
            onViewCertificate = { selectedCourseForCertificate = currentCourse },
            onOpenNarrationStudio = { courseForNarration = currentCourse },
            onOpenPdfViewer = { selectedCourseForPdf = currentCourse },
            modifier = modifier
        )
    } else {
        LazyColumn(
            modifier = modifier
                .fillMaxSize()
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp),
            contentPadding = PaddingValues(top = 16.dp, bottom = 32.dp)
        ) {
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    SectionHeader(
                        title = "İSG Eğitim Modülleri & İlerleme",
                        subtitle = "Room veritabanında saklanan ders tamamlama durumları ve ilerleme yüzdeleri",
                        badge = "Room DB Destekli",
                        badgeColor = GeminiGreen,
                        modifier = Modifier.weight(1f)
                    )
                    if (completedCount > 0 || averageProgress > 0) {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            FilledTonalButton(
                                onClick = { courseForNarration = courses.firstOrNull() },
                                shape = RoundedCornerShape(8.dp),
                                contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp),
                                colors = ButtonDefaults.filledTonalButtonColors(containerColor = GeminiPurple.copy(alpha = 0.15f))
                            ) {
                                Icon(Icons.Default.RecordVoiceOver, contentDescription = null, tint = GeminiPurple, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("ElevenLabs TTS", color = GeminiPurple, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            }
                            IconButton(
                                onClick = { showResetDialog = true },
                                modifier = Modifier.testTag("btn_reset_course_progress")
                            ) {
                                Icon(
                                    Icons.Default.RestartAlt,
                                    contentDescription = "İlerlemeyi Sıfırla",
                                    tint = MaterialTheme.colorScheme.error
                                )
                            }
                        }
                    } else {
                        FilledTonalButton(
                            onClick = { courseForNarration = courses.firstOrNull() },
                            shape = RoundedCornerShape(8.dp),
                            contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp),
                            colors = ButtonDefaults.filledTonalButtonColors(containerColor = GeminiPurple.copy(alpha = 0.15f))
                        ) {
                            Icon(Icons.Default.RecordVoiceOver, contentDescription = null, tint = GeminiPurple, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("ElevenLabs TTS", color = GeminiPurple, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }

            // Stat Cards
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    StatCard(
                        title = "Genel İlerleme",
                        value = "%$averageProgress",
                        icon = Icons.Default.TrendingUp,
                        accentColor = GeminiPurple,
                        modifier = Modifier.weight(1f)
                    )
                    StatCard(
                        title = "Toplam Süre",
                        value = "$totalHours Saat",
                        icon = Icons.Default.Schedule,
                        accentColor = IdxBlue,
                        modifier = Modifier.weight(1f)
                    )
                    StatCard(
                        title = "Tamamlanan",
                        value = "$completedCount/${courses.size}",
                        icon = Icons.Default.CheckCircle,
                        accentColor = if (completedCount > 0) SuccessEmerald else WarningYellow,
                        modifier = Modifier.weight(1f)
                    )
                }
            }

            // Recharts-like Circular / Radial Progress Chart Card
            item {
                IsgProgressRadialChart(courses = courses)
            }

            // Search Bar
            item {
                OutlinedTextField(
                    value = searchQuery,
                    onValueChange = { searchQuery = it },
                    placeholder = { Text("Eğitim modülü, mevzuat veya eğitmen ara...") },
                    leadingIcon = {
                        Icon(Icons.Default.Search, contentDescription = "Ara", tint = MaterialTheme.colorScheme.onSurfaceVariant)
                    },
                    trailingIcon = {
                        if (searchQuery.isNotEmpty()) {
                            IconButton(onClick = { searchQuery = "" }) {
                                Icon(Icons.Default.Clear, contentDescription = "Temizle")
                            }
                        }
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("input_course_search"),
                    shape = RoundedCornerShape(12.dp),
                    singleLine = true
                )
            }

            // Domain Filter
            item {
                Column {
                    Text(
                        text = "Kaynak Portal & Akreditasyon:",
                        style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold),
                        modifier = Modifier.padding(bottom = 6.dp)
                    )
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        items(domains) { dom ->
                            val isSelected = selectedDomain == dom
                            FilterChip(
                                selected = isSelected,
                                onClick = { selectedDomain = dom },
                                label = { Text(dom, fontSize = 12.sp) },
                                modifier = Modifier.testTag("filter_course_domain_$dom")
                            )
                        }
                    }
                }
            }

            // Category Filter
            item {
                Column {
                    Text(
                        text = "Uzmanlık & Konu Kategorisi:",
                        style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold),
                        modifier = Modifier.padding(bottom = 6.dp)
                    )
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        items(categories) { cat ->
                            val isSelected = selectedCategory == cat
                            FilterChip(
                                selected = isSelected,
                                onClick = { selectedCategory = cat },
                                label = { Text(cat, fontSize = 12.sp) },
                                modifier = Modifier.testTag("filter_course_cat_$cat")
                            )
                        }
                    }
                }
            }

            // Course Cards List
            items(filteredCourses) { course ->
                val domainColor = when {
                    course.domain == "isgcepakademi.com" -> GeminiGreen
                    course.domain.contains("xyz") -> GeminiPurple
                    else -> IdxBlue
                }

                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { selectedCourseForDetail = course }
                        .testTag("card_course_${course.id}"),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    border = BorderStroke(
                        1.dp,
                        if (course.isCompleted) SuccessEmerald.copy(alpha = 0.5f)
                        else MaterialTheme.colorScheme.outline.copy(alpha = 0.25f)
                    )
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
                                Surface(
                                    shape = RoundedCornerShape(6.dp),
                                    color = domainColor.copy(alpha = 0.15f)
                                ) {
                                    Text(
                                        text = course.domain,
                                        color = domainColor,
                                        style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 3.dp)
                                    )
                                }
                                Surface(
                                    shape = RoundedCornerShape(6.dp),
                                    color = MaterialTheme.colorScheme.surfaceVariant
                                ) {
                                    Text(
                                        text = course.category,
                                        style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.SemiBold),
                                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 3.dp)
                                    )
                                }
                            }

                            if (course.isCompleted) {
                                Surface(
                                    shape = RoundedCornerShape(6.dp),
                                    color = SuccessEmerald.copy(alpha = 0.15f)
                                ) {
                                    Row(
                                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                                    ) {
                                        Icon(Icons.Default.CheckCircle, contentDescription = null, tint = SuccessEmerald, modifier = Modifier.size(14.dp))
                                        Text(
                                            text = "Tamamlandı",
                                            color = SuccessEmerald,
                                            style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold)
                                        )
                                    }
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(10.dp))
                        Text(
                            text = course.title,
                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold, lineHeight = 22.sp)
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = course.description,
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            maxLines = 2
                        )

                        Spacer(modifier = Modifier.height(10.dp))

                        // Progress Indicator Bar
                        Column(modifier = Modifier.fillMaxWidth()) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = if (course.isCompleted) "Tamamlandı" else "İlerleme",
                                    style = MaterialTheme.typography.labelSmall.copy(
                                        color = if (course.isCompleted) SuccessEmerald else MaterialTheme.colorScheme.onSurfaceVariant,
                                        fontWeight = FontWeight.SemiBold
                                    )
                                )
                                Text(
                                    text = "%${course.progressPercentage}",
                                    style = MaterialTheme.typography.labelSmall.copy(
                                        color = if (course.isCompleted) SuccessEmerald else MaterialTheme.colorScheme.primary,
                                        fontWeight = FontWeight.Bold
                                    )
                                )
                            }
                            Spacer(modifier = Modifier.height(4.dp))
                            LinearProgressIndicator(
                                progress = { course.progressPercentage / 100f },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(6.dp)
                                    .clip(RoundedCornerShape(3.dp)),
                                color = if (course.isCompleted) SuccessEmerald else MaterialTheme.colorScheme.primary,
                                trackColor = MaterialTheme.colorScheme.surfaceVariant
                            )
                        }

                        Spacer(modifier = Modifier.height(12.dp))
                        HorizontalDivider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.15f))
                        Spacer(modifier = Modifier.height(12.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(horizontalArrangement = Arrangement.spacedBy(12.dp), verticalAlignment = Alignment.CenterVertically) {
                                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                    Icon(Icons.Default.Schedule, contentDescription = null, modifier = Modifier.size(14.dp), tint = MaterialTheme.colorScheme.onSurfaceVariant)
                                    Text("${course.durationHours} Saat", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                }
                                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                    Icon(Icons.Default.Star, contentDescription = null, modifier = Modifier.size(14.dp), tint = WarningYellow)
                                    Text("${course.rating} (${course.enrolledCount})", style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.SemiBold)
                                }
                            }

                            Row(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
                                OutlinedButton(
                                    onClick = { selectedCourseForPdf = course },
                                    shape = RoundedCornerShape(8.dp),
                                    contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp),
                                    modifier = Modifier.testTag("btn_quick_pdf_${course.id}")
                                ) {
                                    Icon(Icons.Default.PictureAsPdf, contentDescription = null, modifier = Modifier.size(14.dp), tint = domainColor)
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("PDF", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = domainColor)
                                }

                                if (course.isCompleted || course.progressPercentage >= 100) {
                                    Button(
                                        onClick = { selectedCourseForCertificate = course },
                                        shape = RoundedCornerShape(8.dp),
                                        colors = ButtonDefaults.buttonColors(containerColor = WarningYellow),
                                        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp),
                                        modifier = Modifier.testTag("btn_quick_cert_${course.id}")
                                    ) {
                                        Icon(Icons.Default.WorkspacePremium, contentDescription = null, modifier = Modifier.size(14.dp), tint = Color.Black)
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text("Sertifika", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Color.Black)
                                    }
                                }

                                FilledTonalButton(
                                    onClick = { selectedCourseForDetail = course },
                                    shape = RoundedCornerShape(8.dp),
                                    contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp),
                                    modifier = Modifier.testTag("btn_view_detail_${course.id}")
                                ) {
                                    Text("Detay", fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                                    Spacer(modifier = Modifier.width(2.dp))
                                    Icon(Icons.Default.ChevronRight, contentDescription = null, modifier = Modifier.size(16.dp))
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun CourseDetailView(
    course: IsgCourseModule,
    onBack: () -> Unit,
    onToggleCompletion: () -> Unit,
    onToggleSyllabusItem: (String) -> Unit = {},
    onUpdateProgressPercentage: (Int) -> Unit = {},
    onViewCertificate: () -> Unit = {},
    onOpenNarrationStudio: () -> Unit = {},
    onOpenPdfViewer: () -> Unit = {},
    modifier: Modifier = Modifier
) {
    val domainColor = when {
        course.domain == "isgcepakademi.com" -> GeminiGreen
        course.domain.contains("xyz") -> GeminiPurple
        else -> IdxBlue
    }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp),
        contentPadding = PaddingValues(top = 16.dp, bottom = 32.dp)
    ) {
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                IconButton(
                    onClick = onBack,
                    modifier = Modifier.testTag("btn_back_to_courses")
                ) {
                    Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Geri Dön")
                }
                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = domainColor.copy(alpha = 0.15f)
                ) {
                    Text(
                        text = "🌐 ${course.domain}",
                        color = domainColor,
                        style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold),
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                    )
                }
            }
        }

        // Header Card
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.2f))
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        Surface(
                            shape = RoundedCornerShape(4.dp),
                            color = MaterialTheme.colorScheme.primary.copy(alpha = 0.15f)
                        ) {
                            Text(
                                text = course.category,
                                color = MaterialTheme.colorScheme.primary,
                                style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                            )
                        }
                        Surface(
                            shape = RoundedCornerShape(4.dp),
                            color = MaterialTheme.colorScheme.secondary.copy(alpha = 0.15f)
                        ) {
                            Text(
                                text = course.level,
                                color = MaterialTheme.colorScheme.secondary,
                                style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.SemiBold),
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))
                    Text(
                        text = course.title,
                        style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold, lineHeight = 28.sp)
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = course.description,
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )

                    Spacer(modifier = Modifier.height(14.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(16.dp)
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            Icon(Icons.Default.Person, contentDescription = null, tint = IdxBlue, modifier = Modifier.size(18.dp))
                            Text(course.instructor, style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.SemiBold))
                        }
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            Icon(Icons.Default.Schedule, contentDescription = null, tint = GeminiPurple, modifier = Modifier.size(18.dp))
                            Text("${course.durationHours} Saatlik Müfredat", style = MaterialTheme.typography.labelMedium)
                        }
                    }
                }
            }
        }

        // Official PDF Document Reader Card
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("card_course_pdf_reader"),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = BorderStroke(1.5.dp, domainColor.copy(alpha = 0.4f))
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Surface(
                                shape = RoundedCornerShape(10.dp),
                                color = domainColor.copy(alpha = 0.15f),
                                modifier = Modifier.size(44.dp)
                            ) {
                                Box(contentAlignment = Alignment.Center) {
                                    Icon(Icons.Default.PictureAsPdf, contentDescription = null, tint = domainColor, modifier = Modifier.size(24.dp))
                                }
                            }
                            Column {
                                Text(
                                    text = "Resmi Ders & Mevzuat Dokümanı",
                                    style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold)
                                )
                                Text(
                                    text = "${course.documentPagesCount} Sayfa • ${course.documentFileSize} • e-İmzalı PDF",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                        Surface(
                            shape = RoundedCornerShape(6.dp),
                            color = SuccessEmerald.copy(alpha = 0.15f)
                        ) {
                            Text(
                                text = "PDF Hazır",
                                color = SuccessEmerald,
                                style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))
                    Text(
                        text = course.documentTitle.ifEmpty { "${course.title} Kapsamlı Uygulama Rehberi" },
                        style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.SemiBold)
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "isgcepakademi bağlantı yapısına uygun olarak mevzuat maddeleri, Fine-Kinney tabloları ve saha kontrol listelerini içeren tam metin PDF dokümanı.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )

                    Spacer(modifier = Modifier.height(12.dp))
                    Button(
                        onClick = onOpenPdfViewer,
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("btn_open_course_pdf_reader"),
                        colors = ButtonDefaults.buttonColors(containerColor = domainColor),
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Icon(Icons.Default.MenuBook, contentDescription = null, tint = Color.White)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "📄 PDF Dokümanını Görüntüle & Oku",
                            color = Color.White,
                            style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold)
                        )
                    }
                }
            }
        }

        // Completion & Interactive Progress Card (Room Persisted)
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(
                    containerColor = if (course.isCompleted) SuccessEmerald.copy(alpha = 0.15f)
                    else MaterialTheme.colorScheme.surface
                ),
                border = BorderStroke(
                    1.dp,
                    if (course.isCompleted) SuccessEmerald else MaterialTheme.colorScheme.outline.copy(alpha = 0.25f)
                )
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = if (course.isCompleted) "✓ Bu Modülü Tamamladınız" else "Eğitim İlerlemesi: %${course.progressPercentage}",
                                style = MaterialTheme.typography.titleSmall.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = if (course.isCompleted) SuccessEmerald else MaterialTheme.colorScheme.onSurface
                                )
                            )
                            Text(
                                text = "İlerleme Room SQLite veritabanında kalıcı tutulur.",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        Button(
                            onClick = onToggleCompletion,
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (course.isCompleted) MaterialTheme.colorScheme.outline else SuccessEmerald
                            ),
                            modifier = Modifier.testTag("btn_toggle_course_status")
                        ) {
                            Icon(
                                if (course.isCompleted) Icons.Default.Replay else Icons.Default.Check,
                                contentDescription = null,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(if (course.isCompleted) "Geri Al" else "Tamamla")
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))
                    LinearProgressIndicator(
                        progress = { course.progressPercentage / 100f },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(8.dp)
                            .clip(RoundedCornerShape(4.dp)),
                        color = if (course.isCompleted) SuccessEmerald else MaterialTheme.colorScheme.primary,
                        trackColor = MaterialTheme.colorScheme.surfaceVariant
                    )

                    Spacer(modifier = Modifier.height(10.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        listOf(25, 50, 75, 100).forEach { pct ->
                            OutlinedButton(
                                onClick = { onUpdateProgressPercentage(pct) },
                                modifier = Modifier.weight(1f),
                                shape = RoundedCornerShape(8.dp),
                                contentPadding = PaddingValues(horizontal = 4.dp, vertical = 2.dp)
                            ) {
                                Text("%$pct", style = MaterialTheme.typography.labelSmall)
                            }
                        }
                    }

                    if (course.isCompleted || course.progressPercentage >= 100) {
                        Spacer(modifier = Modifier.height(14.dp))
                        Button(
                            onClick = onViewCertificate,
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("btn_open_certificate_modal"),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = Color(0xFFD4AF37) // Gold
                            ),
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            Icon(Icons.Default.WorkspacePremium, contentDescription = null, tint = Color.Black)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "🎓 Resmi Başarı Belgesini Görüntüle & Doğrula",
                                color = Color.Black,
                                style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))
                    Button(
                        onClick = onOpenNarrationStudio,
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("btn_open_course_narration_studio"),
                        colors = ButtonDefaults.buttonColors(containerColor = GeminiPurple),
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Icon(Icons.Default.RecordVoiceOver, contentDescription = null, tint = Color.White)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "🎙️ Modülü Seslendir (ElevenLabs TTS)",
                            color = Color.White,
                            style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold)
                        )
                    }
                }
            }
        }

        // Target Audience & Certification Info
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.25f))
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "🎯 Hedef Kitle",
                        style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold)
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = course.targetAudience,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )

                    Spacer(modifier = Modifier.height(12.dp))
                    HorizontalDivider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.15f))
                    Spacer(modifier = Modifier.height(12.dp))

                    Text(
                        text = "📜 Sertifikasyon & Doğrulama",
                        style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold)
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = course.certificationInfo,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }

        // Learning Objectives
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.25f))
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "💡 Kazanımlar & Öğrenim Çıktıları",
                        style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold)
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    course.learningObjectives.forEach { obj ->
                        Row(
                            modifier = Modifier.padding(vertical = 3.dp),
                            verticalAlignment = Alignment.Top,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Text("•", color = GeminiGreen, fontWeight = FontWeight.Bold)
                            Text(
                                text = obj,
                                style = MaterialTheme.typography.bodySmall.copy(lineHeight = 18.sp),
                                color = MaterialTheme.colorScheme.onSurface
                            )
                        }
                    }
                }
            }
        }

        // Detailed Syllabus with Interactive Checkboxes
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.25f))
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "📚 Detaylı Ders Planı & Tamamlama",
                            style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold)
                        )
                        Text(
                            text = "${course.completedSyllabusItems.size}/${course.syllabus.size} Tamamlandı",
                            style = MaterialTheme.typography.labelSmall.copy(
                                fontWeight = FontWeight.Bold,
                                color = if (course.completedSyllabusItems.size == course.syllabus.size && course.syllabus.isNotEmpty()) SuccessEmerald else MaterialTheme.colorScheme.primary
                            )
                        )
                    }

                    Spacer(modifier = Modifier.height(10.dp))
                    course.syllabus.forEachIndexed { idx, item ->
                        val isItemCompleted = course.completedSyllabusItems.contains(item)
                        Surface(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 4.dp)
                                .clickable { onToggleSyllabusItem(item) },
                            shape = RoundedCornerShape(8.dp),
                            color = if (isItemCompleted) SuccessEmerald.copy(alpha = 0.1f) else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f),
                            border = if (isItemCompleted) BorderStroke(1.dp, SuccessEmerald.copy(alpha = 0.3f)) else null
                        ) {
                            Row(
                                modifier = Modifier.padding(10.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                Checkbox(
                                    checked = isItemCompleted,
                                    onCheckedChange = { onToggleSyllabusItem(item) },
                                    colors = CheckboxDefaults.colors(checkedColor = SuccessEmerald),
                                    modifier = Modifier.size(24.dp)
                                )
                                Text(
                                    text = item,
                                    style = MaterialTheme.typography.bodyMedium.copy(
                                        fontSize = 13.sp,
                                        color = if (isItemCompleted) MaterialTheme.colorScheme.onSurface else MaterialTheme.colorScheme.onSurfaceVariant
                                    ),
                                    modifier = Modifier.weight(1f)
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}
