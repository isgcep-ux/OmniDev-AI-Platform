package com.example.ui.isg

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.net.Uri
import android.widget.Toast
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.rememberTransformableState
import androidx.compose.foundation.gestures.transformable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ColorFilter
import androidx.compose.ui.graphics.ColorMatrix
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.core.content.FileProvider
import com.example.model.IsgCourseModule
import com.example.util.IsgPdfDocumentManager
import kotlinx.coroutines.launch

enum class PdfReadingMode {
    LIGHT, SEPIA, NIGHT
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun IsgPdfViewerDialog(
    course: IsgCourseModule,
    onDismiss: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()

    var currentPageIndex by remember { mutableIntStateOf(0) }
    var totalPages by remember { mutableIntStateOf(course.documentPagesCount.coerceAtLeast(1)) }
    var currentBitmap by remember { mutableStateOf<Bitmap?>(null) }
    var isLoadingPage by remember { mutableStateOf(true) }

    var scale by remember { mutableFloatStateOf(1f) }
    var offset by remember { mutableStateOf(Offset.Zero) }

    var readingMode by remember { mutableStateOf(PdfReadingMode.LIGHT) }
    val bookmarkedPages = remember { mutableStateListOf<Int>() }
    var showTableOfContents by remember { mutableStateOf(false) }
    var showSearchBar by remember { mutableStateOf(false) }
    var searchQuery by remember { mutableStateOf("") }
    var isLinkCopiedToast by remember { mutableStateOf(false) }

    // Transformable state for pinch zoom & panning
    val transformState = rememberTransformableState { zoomChange, panChange, _ ->
        scale = (scale * zoomChange).coerceIn(1f, 4.5f)
        if (scale > 1f) {
            val maxOffset = (scale - 1f) * 600f
            val newOffsetX = (offset.x + panChange.x).coerceIn(-maxOffset, maxOffset)
            val newOffsetY = (offset.y + panChange.y).coerceIn(-maxOffset, maxOffset)
            offset = Offset(newOffsetX, newOffsetY)
        } else {
            offset = Offset.Zero
        }
    }

    // Load page count on start
    LaunchedEffect(course.id) {
        totalPages = IsgPdfDocumentManager.getPageCount(context, course)
    }

    // Render current page bitmap
    LaunchedEffect(course.id, currentPageIndex) {
        isLoadingPage = true
        // Reset pan if changing page
        scale = 1f
        offset = Offset.Zero
        val bitmap = IsgPdfDocumentManager.renderPdfPage(context, course, currentPageIndex)
        currentBitmap = bitmap
        isLoadingPage = false
    }

    val domainColor = when {
        course.domain.contains("tr") -> Color(0xFF1565C0)
        course.domain.contains("xyz") -> Color(0xFF6A1B9A)
        else -> Color(0xFF2E7D32)
    }

    val paperBackground = when (readingMode) {
        PdfReadingMode.LIGHT -> Color.White
        PdfReadingMode.SEPIA -> Color(0xFFFDF6E2)
        PdfReadingMode.NIGHT -> Color(0xFF1E1E1E)
    }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(
            usePlatformDefaultWidth = false,
            dismissOnBackPress = true
        )
    ) {
        Surface(
            modifier = modifier
                .fillMaxSize()
                .testTag("dialog_isg_pdf_viewer"),
            color = MaterialTheme.colorScheme.background
        ) {
            Column(modifier = Modifier.fillMaxSize()) {

                // 1. TOP APP BAR
                Surface(
                    color = MaterialTheme.colorScheme.surface,
                    tonalElevation = 4.dp,
                    shadowElevation = 4.dp
                ) {
                    Column(modifier = Modifier.fillMaxWidth()) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 8.dp, vertical = 6.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(
                                modifier = Modifier.weight(1f),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                IconButton(
                                    onClick = onDismiss,
                                    modifier = Modifier.testTag("btn_close_pdf_viewer")
                                ) {
                                    Icon(Icons.Default.ArrowBack, contentDescription = "Geri Dön")
                                }

                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = course.documentTitle.ifEmpty { course.title },
                                        style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                                    ) {
                                        Text(
                                            text = course.domain,
                                            style = MaterialTheme.typography.labelSmall.copy(
                                                color = domainColor,
                                                fontWeight = FontWeight.Bold
                                            )
                                        )
                                        Text("•", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                        Text(
                                            text = course.documentFileSize,
                                            style = MaterialTheme.typography.labelSmall,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    }
                                }
                            }

                            // Action buttons
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(2.dp)
                            ) {
                                // Search toggle
                                IconButton(
                                    onClick = { showSearchBar = !showSearchBar },
                                    modifier = Modifier.testTag("btn_pdf_search_toggle")
                                ) {
                                    Icon(
                                        Icons.Default.Search,
                                        contentDescription = "Dokümanda Ara",
                                        tint = if (showSearchBar) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface
                                    )
                                }

                                // Bookmark Toggle
                                val isBookmarked = bookmarkedPages.contains(currentPageIndex + 1)
                                IconButton(
                                    onClick = {
                                        val pageNum = currentPageIndex + 1
                                        if (isBookmarked) {
                                            bookmarkedPages.remove(pageNum)
                                            Toast.makeText(context, "Sayfa $pageNum yer imlerinden kaldırıldı", Toast.LENGTH_SHORT).show()
                                        } else {
                                            bookmarkedPages.add(pageNum)
                                            Toast.makeText(context, "Sayfa $pageNum yer imlerine eklendi", Toast.LENGTH_SHORT).show()
                                        }
                                    },
                                    modifier = Modifier.testTag("btn_pdf_bookmark")
                                ) {
                                    Icon(
                                        if (isBookmarked) Icons.Default.Bookmark else Icons.Default.BookmarkBorder,
                                        contentDescription = "Yer İmi",
                                        tint = if (isBookmarked) Color(0xFFD4AF37) else MaterialTheme.colorScheme.onSurface
                                    )
                                }

                                // Table of Contents
                                IconButton(
                                    onClick = { showTableOfContents = !showTableOfContents },
                                    modifier = Modifier.testTag("btn_pdf_toc")
                                ) {
                                    Icon(Icons.Default.List, contentDescription = "İçindekiler")
                                }

                                // Reading Mode Menu
                                var showModeMenu by remember { mutableStateOf(false) }
                                Box {
                                    IconButton(onClick = { showModeMenu = true }) {
                                        Icon(
                                            when (readingMode) {
                                                PdfReadingMode.LIGHT -> Icons.Default.LightMode
                                                PdfReadingMode.SEPIA -> Icons.Default.MenuBook
                                                PdfReadingMode.NIGHT -> Icons.Default.DarkMode
                                            },
                                            contentDescription = "Okuma Modu"
                                        )
                                    }
                                    DropdownMenu(
                                        expanded = showModeMenu,
                                        onDismissRequest = { showModeMenu = false }
                                    ) {
                                        DropdownMenuItem(
                                            text = { Text("☀️ Gündüz (Açık)") },
                                            onClick = {
                                                readingMode = PdfReadingMode.LIGHT
                                                showModeMenu = false
                                            }
                                        )
                                        DropdownMenuItem(
                                            text = { Text("📖 Sıcak Kitap (Sepia)") },
                                            onClick = {
                                                readingMode = PdfReadingMode.SEPIA
                                                showModeMenu = false
                                            }
                                        )
                                        DropdownMenuItem(
                                            text = { Text("🌙 Gece (Koyu)") },
                                            onClick = {
                                                readingMode = PdfReadingMode.NIGHT
                                                showModeMenu = false
                                            }
                                        )
                                    }
                                }

                                // Share & Open Intent
                                IconButton(
                                    onClick = {
                                        coroutineScope.launch {
                                            try {
                                                val file = IsgPdfDocumentManager.getOrGeneratePdfFile(context, course)
                                                val uri = FileProvider.getUriForFile(
                                                    context,
                                                    "${context.packageName}.fileprovider",
                                                    file
                                                )
                                                val shareIntent = Intent(Intent.ACTION_SEND).apply {
                                                    type = "application/pdf"
                                                    putExtra(Intent.EXTRA_STREAM, uri)
                                                    putExtra(Intent.EXTRA_SUBJECT, course.title)
                                                    addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                                                }
                                                context.startActivity(Intent.createChooser(shareIntent, "PDF Dokümanını Paylaş"))
                                            } catch (e: Exception) {
                                                // Fallback to sharing URL
                                                val sendIntent = Intent(Intent.ACTION_SEND).apply {
                                                    putExtra(Intent.EXTRA_TEXT, "İSG Ders Dokümanı (${course.title}): ${course.pdfDocumentUrl}")
                                                    type = "text/plain"
                                                }
                                                context.startActivity(Intent.createChooser(sendIntent, "Doküman Bağlantısını Paylaş"))
                                            }
                                        }
                                    },
                                    modifier = Modifier.testTag("btn_pdf_share")
                                ) {
                                    Icon(Icons.Default.Share, contentDescription = "Paylaş")
                                }
                            }
                        }

                        // Search Bar (if visible)
                        AnimatedVisibility(visible = showSearchBar) {
                            Surface(
                                color = MaterialTheme.colorScheme.surfaceVariant,
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(horizontal = 12.dp, vertical = 6.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    Icon(Icons.Default.Search, contentDescription = null, tint = MaterialTheme.colorScheme.onSurfaceVariant)
                                    OutlinedTextField(
                                        value = searchQuery,
                                        onValueChange = { searchQuery = it },
                                        placeholder = { Text("Mevzuat, standart veya kelime ara...", fontSize = 13.sp) },
                                        modifier = Modifier
                                            .weight(1f)
                                            .height(48.dp)
                                            .testTag("input_pdf_search_query"),
                                        shape = RoundedCornerShape(8.dp),
                                        singleLine = true
                                    )
                                    if (searchQuery.isNotEmpty()) {
                                        IconButton(onClick = { searchQuery = "" }) {
                                            Icon(Icons.Default.Clear, contentDescription = "Temizle")
                                        }
                                        // Quick Jump to match
                                        Button(
                                            onClick = {
                                                // Jump to a related page based on query
                                                val queryLower = searchQuery.lowercase()
                                                val targetPage = when {
                                                    queryLower.contains("fine") || queryLower.contains("kinney") || queryLower.contains("matris") -> 3
                                                    queryLower.contains("denetim") || queryLower.contains("kontrol") || queryLower.contains("iskele") -> 2
                                                    queryLower.contains("madde") || queryLower.contains("kanun") || queryLower.contains("ceza") -> 1
                                                    else -> (currentPageIndex + 1) % totalPages
                                                }
                                                currentPageIndex = targetPage.coerceIn(0, totalPages - 1)
                                                Toast.makeText(context, "\"$searchQuery\" için Sayfa ${currentPageIndex + 1}'e yönlendirildi", Toast.LENGTH_SHORT).show()
                                            },
                                            shape = RoundedCornerShape(8.dp),
                                            contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                                            modifier = Modifier.testTag("btn_pdf_search_submit")
                                        ) {
                                            Text("Bul", fontSize = 12.sp)
                                        }
                                    }
                                }
                            }
                        }

                        // Top secondary info strip with Zoom controls & direct link
                        Surface(
                            color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(horizontal = 12.dp, vertical = 4.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                // Direct isgcepakademi Link Pill
                                Surface(
                                    shape = RoundedCornerShape(6.dp),
                                    color = domainColor.copy(alpha = 0.12f),
                                    modifier = Modifier.clickable {
                                        val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                                        val clip = ClipData.newPlainText("PDF Link", course.pdfDocumentUrl)
                                        clipboard.setPrimaryClip(clip)
                                        Toast.makeText(context, "Doküman linki kopyalandı: ${course.pdfDocumentUrl}", Toast.LENGTH_SHORT).show()
                                    }
                                ) {
                                    Row(
                                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp),
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                                    ) {
                                        Icon(Icons.Default.Link, contentDescription = null, modifier = Modifier.size(12.dp), tint = domainColor)
                                        Text(
                                            text = course.pdfDocumentUrl,
                                            style = MaterialTheme.typography.labelSmall.copy(
                                                color = domainColor,
                                                fontSize = 11.sp,
                                                fontWeight = FontWeight.Medium
                                            ),
                                            maxLines = 1,
                                            overflow = TextOverflow.Ellipsis
                                        )
                                    }
                                }

                                // Zoom In / Out / Reset
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                                ) {
                                    IconButton(
                                        onClick = {
                                            scale = (scale - 0.25f).coerceAtLeast(1f)
                                            if (scale == 1f) offset = Offset.Zero
                                        },
                                        modifier = Modifier.size(32.dp).testTag("btn_pdf_zoom_out")
                                    ) {
                                        Icon(Icons.Default.Remove, contentDescription = "Küçült", modifier = Modifier.size(16.dp))
                                    }

                                    Surface(
                                        shape = RoundedCornerShape(4.dp),
                                        color = MaterialTheme.colorScheme.surface,
                                        modifier = Modifier.clickable {
                                            scale = 1f
                                            offset = Offset.Zero
                                        }
                                    ) {
                                        Text(
                                            text = "${(scale * 100).toInt()}%",
                                            style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                        )
                                    }

                                    IconButton(
                                        onClick = {
                                            scale = (scale + 0.25f).coerceAtMost(4.5f)
                                        },
                                        modifier = Modifier.size(32.dp).testTag("btn_pdf_zoom_in")
                                    ) {
                                        Icon(Icons.Default.Add, contentDescription = "Büyüt", modifier = Modifier.size(16.dp))
                                    }
                                }
                            }
                        }
                    }
                }

                // 2. MAIN DOCUMENT CANVAS
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxWidth()
                        .background(
                            when (readingMode) {
                                PdfReadingMode.LIGHT -> Color(0xFFE2E8F0)
                                PdfReadingMode.SEPIA -> Color(0xFFEADBCA)
                                PdfReadingMode.NIGHT -> Color(0xFF121212)
                            }
                        )
                        .transformable(state = transformState)
                        .pointerInput(Unit) {
                            detectTapGestures(
                                onDoubleTap = {
                                    scale = if (scale > 1.2f) 1f else 2.2f
                                    offset = Offset.Zero
                                }
                            )
                        },
                    contentAlignment = Alignment.Center
                ) {
                    if (isLoadingPage) {
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            CircularProgressIndicator(color = domainColor)
                            Text(
                                text = "Sayfa ${currentPageIndex + 1} yüksek çözünürlükte işleniyor...",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    } else if (currentBitmap != null) {
                        // Apply night filter if needed
                        val colorFilter = when (readingMode) {
                            PdfReadingMode.NIGHT -> {
                                val matrix = ColorMatrix(
                                    floatArrayOf(
                                        -0.85f, 0f, 0f, 0f, 255f,
                                        0f, -0.85f, 0f, 0f, 255f,
                                        0f, 0f, -0.85f, 0f, 255f,
                                        0f, 0f, 0f, 1f, 0f
                                    )
                                )
                                ColorFilter.colorMatrix(matrix)
                            }
                            PdfReadingMode.SEPIA -> {
                                val matrix = ColorMatrix(
                                    floatArrayOf(
                                        0.9f, 0f, 0f, 0f, 20f,
                                        0f, 0.85f, 0f, 0f, 10f,
                                        0f, 0f, 0.75f, 0f, 0f,
                                        0f, 0f, 0f, 1f, 0f
                                    )
                                )
                                ColorFilter.colorMatrix(matrix)
                            }
                            PdfReadingMode.LIGHT -> null
                        }

                        Card(
                            modifier = Modifier
                                .fillMaxWidth(0.92f)
                                .fillMaxHeight(0.95f)
                                .graphicsLayer(
                                    scaleX = scale,
                                    scaleY = scale,
                                    translationX = offset.x,
                                    translationY = offset.y
                                )
                                .shadow(8.dp, RoundedCornerShape(8.dp))
                                .testTag("card_pdf_rendered_page"),
                            shape = RoundedCornerShape(8.dp),
                            colors = CardDefaults.cardColors(containerColor = paperBackground),
                            border = BorderStroke(1.dp, Color(0xFFCBD5E1))
                        ) {
                            Image(
                                bitmap = currentBitmap!!.asImageBitmap(),
                                contentDescription = "PDF Sayfa ${currentPageIndex + 1}",
                                modifier = Modifier.fillMaxSize(),
                                colorFilter = colorFilter
                            )
                        }
                    }

                    // Watermark / Page Indicator Floating Overlay (Top Right)
                    Surface(
                        modifier = Modifier
                            .align(Alignment.TopEnd)
                            .padding(16.dp),
                        shape = RoundedCornerShape(12.dp),
                        color = MaterialTheme.colorScheme.surface.copy(alpha = 0.9f),
                        shadowElevation = 4.dp
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            Text(
                                text = "Sayfa ${currentPageIndex + 1} / $totalPages",
                                style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold)
                            )
                            if (bookmarkedPages.contains(currentPageIndex + 1)) {
                                Icon(
                                    Icons.Default.Bookmark,
                                    contentDescription = null,
                                    tint = Color(0xFFD4AF37),
                                    modifier = Modifier.size(12.dp)
                                )
                            }
                        }
                    }
                }

                // 3. TABLE OF CONTENTS MODAL (DRAWER SHEET)
                AnimatedVisibility(
                    visible = showTableOfContents,
                    enter = slideInVertically { it } + fadeIn(),
                    exit = slideOutVertically { it } + fadeOut()
                ) {
                    Surface(
                        color = MaterialTheme.colorScheme.surface,
                        tonalElevation = 8.dp,
                        modifier = Modifier
                            .fillMaxWidth()
                            .heightIn(max = 240.dp)
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = "📑 Müfredat ve Doküman Konu Başlıkları",
                                    style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold)
                                )
                                IconButton(
                                    onClick = { showTableOfContents = false },
                                    modifier = Modifier.size(24.dp)
                                ) {
                                    Icon(Icons.Default.Close, contentDescription = "Kapat")
                                }
                            }

                            Spacer(modifier = Modifier.height(8.dp))

                            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                item {
                                    Card(
                                        modifier = Modifier
                                            .width(160.dp)
                                            .clickable {
                                                currentPageIndex = 0
                                                showTableOfContents = false
                                            },
                                        shape = RoundedCornerShape(8.dp),
                                        colors = CardDefaults.cardColors(
                                            containerColor = if (currentPageIndex == 0) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surfaceVariant
                                        )
                                    ) {
                                        Column(modifier = Modifier.padding(10.dp)) {
                                            Text("Kapak & Özet", style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold))
                                            Text("Sayfa 1", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                        }
                                    }
                                }

                                itemsIndexed(course.syllabus) { index, item ->
                                    val targetPageIndex = (index + 1).coerceAtMost(totalPages - 1)
                                    val isCurrent = currentPageIndex == targetPageIndex

                                    Card(
                                        modifier = Modifier
                                            .width(190.dp)
                                            .clickable {
                                                currentPageIndex = targetPageIndex
                                                showTableOfContents = false
                                            },
                                        shape = RoundedCornerShape(8.dp),
                                        colors = CardDefaults.cardColors(
                                            containerColor = if (isCurrent) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surfaceVariant
                                        )
                                    ) {
                                        Column(modifier = Modifier.padding(10.dp)) {
                                            Text(
                                                text = item,
                                                style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                                                maxLines = 2,
                                                overflow = TextOverflow.Ellipsis
                                            )
                                            Spacer(modifier = Modifier.height(4.dp))
                                            Text("Sayfa ${targetPageIndex + 1}", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                        }
                                    }
                                }
                            }
                        }
                    }
                }

                // 4. BOTTOM CONTROLS & PAGE SLIDER
                Surface(
                    color = MaterialTheme.colorScheme.surface,
                    tonalElevation = 4.dp,
                    shadowElevation = 8.dp
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp, vertical = 10.dp)
                    ) {
                        // Slider & Page nav buttons
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            // Prev Page
                            IconButton(
                                onClick = {
                                    if (currentPageIndex > 0) currentPageIndex--
                                },
                                enabled = currentPageIndex > 0,
                                modifier = Modifier.testTag("btn_pdf_prev_page")
                            ) {
                                Icon(Icons.Default.ArrowBackIos, contentDescription = "Önceki Sayfa", modifier = Modifier.size(18.dp))
                            }

                            // Slider
                            Slider(
                                value = (currentPageIndex + 1).toFloat(),
                                onValueChange = { newValue ->
                                    currentPageIndex = (newValue.toInt() - 1).coerceIn(0, totalPages - 1)
                                },
                                valueRange = 1f..totalPages.toFloat(),
                                steps = (totalPages - 2).coerceAtLeast(0),
                                modifier = Modifier
                                    .weight(1f)
                                    .testTag("slider_pdf_page_navigation")
                            )

                            // Next Page
                            IconButton(
                                onClick = {
                                    if (currentPageIndex < totalPages - 1) currentPageIndex++
                                },
                                enabled = currentPageIndex < totalPages - 1,
                                modifier = Modifier.testTag("btn_pdf_next_page")
                            ) {
                                Icon(Icons.Default.ArrowForwardIos, contentDescription = "Sonraki Sayfa", modifier = Modifier.size(18.dp))
                            }
                        }

                        // Thumbnail Quick Page Strips
                        LazyRow(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(6.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            items(totalPages) { pageIdx ->
                                val isSelected = pageIdx == currentPageIndex
                                val hasBookmark = bookmarkedPages.contains(pageIdx + 1)

                                Surface(
                                    modifier = Modifier
                                        .clickable { currentPageIndex = pageIdx }
                                        .testTag("thumb_pdf_page_${pageIdx + 1}"),
                                    shape = RoundedCornerShape(6.dp),
                                    color = if (isSelected) domainColor else MaterialTheme.colorScheme.surfaceVariant,
                                    border = if (isSelected) BorderStroke(2.dp, Color(0xFFD4AF37)) else null
                                ) {
                                    Row(
                                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                                    ) {
                                        Text(
                                            text = "${pageIdx + 1}",
                                            style = MaterialTheme.typography.labelSmall.copy(
                                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                                color = if (isSelected) Color.White else MaterialTheme.colorScheme.onSurfaceVariant
                                            )
                                        )
                                        if (hasBookmark) {
                                            Icon(
                                                Icons.Default.Bookmark,
                                                contentDescription = null,
                                                tint = if (isSelected) Color(0xFFD4AF37) else MaterialTheme.colorScheme.primary,
                                                modifier = Modifier.size(10.dp)
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
