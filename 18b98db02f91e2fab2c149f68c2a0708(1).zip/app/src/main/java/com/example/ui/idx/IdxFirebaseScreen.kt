package com.example.ui.idx

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.FirebaseRuleTest
import com.example.ui.components.CodeViewerCard
import com.example.ui.components.SectionHeader
import com.example.ui.components.StatCard
import com.example.ui.theme.ErrorRose
import com.example.ui.theme.FirebaseAmber
import com.example.ui.theme.SuccessEmerald

@Composable
fun IdxFirebaseScreen(
    ruleTests: List<FirebaseRuleTest>,
    onSaveSnippet: (String, String, String) -> Unit,
    modifier: Modifier = Modifier
) {
    var activeService by remember { mutableStateOf("Firestore") }

    val firestoreRulesCode = """
rules_version = '2';
service cloud.firestore {
  match /databases/{database}/documents {
    // Public post feeds
    match /posts/{postId} {
      allow read: if true;
      allow create: if request.auth != null;
      allow update, delete: if request.auth != null && request.auth.uid == resource.data.authorId;
    }
    
    // User profile documents
    match /users/{userId} {
      allow read: if request.auth != null;
      allow write: if request.auth != null && request.auth.uid == userId;
    }
    
    // Admin configuration
    match /system/{document=**} {
      allow read, write: if request.auth.token.admin == true;
    }
  }
}
    """.trimIndent()

    val cloudFunctionsCode = """
import { onDocumentCreated } from "firebase-functions/v2/firestore";
import { GoogleGenerativeAI } from "@google/generative-ai";

const genAI = new GoogleGenerativeAI(process.env.GEMINI_API_KEY!);

export const autoTagPost = onDocumentCreated("posts/{postId}", async (event) => {
  const snapshot = event.data;
  if (!snapshot) return;
  
  const content = snapshot.data().text;
  const model = genAI.getGenerativeModel({ model: "gemini-3.5-flash" });
  
  const result = await model.generateContent([
    "Generate 3 comma-separated category tags for this post:",
    content
  ]);
  
  const tags = result.response.text().split(",").map(t => t.trim());
  return snapshot.ref.update({ tags, status: "PROCESSED" });
});
    """.trimIndent()

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            SectionHeader(
                title = "Firebase Backend",
                subtitle = "idx.google.com ├── Firebase Backend (Firestore, Rules, Cloud Functions)",
                badge = "Firebase v10+ & Gen 2",
                badgeColor = FirebaseAmber
            )
        }

        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                StatCard(
                    title = "Auth Providers",
                    value = "Google & GitHub",
                    icon = Icons.Default.Lock,
                    accentColor = FirebaseAmber,
                    modifier = Modifier.weight(1f)
                )
                StatCard(
                    title = "Cloud Functions",
                    value = "2nd Gen (Cloud Run)",
                    icon = Icons.Default.CloudQueue,
                    accentColor = SuccessEmerald,
                    modifier = Modifier.weight(1f)
                )
            }
        }

        // Service Tab Selector
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                listOf("Firestore", "Cloud Functions", "Security Rules Tester").forEach { tab ->
                    val isSelected = activeService == tab
                    FilterChip(
                        selected = isSelected,
                        onClick = { activeService = tab },
                        label = { Text(tab, fontSize = 12.sp) },
                        modifier = Modifier.testTag("firebase_tab_$tab")
                    )
                }
            }
        }

        when (activeService) {
            "Firestore" -> {
                item {
                    CodeViewerCard(
                        title = "firestore.rules",
                        language = "javascript",
                        code = firestoreRulesCode
                    )
                }
                item {
                    OutlinedButton(
                        onClick = { onSaveSnippet("Firestore Security Rules", "Firebase", firestoreRulesCode) },
                        modifier = Modifier.fillMaxWidth().testTag("save_firebase_rules_button")
                    ) {
                        Icon(Icons.Default.BookmarkBorder, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Save Rules to Snippet Vault")
                    }
                }
            }
            "Cloud Functions" -> {
                item {
                    CodeViewerCard(
                        title = "functions/src/index.ts (Gemini Auto-Tag Trigger)",
                        language = "typescript",
                        code = cloudFunctionsCode
                    )
                }
                item {
                    OutlinedButton(
                        onClick = { onSaveSnippet("Gemini Cloud Function", "Firebase", cloudFunctionsCode) },
                        modifier = Modifier.fillMaxWidth().testTag("save_firebase_func_button")
                    ) {
                        Icon(Icons.Default.BookmarkBorder, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Save Cloud Function Template")
                    }
                }
            }
            "Security Rules Tester" -> {
                item {
                    Text(
                        text = "Emulator Security Rules Evaluation Matrix",
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.SemiBold)
                    )
                }
                items(ruleTests) { test ->
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(10.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                        border = androidx.compose.foundation.BorderStroke(
                            1.dp,
                            if (test.allowed) SuccessEmerald.copy(alpha = 0.5f) else ErrorRose.copy(alpha = 0.5f)
                        )
                    ) {
                        Row(
                            modifier = Modifier.padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                    Surface(
                                        color = if (test.allowed) SuccessEmerald.copy(alpha = 0.15f) else ErrorRose.copy(alpha = 0.15f),
                                        shape = RoundedCornerShape(4.dp)
                                    ) {
                                        Text(
                                            text = if (test.allowed) "ALLOWED" else "DENIED",
                                            color = if (test.allowed) SuccessEmerald else ErrorRose,
                                            style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                        )
                                    }
                                    Text(
                                        text = test.name,
                                        style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold)
                                    )
                                }
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = "${test.operation.uppercase()} on ${test.path}",
                                    style = MaterialTheme.typography.bodySmall.copy(fontFamily = FontFamily.Monospace),
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                                Spacer(modifier = Modifier.height(2.dp))
                                Text(
                                    text = "Role: ${test.authRole}",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }

                            Icon(
                                imageVector = if (test.allowed) Icons.Default.CheckCircle else Icons.Default.Block,
                                contentDescription = null,
                                tint = if (test.allowed) SuccessEmerald else ErrorRose,
                                modifier = Modifier.size(24.dp)
                            )
                        }
                    }
                }
            }
        }
    }
}
