package com.example.ui.isg

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.widget.Toast
import androidx.compose.animation.*
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.remote.VoiceSynthesisResult
import com.example.model.ClonedVoiceProfile
import com.example.model.IsgCourseModule
import com.example.ui.theme.*
import kotlinx.coroutines.launch

/**
 * Compose UI Component that enables users to input text scripts for ISG course modules
 * and triggers ElevenLabs API wrapper to generate high-fidelity narrated audio.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun IsgModuleNarrationStudioDialog(
    initialCourse: IsgCourseModule? = null,
    allCourses: List<IsgCourseModule> = emptyList(),
    voiceProfiles: List<ClonedVoiceProfile>,
    onSynthesize: suspend (text: String, voiceProfile: ClonedVoiceProfile, apiKey: String) -> VoiceSynthesisResult,
    onDismiss: () -> Unit,
    onSendToVideoStudio: ((courseTitle: String, scriptText: String, voice: ClonedVoiceProfile) -> Unit)? = null,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    var selectedCourse by remember { mutableStateOf(initialCourse ?: allCourses.firstOrNull()) }
    var selectedTopic by remember { mutableStateOf(selectedCourse?.syllabus?.firstOrNull() ?: "") }
    
    var scriptText by remember(selectedCourse, selectedTopic) {
        val courseTitle = selectedCourse?.title ?: "İş Sağlığı ve Güvenliği Eğitimi"
        val topic = if (selectedTopic.isNotBlank()) selectedTopic else "Temel Prensipler"
        mutableStateOf(
            "Merhaba değerli meslektaşlarım. Bugün $courseTitle modülümüzün '$topic' konusunu ele alıyoruz. 6331 sayılı İSG Kanunu ve ilgili yönetmelikler gereğince sahada proaktif güvenlik kültürünü oluşturmak en temel hedefimizdir."
        )
    }

    var selectedVoice by remember(voiceProfiles) {
        mutableStateOf(voiceProfiles.firstOrNull { it.provider.contains("ElevenLabs", ignoreCase = true) } 
            ?: voiceProfiles.firstOrNull()
            ?: ClonedVoiceProfile(
                id = "default_el",
                name = "Eğitmen Ahmet Bey (Klon)",
                provider = "ElevenLabs Instant Cloning",
                voiceId = "21m00Tcm4TlvDq8ikWAM",
                description = "İSG Baş Denetçi Ses Tonu",
                gender = "Erkek"
            )
        )
    }

    var apiKey by remember { mutableStateOf("") }
    var showApiKey by remember { mutableStateOf(false) }

    var stability by remember { mutableFloatStateOf(selectedVoice.stability) }
    var similarityBoost by remember { mutableFloatStateOf(selectedVoice.similarityBoost) }
    var showAdvancedSettings by remember { mutableStateOf(false) }

    var isGenerating by remember { mutableStateOf(false) }
    var generatedResult by remember { mutableStateOf<VoiceSynthesisResult.Success?>(null) }
    var errorMessage by remember { mutableStateOf<String?>(null) }
    var isPlayingPreview by remember { mutableStateOf(false) }

    val wordCount = remember(scriptText) { scriptText.split(Regex("\\s+")).filter { it.isNotBlank() }.size }
    val estimatedDurationSec = remember(wordCount) { (wordCount / 2.5).toInt().coerceAtLeast(3) }

    BasicAlertDialog(
        onDismissRequest = { if (!isGenerating) onDismiss() },
        modifier = modifier
            .fillMaxWidth()
            .padding(12.dp)
            .testTag("dialog_module_narration_studio")
    ) {
        Surface(
            shape = RoundedCornerShape(24.dp),
            color = MaterialTheme.colorScheme.surface,
            tonalElevation = 6.dp,
            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.2f))
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(20.dp)
                    .verticalScroll(rememberScrollState())
            ) {
                // Header Bar
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Surface(
                            shape = CircleShape,
                            color = GeminiPurple.copy(alpha = 0.15f),
                            modifier = Modifier.size(40.dp)
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Icon(
                                    Icons.Default.RecordVoiceOver,
                                    contentDescription = null,
                                    tint = GeminiPurple,
                                    modifier = Modifier.size(22.dp)
                                )
                            }
                        }
                        Column {
                            Text(
                                text = "Modül Seslendirme Stüdyosu",
                                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                            )
                            Text(
                                text = "ElevenLabs Authenticated Text-to-Speech API",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }

                    IconButton(
                        onClick = onDismiss,
                        enabled = !isGenerating
                    ) {
                        Icon(Icons.Default.Close, contentDescription = "Kapat")
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Course & Syllabus Topic Selector
                if (allCourses.isNotEmpty() && initialCourse == null) {
                    Text(
                        text = "Ders Modülü Seçimi:",
                        style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold)
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        allCourses.take(3).forEach { course ->
                            val isSelected = selectedCourse?.id == course.id
                            FilterChip(
                                selected = isSelected,
                                onClick = {
                                    selectedCourse = course
                                    selectedTopic = course.syllabus.firstOrNull() ?: ""
                                },
                                label = {
                                    Text(
                                        text = course.title.take(18) + if (course.title.length > 18) "..." else "",
                                        fontSize = 11.sp
                                    )
                                },
                                modifier = Modifier.weight(1f)
                            )
                        }
                    }
                    Spacer(modifier = Modifier.height(12.dp))
                }

                // Syllabus Topics Chips
                selectedCourse?.syllabus?.let { topics ->
                    if (topics.isNotEmpty()) {
                        Text(
                            text = "Müfredat Konu Başlığı:",
                            style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold)
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            topics.take(3).forEach { top ->
                                val isSelected = selectedTopic == top
                                FilterChip(
                                    selected = isSelected,
                                    onClick = {
                                        selectedTopic = top
                                        scriptText = "Merhaba değerli meslektaşlarım. ${selectedCourse?.title ?: "Eğitimimiz"} kapsamında '$top' konusunu ele alıyoruz. Standartlar ve yasal mevzuat gerekliliklerine dikkatle uyulmalıdır."
                                    },
                                    label = { Text(top.take(16) + if (top.length > 16) ".." else "", fontSize = 11.sp) },
                                    modifier = Modifier.weight(1f)
                                )
                            }
                        }
                        Spacer(modifier = Modifier.height(14.dp))
                    }
                }

                // Script Input Field
                Text(
                    text = "Seslendirilecek Eğitim Senaryosu (Metin):",
                    style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold)
                )
                Spacer(modifier = Modifier.height(6.dp))
                OutlinedTextField(
                    value = scriptText,
                    onValueChange = { scriptText = it },
                    placeholder = { Text("Eğitmenin okuyacağı metni buraya yazın...") },
                    minLines = 4,
                    maxLines = 8,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("input_narration_script"),
                    shape = RoundedCornerShape(12.dp)
                )

                Spacer(modifier = Modifier.height(6.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Kelime: $wordCount • Karakter: ${scriptText.length} • Süre: ~$estimatedDurationSec sn",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )

                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        FilledTonalButton(
                            onClick = {
                                scriptText = "6331 sayılı İSG Kanunu Madde 4 gereğince, işveren çalışanların işle ilgili sağlık ve güvenliğini sağlamakla yükümlüdür. Risk değerlendirmesi yapılmalı, çalışanlara uygun KKD temin edilmelidir."
                            },
                            shape = RoundedCornerShape(8.dp),
                            contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp)
                        ) {
                            Text("Mevzuat Şablonu", fontSize = 10.5.sp)
                        }
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // ElevenLabs Voice Selection Card
                Card(
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.35f)),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.15f))
                ) {
                    Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "Klon Ses Profili (ElevenLabs)",
                                style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold)
                            )
                            Surface(
                                shape = RoundedCornerShape(6.dp),
                                color = GeminiPurple.copy(alpha = 0.15f)
                            ) {
                                Text(
                                    text = "Multilingual v2",
                                    style = MaterialTheme.typography.labelSmall.copy(color = GeminiPurple, fontWeight = FontWeight.Bold),
                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                )
                            }
                        }

                        // Voice Selector Chips
                        Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            voiceProfiles.forEach { profile ->
                                val isSelected = selectedVoice.id == profile.id
                                Surface(
                                    shape = RoundedCornerShape(10.dp),
                                    color = if (isSelected) MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.5f) else MaterialTheme.colorScheme.surface,
                                    border = BorderStroke(
                                        if (isSelected) 1.5.dp else 1.dp,
                                        if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outline.copy(alpha = 0.2f)
                                    ),
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clickable {
                                            selectedVoice = profile
                                            stability = profile.stability
                                            similarityBoost = profile.similarityBoost
                                        }
                                ) {
                                    Row(
                                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 8.dp),
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.SpaceBetween
                                    ) {
                                        Row(
                                            verticalAlignment = Alignment.CenterVertically,
                                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                                        ) {
                                            Icon(
                                                if (profile.gender == "Kadın") Icons.Default.Female else Icons.Default.Male,
                                                contentDescription = null,
                                                tint = if (profile.gender == "Kadın") GeminiPurple else IdxBlue,
                                                modifier = Modifier.size(18.dp)
                                            )
                                            Column {
                                                Text(
                                                    text = profile.name,
                                                    style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Bold)
                                                )
                                                Text(
                                                    text = "ID: ${profile.voiceId.take(12)}... • ${profile.provider}",
                                                    style = MaterialTheme.typography.labelSmall.copy(fontSize = 10.sp, fontFamily = FontFamily.Monospace),
                                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                                )
                                            }
                                        }
                                        RadioButton(selected = isSelected, onClick = { selectedVoice = profile })
                                    }
                                }
                            }
                        }

                        // Advanced Settings Toggle
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { showAdvancedSettings = !showAdvancedSettings },
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "Gelişmiş Ses Ayarları & API Key",
                                style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.SemiBold, color = MaterialTheme.colorScheme.primary)
                            )
                            Icon(
                                if (showAdvancedSettings) Icons.Default.KeyboardArrowUp else Icons.Default.KeyboardArrowDown,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.size(18.dp)
                            )
                        }

                        AnimatedVisibility(visible = showAdvancedSettings) {
                            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                                OutlinedTextField(
                                    value = apiKey,
                                    onValueChange = { apiKey = it },
                                    label = { Text("ElevenLabs xi-api-key (Opsiyonel / Secrets)") },
                                    placeholder = { Text("sk_... veya boş bırakın") },
                                    visualTransformation = if (showApiKey) VisualTransformation.None else PasswordVisualTransformation(),
                                    trailingIcon = {
                                        IconButton(onClick = { showApiKey = !showApiKey }) {
                                            Icon(
                                                if (showApiKey) Icons.Default.VisibilityOff else Icons.Default.Visibility,
                                                contentDescription = null,
                                                modifier = Modifier.size(18.dp)
                                            )
                                        }
                                    },
                                    singleLine = true,
                                    modifier = Modifier.fillMaxWidth()
                                )

                                Column {
                                    Text("Stabilite (Stability): %${(stability * 100).toInt()}", style = MaterialTheme.typography.labelSmall)
                                    Slider(
                                        value = stability,
                                        onValueChange = { stability = it },
                                        valueRange = 0.1f..1.0f
                                    )
                                }

                                Column {
                                    Text("Benzerlik Artışı (Similarity Boost): %${(similarityBoost * 100).toInt()}", style = MaterialTheme.typography.labelSmall)
                                    Slider(
                                        value = similarityBoost,
                                        onValueChange = { similarityBoost = it },
                                        valueRange = 0.1f..1.0f
                                    )
                                }
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Error Message if any
                if (errorMessage != null) {
                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = ErrorRose.copy(alpha = 0.15f),
                        border = BorderStroke(1.dp, ErrorRose.copy(alpha = 0.3f)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier.padding(10.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Icon(Icons.Default.ErrorOutline, contentDescription = null, tint = ErrorRose, modifier = Modifier.size(20.dp))
                            Text(text = errorMessage ?: "", color = ErrorRose, style = MaterialTheme.typography.bodySmall)
                        }
                    }
                    Spacer(modifier = Modifier.height(10.dp))
                }

                // Generated Audio Player Preview Box
                if (generatedResult != null) {
                    val result = generatedResult!!
                    Card(
                        shape = RoundedCornerShape(14.dp),
                        colors = CardDefaults.cardColors(containerColor = SuccessEmerald.copy(alpha = 0.1f)),
                        border = BorderStroke(1.5.dp, SuccessEmerald.copy(alpha = 0.5f)),
                        modifier = Modifier.fillMaxWidth().testTag("box_generated_audio_result")
                    ) {
                        Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                                ) {
                                    Icon(Icons.Default.CheckCircle, contentDescription = null, tint = SuccessEmerald, modifier = Modifier.size(18.dp))
                                    Text(
                                        text = "Ses Sentezi Başarılı!",
                                        style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold, color = SuccessEmerald)
                                    )
                                }
                                Text(
                                    text = "${result.latencyMs} ms • ~${result.durationSeconds} sn",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }

                            // Audio Player Bar
                            Surface(
                                shape = RoundedCornerShape(10.dp),
                                color = MaterialTheme.colorScheme.surface,
                                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.2f))
                            ) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(8.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                                ) {
                                    Surface(
                                        shape = CircleShape,
                                        color = SuccessEmerald,
                                        modifier = Modifier
                                            .size(36.dp)
                                            .clickable {
                                                isPlayingPreview = !isPlayingPreview
                                                Toast.makeText(context, if (isPlayingPreview) "Ses çalınıyor..." else "Durduruldu.", Toast.LENGTH_SHORT).show()
                                            }
                                    ) {
                                        Box(contentAlignment = Alignment.Center) {
                                            Icon(
                                                if (isPlayingPreview) Icons.Default.Pause else Icons.Default.PlayArrow,
                                                contentDescription = "Oynat/Durdur",
                                                tint = Color.White,
                                                modifier = Modifier.size(20.dp)
                                            )
                                        }
                                    }

                                    Column(modifier = Modifier.weight(1f)) {
                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.SpaceBetween
                                        ) {
                                            Text(
                                                text = "${selectedVoice.name} - MP3 44.1kHz",
                                                style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold)
                                            )
                                            Text(
                                                text = "00:${result.durationSeconds}",
                                                style = MaterialTheme.typography.labelSmall,
                                                color = MaterialTheme.colorScheme.onSurfaceVariant
                                            )
                                        }
                                        Spacer(modifier = Modifier.height(4.dp))
                                        LinearProgressIndicator(
                                            progress = { if (isPlayingPreview) 0.65f else 0.0f },
                                            modifier = Modifier.fillMaxWidth().height(4.dp).clip(RoundedCornerShape(2.dp)),
                                            color = SuccessEmerald
                                        )
                                    }
                                }
                            }

                            // Action buttons: Copy link & send to Video Studio
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                OutlinedButton(
                                    onClick = {
                                        val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                                        val clip = ClipData.newPlainText("Audio URL", result.audioUrl)
                                        clipboard.setPrimaryClip(clip)
                                        Toast.makeText(context, "Ses MP3 bağlantısı kopyalandı!", Toast.LENGTH_SHORT).show()
                                    },
                                    shape = RoundedCornerShape(8.dp),
                                    modifier = Modifier.weight(1f),
                                    contentPadding = PaddingValues(horizontal = 6.dp, vertical = 4.dp)
                                ) {
                                    Icon(Icons.Default.ContentCopy, contentDescription = null, modifier = Modifier.size(14.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("Linki Kopyala", fontSize = 11.sp)
                                }

                                if (onSendToVideoStudio != null) {
                                    Button(
                                        onClick = {
                                            val title = "${selectedCourse?.title ?: "İSG Modülü"} - $selectedTopic"
                                            onSendToVideoStudio(title, scriptText, selectedVoice)
                                            onDismiss()
                                        },
                                        shape = RoundedCornerShape(8.dp),
                                        colors = ButtonDefaults.buttonColors(containerColor = GeminiPurple),
                                        modifier = Modifier.weight(1f),
                                        contentPadding = PaddingValues(horizontal = 6.dp, vertical = 4.dp)
                                    ) {
                                        Icon(Icons.Default.VideoCameraFront, contentDescription = null, modifier = Modifier.size(14.dp))
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text("Videoya Dönüştür", fontSize = 11.sp)
                                    }
                                }
                            }
                        }
                    }
                    Spacer(modifier = Modifier.height(14.dp))
                }

                // Trigger Button: ElevenLabs Speech Generation
                Button(
                    onClick = {
                        scope.launch {
                            isGenerating = true
                            errorMessage = null
                            val tuningVoice = selectedVoice.copy(
                                stability = stability,
                                similarityBoost = similarityBoost
                            )
                            val res = onSynthesize(scriptText, tuningVoice, apiKey)
                            isGenerating = false
                            if (res is VoiceSynthesisResult.Success) {
                                generatedResult = res
                                Toast.makeText(context, "ElevenLabs ile seslendirme tamamlandı!", Toast.LENGTH_SHORT).show()
                            } else if (res is VoiceSynthesisResult.Error) {
                                errorMessage = res.message
                            }
                        }
                    },
                    enabled = !isGenerating && scriptText.isNotBlank(),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(50.dp)
                        .testTag("btn_trigger_elevenlabs_narration"),
                    shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = GeminiPurple)
                ) {
                    if (isGenerating) {
                        CircularProgressIndicator(
                            modifier = Modifier.size(20.dp),
                            color = Color.White,
                            strokeWidth = 2.5.dp
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("ElevenLabs Sentezliyor...", fontWeight = FontWeight.Bold)
                    } else {
                        Icon(Icons.Default.AutoAwesome, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("🎙️ ElevenLabs ile Seslendir", fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}
