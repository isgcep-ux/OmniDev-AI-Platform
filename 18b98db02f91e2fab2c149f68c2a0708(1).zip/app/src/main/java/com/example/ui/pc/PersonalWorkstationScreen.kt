package com.example.ui.pc

import androidx.compose.animation.*
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.NoteAdd
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.model.PersonalPcWorkstation
import com.example.model.PersonalTerminalEntry
import com.example.model.PersonalWorkspaceFile
import com.example.model.PersonalWorkspaceNote
import com.example.ui.theme.*

private val CyberDark = Color(0xFF0D1117)
private val CyberSurface = Color(0xFF161B22)
private val CyberBorder = Color(0xFF30363D)
private val CyberAccent = Color(0xFF58A6FF)
private val CyberGreen = Color(0xFF3FB950)
private val CyberPurple = Color(0xFFBC8CFF)
private val CyberOrange = Color(0xFFF0883E)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PersonalWorkstationScreen(
    workstation: PersonalPcWorkstation,
    files: List<PersonalWorkspaceFile>,
    notes: List<PersonalWorkspaceNote>,
    terminalLogs: List<PersonalTerminalEntry>,
    onUpdateWorkstation: (PersonalPcWorkstation) -> Unit,
    onSaveFile: (PersonalWorkspaceFile) -> Unit,
    onDeleteFile: (String) -> Unit,
    onSaveNote: (PersonalWorkspaceNote) -> Unit,
    onDeleteNote: (String) -> Unit,
    onTogglePinNote: (String) -> Unit,
    onExecuteCommand: (String) -> Unit,
    onClearTerminal: () -> Unit,
    onSetDpiScale: (Float) -> Unit,
    onSetWindowMode: (String) -> Unit,
    onNavigateToTab: (String) -> Unit = {},
    modifier: Modifier = Modifier
) {
    var selectedPcSection by remember { mutableStateOf(0) } // 0: Masaüstü & Sistem, 1: Dosya Gezgini, 2: Terminal, 3: Notlar, 4: Ayarlar
    var activeFileForEdit by remember { mutableStateOf<PersonalWorkspaceFile?>(null) }
    var activeNoteForEdit by remember { mutableStateOf<PersonalWorkspaceNote?>(null) }
    var showNewFileDialog by remember { mutableStateOf(false) }
    var showNewNoteDialog by remember { mutableStateOf(false) }

    val sections = listOf(
        "🖥️ Masaüstü" to Icons.Default.Computer,
        "🗂️ Dosyalar (${files.size})" to Icons.Default.FolderOpen,
        "💻 Terminal" to Icons.Default.Terminal,
        "📝 Notlar (${notes.size})" to Icons.Default.EditNote,
        "⚙️ PC Ayarları" to Icons.Default.Tune
    )

    // Edit File Dialog
    if (activeFileForEdit != null) {
        PersonalFileEditorDialog(
            file = activeFileForEdit!!,
            onSave = { updated ->
                onSaveFile(updated)
                activeFileForEdit = null
            },
            onDelete = { id ->
                onDeleteFile(id)
                activeFileForEdit = null
            },
            onDismiss = { activeFileForEdit = null }
        )
    }

    // New File Dialog
    if (showNewFileDialog) {
        PersonalNewFileDialog(
            onConfirm = { name, category, content ->
                val ext = name.substringAfterLast(".", "txt")
                val newFile = PersonalWorkspaceFile(
                    id = "file_${System.currentTimeMillis()}",
                    path = "/workspace/$name",
                    name = name,
                    extension = ext,
                    sizeBytes = content.toByteArray().size.toLong().coerceAtLeast(100L),
                    category = category,
                    content = content
                )
                onSaveFile(newFile)
                showNewFileDialog = false
            },
            onDismiss = { showNewFileDialog = false }
        )
    }

    // New Note Dialog
    if (showNewNoteDialog) {
        PersonalNewNoteDialog(
            onConfirm = { title, content, category, tags ->
                val newNote = PersonalWorkspaceNote(
                    id = "note_${System.currentTimeMillis()}",
                    title = title,
                    content = content,
                    category = category,
                    tags = tags
                )
                onSaveNote(newNote)
                showNewNoteDialog = false
            },
            onDismiss = { showNewNoteDialog = false }
        )
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        // Workstation Top Banner (PC Status & Specs Header)
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 8.dp)
                .testTag("card_pc_top_header"),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = CyberDark),
            border = BorderStroke(1.dp, CyberBorder)
        ) {
            Column(modifier = Modifier.padding(14.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(40.dp)
                                .clip(RoundedCornerShape(10.dp))
                                .background(
                                    Brush.linearGradient(
                                        listOf(CyberAccent, CyberPurple)
                                    )
                                ),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                Icons.Default.LaptopChromebook,
                                contentDescription = null,
                                tint = Color.White,
                                modifier = Modifier.size(22.dp)
                            )
                        }
                        Column {
                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                Text(
                                    text = workstation.hostname,
                                    style = MaterialTheme.typography.titleSmall.copy(
                                        fontWeight = FontWeight.Bold,
                                        fontFamily = FontFamily.Monospace
                                    ),
                                    color = Color.White
                                )
                                Box(
                                    modifier = Modifier
                                        .size(8.dp)
                                        .clip(CircleShape)
                                        .background(CyberGreen)
                                )
                            }
                            Text(
                                text = "${workstation.ownerName} • ${workstation.ownerRole}",
                                style = MaterialTheme.typography.labelSmall,
                                color = Color.LightGray
                            )
                        }
                    }

                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = if (workstation.isTurboBoostEnabled) CyberGreen.copy(alpha = 0.2f) else CyberBorder,
                        border = BorderStroke(1.dp, if (workstation.isTurboBoostEnabled) CyberGreen else CyberBorder)
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            Icon(
                                Icons.Default.Bolt,
                                contentDescription = null,
                                tint = if (workstation.isTurboBoostEnabled) CyberGreen else Color.Gray,
                                modifier = Modifier.size(14.dp)
                            )
                            Text(
                                text = if (workstation.isTurboBoostEnabled) "TURBO (4.5 GHz)" else "DENGELİ",
                                style = MaterialTheme.typography.labelSmall.copy(
                                    fontWeight = FontWeight.Bold,
                                    fontFamily = FontFamily.Monospace
                                ),
                                color = if (workstation.isTurboBoostEnabled) CyberGreen else Color.LightGray,
                                fontSize = 10.sp
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))
                HorizontalDivider(color = CyberBorder)
                Spacer(modifier = Modifier.height(10.dp))

                // Hardware Live Metric Gauges
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    PcMetricMiniItem(
                        icon = Icons.Default.Memory,
                        label = "CPU Yükü",
                        value = "%${workstation.cpuUsagePercent}",
                        tint = if (workstation.cpuUsagePercent > 70) CyberOrange else CyberAccent
                    )
                    PcMetricMiniItem(
                        icon = Icons.Default.Storage,
                        label = "RAM Bellek",
                        value = "${workstation.ramUsedGb} / ${workstation.ramTotalGb} GB",
                        tint = CyberPurple
                    )
                    PcMetricMiniItem(
                        icon = Icons.Default.FolderZip,
                        label = "Disk Alanı",
                        value = "${workstation.diskUsedGb} / ${workstation.diskTotalGb} GB",
                        tint = CyberGreen
                    )
                    PcMetricMiniItem(
                        icon = Icons.Default.Schedule,
                        label = "Uptime",
                        value = "7g 18s",
                        tint = CyberOrange
                    )
                }
            }
        }

        // Section Tabs
        val scrollState = rememberScrollState()
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(scrollState)
                .padding(horizontal = 16.dp, vertical = 4.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            sections.forEachIndexed { index, (title, icon) ->
                val isSelected = selectedPcSection == index
                FilterChip(
                    selected = isSelected,
                    onClick = { selectedPcSection = index },
                    leadingIcon = {
                        Icon(
                            icon,
                            contentDescription = null,
                            modifier = Modifier.size(16.dp),
                            tint = if (isSelected) CyberAccent else MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    },
                    label = {
                        Text(
                            text = title,
                            style = MaterialTheme.typography.labelMedium.copy(
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                            )
                        )
                    },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = CyberAccent.copy(alpha = 0.15f),
                        selectedLabelColor = CyberAccent
                    ),
                    modifier = Modifier.testTag("pc_subtab_$index")
                )
            }
        }

        Spacer(modifier = Modifier.height(4.dp))

        // Content Body
        Box(modifier = Modifier.fillMaxSize().weight(1f)) {
            AnimatedContent(
                targetState = selectedPcSection,
                transitionSpec = { fadeIn() togetherWith fadeOut() },
                label = "PcSectionTransition"
            ) { targetSection ->
                when (targetSection) {
                    0 -> PcDesktopDashboardView(
                        workstation = workstation,
                        files = files,
                        notes = notes,
                        onOpenTerminal = { selectedPcSection = 2 },
                        onOpenFiles = { selectedPcSection = 1 },
                        onOpenNotes = { selectedPcSection = 3 },
                        onOpenFile = { file -> activeFileForEdit = file },
                        onToggleTurbo = {
                            onUpdateWorkstation(
                                workstation.copy(
                                    isTurboBoostEnabled = !workstation.isTurboBoostEnabled,
                                    cpuUsagePercent = if (!workstation.isTurboBoostEnabled) 28 else 14
                                )
                            )
                        }
                    )
                    1 -> PcFileExplorerView(
                        files = files,
                        onOpenFile = { file -> activeFileForEdit = file },
                        onNewFile = { showNewFileDialog = true },
                        onDeleteFile = onDeleteFile
                    )
                    2 -> PcTerminalView(
                        logs = terminalLogs,
                        workstation = workstation,
                        onExecuteCommand = onExecuteCommand,
                        onClearLogs = onClearTerminal
                    )
                    3 -> PcNotesView(
                        notes = notes,
                        onNewNote = { showNewNoteDialog = true },
                        onTogglePin = onTogglePinNote,
                        onDeleteNote = onDeleteNote
                    )
                    4 -> PcSettingsView(
                        workstation = workstation,
                        onUpdate = onUpdateWorkstation,
                        onSetDpi = onSetDpiScale,
                        onSetWindowMode = onSetWindowMode
                    )
                }
            }
        }
    }
}

@Composable
private fun PcMetricMiniItem(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    label: String,
    value: String,
    tint: Color
) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(3.dp)
        ) {
            Icon(icon, contentDescription = null, tint = tint, modifier = Modifier.size(13.dp))
            Text(text = label, style = MaterialTheme.typography.labelSmall, color = Color.Gray, fontSize = 10.sp)
        }
        Spacer(modifier = Modifier.height(2.dp))
        Text(
            text = value,
            style = MaterialTheme.typography.labelSmall.copy(
                fontWeight = FontWeight.Bold,
                fontFamily = FontFamily.Monospace
            ),
            color = Color.White,
            fontSize = 11.sp
        )
    }
}

@Composable
private fun PcDesktopDashboardView(
    workstation: PersonalPcWorkstation,
    files: List<PersonalWorkspaceFile>,
    notes: List<PersonalWorkspaceNote>,
    onOpenTerminal: () -> Unit,
    onOpenFiles: () -> Unit,
    onOpenNotes: () -> Unit,
    onOpenFile: (PersonalWorkspaceFile) -> Unit,
    onToggleTurbo: () -> Unit
) {
    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // Quick App Dock (Workstation Desktop Launcher)
        item {
            Text(
                text = "⚡ Kişisel İş İstasyonu Hızlı Başlatıcı (Dock)",
                style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold)
            )
            Spacer(modifier = Modifier.height(8.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                PcDockAppItem(
                    title = "Terminal",
                    desc = "Bash CLI",
                    icon = Icons.Default.Terminal,
                    accentColor = CyberGreen,
                    onClick = onOpenTerminal,
                    modifier = Modifier.weight(1f)
                )
                PcDockAppItem(
                    title = "Gezgin",
                    desc = "${files.size} Dosya",
                    icon = Icons.Default.FolderZip,
                    accentColor = CyberAccent,
                    onClick = onOpenFiles,
                    modifier = Modifier.weight(1f)
                )
                PcDockAppItem(
                    title = "Not Defteri",
                    desc = "${notes.size} Not",
                    icon = Icons.Default.EditNote,
                    accentColor = CyberPurple,
                    onClick = onOpenNotes,
                    modifier = Modifier.weight(1f)
                )
                PcDockAppItem(
                    title = "Turbo Güç",
                    desc = if (workstation.isTurboBoostEnabled) "Aktif" else "Kapalı",
                    icon = Icons.Default.Bolt,
                    accentColor = CyberOrange,
                    onClick = onToggleTurbo,
                    modifier = Modifier.weight(1f)
                )
            }
        }

        // Detailed System Hardware Specs Card
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Icon(Icons.Default.Dns, contentDescription = null, tint = CyberAccent)
                            Text(
                                text = "Kişisel Bilgisayar Donanım & Çekirdek",
                                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                            )
                        }
                        Surface(
                            shape = RoundedCornerShape(6.dp),
                            color = CyberAccent.copy(alpha = 0.15f)
                        ) {
                            Text(
                                text = "x86_64 Cloud Native",
                                color = CyberAccent,
                                style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    PcSpecRow("İşlemci (CPU)", workstation.cpuModel)
                    PcSpecRow("İşletim Sistemi", workstation.osName)
                    PcSpecRow("Kernel Çekirdeği", workstation.kernelVersion)
                    PcSpecRow("Yerel IP & Ağ", "${workstation.localIp} • 10 Gbps Sanal Köprü")
                    PcSpecRow("Emülatör Pencere Modu", "${workstation.windowMode} (${workstation.emulatorDpiScale}x DPI)")
                    PcSpecRow("Sistem Teması", workstation.activeTheme)
                }
            }
        }

        // Recent Workspace Files Quick Access
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "📂 Son Çalışma Dosyalarım",
                    style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold)
                )
                TextButton(onClick = onOpenFiles) {
                    Text("Tümünü Gör (${files.size})")
                }
            }

            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                files.take(3).forEach { file ->
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { onOpenFile(file) },
                        shape = RoundedCornerShape(12.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(12.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(10.dp),
                                modifier = Modifier.weight(1f)
                            ) {
                                Surface(
                                    shape = RoundedCornerShape(8.dp),
                                    color = when (file.category) {
                                        "KAYNAK KOD" -> CyberAccent.copy(alpha = 0.15f)
                                        "İSG RAPORU" -> CyberOrange.copy(alpha = 0.15f)
                                        "YAPILANDIRMA" -> CyberPurple.copy(alpha = 0.15f)
                                        else -> CyberGreen.copy(alpha = 0.15f)
                                    },
                                    modifier = Modifier.size(36.dp)
                                ) {
                                    Box(contentAlignment = Alignment.Center) {
                                        Icon(
                                            when (file.category) {
                                                "KAYNAK KOD" -> Icons.Default.Code
                                                "İSG RAPORU" -> Icons.Default.Assignment
                                                "YAPILANDIRMA" -> Icons.Default.Settings
                                                else -> Icons.Default.Description
                                            },
                                            contentDescription = null,
                                            tint = when (file.category) {
                                                "KAYNAK KOD" -> CyberAccent
                                                "İSG RAPORU" -> CyberOrange
                                                "YAPILANDIRMA" -> CyberPurple
                                                else -> CyberGreen
                                            },
                                            modifier = Modifier.size(20.dp)
                                        )
                                    }
                                }
                                Column {
                                    Text(
                                        text = file.name,
                                        style = MaterialTheme.typography.bodyMedium.copy(
                                            fontWeight = FontWeight.SemiBold,
                                            fontFamily = FontFamily.Monospace
                                        )
                                    )
                                    Text(
                                        text = "${file.path} • ${(file.sizeBytes / 1024.0).let { String.format(java.util.Locale.US, "%.1f KB", it) }}",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            }

                            Icon(
                                Icons.Default.ChevronRight,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun PcDockAppItem(
    title: String,
    desc: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    accentColor: Color,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier
            .clip(RoundedCornerShape(12.dp))
            .clickable { onClick() },
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(1.dp, accentColor.copy(alpha = 0.3f))
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 10.dp, horizontal = 4.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Surface(
                shape = CircleShape,
                color = accentColor.copy(alpha = 0.15f),
                modifier = Modifier.size(36.dp)
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Icon(icon, contentDescription = null, tint = accentColor, modifier = Modifier.size(20.dp))
                }
            }
            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = title,
                style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                fontSize = 11.sp
            )
            Text(
                text = desc,
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                fontSize = 9.sp
            )
        }
    }
}

@Composable
private fun PcSpecRow(label: String, value: String) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            text = label,
            style = MaterialTheme.typography.labelSmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        Text(
            text = value,
            style = MaterialTheme.typography.labelSmall.copy(
                fontWeight = FontWeight.Medium,
                fontFamily = FontFamily.Monospace
            )
        )
    }
}

// -------------------------------------------------------------
// FILE EXPLORER VIEW
// -------------------------------------------------------------
@Composable
private fun PcFileExplorerView(
    files: List<PersonalWorkspaceFile>,
    onOpenFile: (PersonalWorkspaceFile) -> Unit,
    onNewFile: () -> Unit,
    onDeleteFile: (String) -> Unit
) {
    var searchQuery by remember { mutableStateOf("") }
    var selectedCategory by remember { mutableStateOf("Tümü") }

    val categories = listOf("Tümü", "KAYNAK KOD", "İSG RAPORU", "YAPILANDIRMA", "DOKÜMAN", "SCRİPT")

    val filteredFiles = files.filter { file ->
        val matchesCategory = selectedCategory == "Tümü" || file.category.equals(selectedCategory, ignoreCase = true)
        val matchesSearch = searchQuery.isBlank() ||
                file.name.contains(searchQuery, ignoreCase = true) ||
                file.content.contains(searchQuery, ignoreCase = true)
        matchesCategory && matchesSearch
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        // Explorer Action Bar
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = "🗂️ Kişisel Dosya Gezgini (/workspace)",
                    style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold)
                )
                Text(
                    text = "${filteredFiles.size} dosya listeleniyor",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            Button(
                onClick = onNewFile,
                shape = RoundedCornerShape(8.dp),
                colors = ButtonDefaults.buttonColors(containerColor = CyberAccent),
                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp)
            ) {
                Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(4.dp))
                Text("Yeni Dosya", fontSize = 12.sp, fontWeight = FontWeight.Bold)
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Search Bar
        OutlinedTextField(
            value = searchQuery,
            onValueChange = { searchQuery = it },
            placeholder = { Text("Dosya adı veya içerik ara...", fontSize = 13.sp) },
            leadingIcon = { Icon(Icons.Default.Search, contentDescription = null, modifier = Modifier.size(18.dp)) },
            trailingIcon = {
                if (searchQuery.isNotEmpty()) {
                    IconButton(onClick = { searchQuery = "" }) {
                        Icon(Icons.Default.Clear, contentDescription = "Temizle", modifier = Modifier.size(18.dp))
                    }
                }
            },
            singleLine = true,
            shape = RoundedCornerShape(10.dp),
            modifier = Modifier
                .fillMaxWidth()
                .testTag("input_search_pc_files")
        )

        Spacer(modifier = Modifier.height(8.dp))

        // Category Filter Chips
        LazyRow(
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            items(categories) { cat ->
                val isSelected = selectedCategory == cat
                FilterChip(
                    selected = isSelected,
                    onClick = { selectedCategory = cat },
                    label = { Text(cat, fontSize = 11.sp) },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = CyberAccent.copy(alpha = 0.15f),
                        selectedLabelColor = CyberAccent
                    )
                )
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        // File List
        if (filteredFiles.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(Icons.Default.FolderOff, contentDescription = null, tint = Color.Gray, modifier = Modifier.size(48.dp))
                    Spacer(modifier = Modifier.height(8.dp))
                    Text("Dosya bulunamadı.", color = Color.Gray)
                }
            }
        } else {
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(filteredFiles, key = { it.id }) { file ->
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { onOpenFile(file) }
                            .testTag("card_pc_file_${file.id}"),
                        shape = RoundedCornerShape(12.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f))
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(12.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(10.dp),
                                modifier = Modifier.weight(1f)
                            ) {
                                Surface(
                                    shape = RoundedCornerShape(8.dp),
                                    color = when (file.category) {
                                        "KAYNAK KOD" -> CyberAccent.copy(alpha = 0.15f)
                                        "İSG RAPORU" -> CyberOrange.copy(alpha = 0.15f)
                                        "YAPILANDIRMA" -> CyberPurple.copy(alpha = 0.15f)
                                        else -> CyberGreen.copy(alpha = 0.15f)
                                    },
                                    modifier = Modifier.size(38.dp)
                                ) {
                                    Box(contentAlignment = Alignment.Center) {
                                        Icon(
                                            when (file.category) {
                                                "KAYNAK KOD" -> Icons.Default.Code
                                                "İSG RAPORU" -> Icons.Default.Assignment
                                                "YAPILANDIRMA" -> Icons.Default.Settings
                                                else -> Icons.Default.Description
                                            },
                                            contentDescription = null,
                                            tint = when (file.category) {
                                                "KAYNAK KOD" -> CyberAccent
                                                "İSG RAPORU" -> CyberOrange
                                                "YAPILANDIRMA" -> CyberPurple
                                                else -> CyberGreen
                                            },
                                            modifier = Modifier.size(20.dp)
                                        )
                                    }
                                }

                                Column {
                                    Text(
                                        text = file.name,
                                        style = MaterialTheme.typography.bodyMedium.copy(
                                            fontWeight = FontWeight.Bold,
                                            fontFamily = FontFamily.Monospace
                                        )
                                    )
                                    Text(
                                        text = "${file.path} • ${(file.sizeBytes / 1024.0).let { String.format(java.util.Locale.US, "%.1f KB", it) }} • ${file.lastModified}",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            }

                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Surface(
                                    shape = RoundedCornerShape(4.dp),
                                    color = MaterialTheme.colorScheme.surfaceVariant
                                ) {
                                    Text(
                                        text = file.category,
                                        style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.SemiBold),
                                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
                                        fontSize = 9.sp
                                    )
                                }
                                Spacer(modifier = Modifier.width(6.dp))
                                IconButton(
                                    onClick = { onDeleteFile(file.id) },
                                    modifier = Modifier.size(28.dp)
                                ) {
                                    Icon(Icons.Default.DeleteOutline, contentDescription = "Sil", tint = Color.Gray, modifier = Modifier.size(16.dp))
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

// -------------------------------------------------------------
// TERMINAL VIEW
// -------------------------------------------------------------
@Composable
private fun PcTerminalView(
    logs: List<PersonalTerminalEntry>,
    workstation: PersonalPcWorkstation,
    onExecuteCommand: (String) -> Unit,
    onClearLogs: () -> Unit
) {
    var commandInput by remember { mutableStateOf("") }
    val listState = rememberLazyListState()

    val quickCommands = listOf(
        "sysinfo", "ls", "cat fine_kinney_calculator.py", "isg-check",
        "gemini İSG mevzuatında gürültü sınırları", "top", "ping isgcepakademi.com.tr", "help"
    )

    LaunchedEffect(logs.size) {
        if (logs.isNotEmpty()) {
            listState.animateScrollToItem(logs.size - 1)
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(CyberDark)
            .padding(12.dp)
    ) {
        // Terminal Window Header Bar
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(topStart = 10.dp, topEnd = 10.dp))
                .background(CyberSurface)
                .padding(horizontal = 12.dp, vertical = 8.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                Box(modifier = Modifier.size(10.dp).clip(CircleShape).background(Color(0xFFFF5F56)))
                Box(modifier = Modifier.size(10.dp).clip(CircleShape).background(Color(0xFFFFBD2E)))
                Box(modifier = Modifier.size(10.dp).clip(CircleShape).background(Color(0xFF27C93F)))
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = "ozben@${workstation.hostname}: ~/workspace (dev-bash)",
                    style = MaterialTheme.typography.labelSmall.copy(
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold
                    ),
                    color = Color.LightGray
                )
            }

            IconButton(
                onClick = onClearLogs,
                modifier = Modifier.size(24.dp)
            ) {
                Icon(Icons.Default.DeleteSweep, contentDescription = "Terminali Temizle", tint = Color.Gray, modifier = Modifier.size(16.dp))
            }
        }

        // Terminal Log Output Window
        LazyColumn(
            state = listState,
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f)
                .background(Color(0xFF070A0E))
                .padding(10.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            item {
                Text(
                    text = "DevOS Kişisel Bilgisayar Terminali [Sürüm 2.6.4 (x86_64)]\nKomut listesi için 'help' yazabilirsiniz.",
                    style = MaterialTheme.typography.labelSmall.copy(fontFamily = FontFamily.Monospace),
                    color = CyberGreen
                )
            }

            items(logs, key = { it.id }) { log ->
                Column(modifier = Modifier.fillMaxWidth()) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text(
                            text = "ozben@workstation:~$",
                            style = MaterialTheme.typography.labelSmall.copy(
                                fontFamily = FontFamily.Monospace,
                                fontWeight = FontWeight.Bold
                            ),
                            color = CyberAccent
                        )
                        Text(
                            text = log.command,
                            style = MaterialTheme.typography.labelSmall.copy(
                                fontFamily = FontFamily.Monospace,
                                fontWeight = FontWeight.Bold
                            ),
                            color = Color.White
                        )
                        Spacer(modifier = Modifier.weight(1f))
                        Text(
                            text = log.timestamp,
                            style = MaterialTheme.typography.labelSmall.copy(fontFamily = FontFamily.Monospace),
                            color = Color.DarkGray,
                            fontSize = 9.sp
                        )
                    }

                    Spacer(modifier = Modifier.height(2.dp))

                    Text(
                        text = log.output,
                        style = MaterialTheme.typography.bodySmall.copy(fontFamily = FontFamily.Monospace),
                        color = if (log.isError) Color(0xFFFF7B72) else Color(0xFFC9D1D9)
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(6.dp))

        // Quick Command Pills
        LazyRow(
            horizontalArrangement = Arrangement.spacedBy(6.dp),
            modifier = Modifier.padding(vertical = 4.dp)
        ) {
            items(quickCommands) { cmd ->
                Surface(
                    shape = RoundedCornerShape(6.dp),
                    color = CyberSurface,
                    border = BorderStroke(1.dp, CyberBorder),
                    modifier = Modifier.clickable {
                        onExecuteCommand(cmd)
                    }
                ) {
                    Text(
                        text = cmd,
                        style = MaterialTheme.typography.labelSmall.copy(fontFamily = FontFamily.Monospace),
                        color = CyberAccent,
                        fontSize = 10.sp,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(4.dp))

        // Command Input Field
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            OutlinedTextField(
                value = commandInput,
                onValueChange = { commandInput = it },
                placeholder = { Text("Komut yazın (örn: sysinfo, ls, gemini ...)", fontFamily = FontFamily.Monospace, fontSize = 12.sp, color = Color.Gray) },
                singleLine = true,
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Send),
                keyboardActions = KeyboardActions(onSend = {
                    if (commandInput.isNotBlank()) {
                        onExecuteCommand(commandInput)
                        commandInput = ""
                    }
                }),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = CyberAccent,
                    unfocusedBorderColor = CyberBorder,
                    focusedTextColor = Color.White,
                    unfocusedTextColor = Color.White,
                    focusedContainerColor = CyberSurface,
                    unfocusedContainerColor = CyberSurface
                ),
                shape = RoundedCornerShape(8.dp),
                modifier = Modifier
                    .weight(1f)
                    .testTag("input_pc_terminal_command")
            )

            Button(
                onClick = {
                    if (commandInput.isNotBlank()) {
                        onExecuteCommand(commandInput)
                        commandInput = ""
                    }
                },
                colors = ButtonDefaults.buttonColors(containerColor = CyberAccent),
                shape = RoundedCornerShape(8.dp),
                contentPadding = PaddingValues(horizontal = 14.dp, vertical = 12.dp)
            ) {
                Icon(Icons.Default.Send, contentDescription = "Gönder", tint = Color.White, modifier = Modifier.size(16.dp))
            }
        }
    }
}

// -------------------------------------------------------------
// NOTES VIEW
// -------------------------------------------------------------
@Composable
private fun PcNotesView(
    notes: List<PersonalWorkspaceNote>,
    onNewNote: () -> Unit,
    onTogglePin: (String) -> Unit,
    onDeleteNote: (String) -> Unit
) {
    val clipboardManager = LocalClipboardManager.current

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = "📝 Kişisel Çalışma Notları & Defter",
                    style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold)
                )
                Text(
                    text = "${notes.size} aktif not kaydedildi",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            Button(
                onClick = onNewNote,
                shape = RoundedCornerShape(8.dp),
                colors = ButtonDefaults.buttonColors(containerColor = CyberPurple),
                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp)
            ) {
                Icon(Icons.AutoMirrored.Filled.NoteAdd, contentDescription = null, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(4.dp))
                Text("Yeni Not", fontSize = 12.sp, fontWeight = FontWeight.Bold)
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        if (notes.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f),
                contentAlignment = Alignment.Center
            ) {
                Text("Henüz not eklenmedi. Yeni not oluşturun.", color = Color.Gray)
            }
        } else {
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                items(notes, key = { it.id }) { note ->
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        border = BorderStroke(
                            if (note.isPinned) 1.5.dp else 1.dp,
                            if (note.isPinned) CyberPurple else MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f)
                        )
                    ) {
                        Column(modifier = Modifier.padding(14.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                                    modifier = Modifier.weight(1f)
                                ) {
                                    if (note.isPinned) {
                                        Icon(Icons.Default.PushPin, contentDescription = null, tint = CyberPurple, modifier = Modifier.size(16.dp))
                                    }
                                    Text(
                                        text = note.title,
                                        style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold)
                                    )
                                }

                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    IconButton(
                                        onClick = { onTogglePin(note.id) },
                                        modifier = Modifier.size(28.dp)
                                    ) {
                                        Icon(
                                            Icons.Default.PushPin,
                                            contentDescription = "Sabitle",
                                            tint = if (note.isPinned) CyberPurple else Color.Gray,
                                            modifier = Modifier.size(16.dp)
                                        )
                                    }
                                    IconButton(
                                        onClick = {
                                            clipboardManager.setText(AnnotatedString("${note.title}\n\n${note.content}"))
                                        },
                                        modifier = Modifier.size(28.dp)
                                    ) {
                                        Icon(Icons.Default.ContentCopy, contentDescription = "Kopyala", tint = Color.Gray, modifier = Modifier.size(16.dp))
                                    }
                                    IconButton(
                                        onClick = { onDeleteNote(note.id) },
                                        modifier = Modifier.size(28.dp)
                                    ) {
                                        Icon(Icons.Default.DeleteOutline, contentDescription = "Sil", tint = Color.Gray, modifier = Modifier.size(16.dp))
                                    }
                                }
                            }

                            Spacer(modifier = Modifier.height(6.dp))
                            Text(
                                text = note.content,
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurface
                            )

                            Spacer(modifier = Modifier.height(10.dp))

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                    Surface(
                                        shape = RoundedCornerShape(4.dp),
                                        color = CyberPurple.copy(alpha = 0.15f)
                                    ) {
                                        Text(
                                            text = note.category,
                                            style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                                            color = CyberPurple,
                                            fontSize = 9.sp,
                                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                        )
                                    }
                                    note.tags.forEach { tag ->
                                        Surface(
                                            shape = RoundedCornerShape(4.dp),
                                            color = MaterialTheme.colorScheme.surfaceVariant
                                        ) {
                                            Text(
                                                text = "#$tag",
                                                style = MaterialTheme.typography.labelSmall,
                                                fontSize = 9.sp,
                                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                            )
                                        }
                                    }
                                }

                                Text(
                                    text = note.updatedAt,
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                    fontSize = 10.sp
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

// -------------------------------------------------------------
// SETTINGS VIEW
// -------------------------------------------------------------
@Composable
private fun PcSettingsView(
    workstation: PersonalPcWorkstation,
    onUpdate: (PersonalPcWorkstation) -> Unit,
    onSetDpi: (Float) -> Unit,
    onSetWindowMode: (String) -> Unit
) {
    var hostnameInput by remember { mutableStateOf(workstation.hostname) }
    var ownerNameInput by remember { mutableStateOf(workstation.ownerName) }
    var ownerRoleInput by remember { mutableStateOf(workstation.ownerRole) }

    val themes = listOf("Cyber Matrix Dark", "IDX Modern Slate", "Clean Studio Light", "Retro CRT Amber")
    val windowModes = listOf("Desktop Workstation", "Split-Screen Studio", "Mobile Focus")
    val dpiScales = listOf(0.85f to "Kompakt (0.85x)", 1.0f to "Standart (1.0x)", 1.15f to "Büyük (1.15x)")

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Text(
            text = "⚙️ Kişisel Bilgisayar & Emülatör Yapılandırması",
            style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold)
        )

        // User & Workstation Identification
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(12.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
        ) {
            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text(text = "Kullanıcı & Makine Kimliği", style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold))

                OutlinedTextField(
                    value = hostnameInput,
                    onValueChange = { hostnameInput = it },
                    label = { Text("Bilgisayar Adı (Hostname)") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = ownerNameInput,
                    onValueChange = { ownerNameInput = it },
                    label = { Text("Kullanıcı Adı") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = ownerRoleInput,
                    onValueChange = { ownerRoleInput = it },
                    label = { Text("Unvan & Görev") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                Button(
                    onClick = {
                        onUpdate(
                            workstation.copy(
                                hostname = hostnameInput,
                                ownerName = ownerNameInput,
                                ownerRole = ownerRoleInput
                            )
                        )
                    },
                    modifier = Modifier.align(Alignment.End),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Text("Kimliği Güncelle")
                }
            }
        }

        // Window Mode & DPI Scaling
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(12.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
        ) {
            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text(text = "🖥️ Emülatör & Ekran Yerleşimi", style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold))

                Text(text = "Çalışma Alanı Modu:", style = MaterialTheme.typography.labelMedium)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    windowModes.forEach { mode ->
                        val isSelected = workstation.windowMode == mode
                        FilterChip(
                            selected = isSelected,
                            onClick = { onSetWindowMode(mode) },
                            label = { Text(mode, fontSize = 11.sp) }
                        )
                    }
                }

                Spacer(modifier = Modifier.height(4.dp))
                Text(text = "DPI / Yazı Tipi Ölçekleme:", style = MaterialTheme.typography.labelMedium)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    dpiScales.forEach { (scale, label) ->
                        val isSelected = workstation.emulatorDpiScale == scale
                        FilterChip(
                            selected = isSelected,
                            onClick = { onSetDpi(scale) },
                            label = { Text(label, fontSize = 11.sp) }
                        )
                    }
                }
            }
        }

        // Theme Customizer
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(12.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
        ) {
            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text(text = "🎨 Bilgisayar Arayüz Teması", style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold))

                LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(themes) { theme ->
                        val isSelected = workstation.activeTheme == theme
                        FilterChip(
                            selected = isSelected,
                            onClick = { onUpdate(workstation.copy(activeTheme = theme)) },
                            label = { Text(theme, fontSize = 11.sp) }
                        )
                    }
                }
            }
        }
    }
}

// -------------------------------------------------------------
// DIALOGS: File Editor, New File, New Note
// -------------------------------------------------------------
@Composable
private fun PersonalFileEditorDialog(
    file: PersonalWorkspaceFile,
    onSave: (PersonalWorkspaceFile) -> Unit,
    onDelete: (String) -> Unit,
    onDismiss: () -> Unit
) {
    var contentText by remember { mutableStateOf(file.content) }
    val clipboardManager = LocalClipboardManager.current

    Dialog(onDismissRequest = onDismiss) {
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .fillMaxHeight(0.85f),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = CyberDark)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(14.dp)
            ) {
                // Header
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Icon(Icons.Default.Code, contentDescription = null, tint = CyberAccent)
                        Column {
                            Text(
                                text = file.name,
                                style = MaterialTheme.typography.titleSmall.copy(
                                    fontWeight = FontWeight.Bold,
                                    fontFamily = FontFamily.Monospace
                                ),
                                color = Color.White
                            )
                            Text(
                                text = file.path,
                                style = MaterialTheme.typography.labelSmall,
                                color = Color.Gray
                            )
                        }
                    }

                    IconButton(onClick = onDismiss) {
                        Icon(Icons.Default.Close, contentDescription = "Kapat", tint = Color.LightGray)
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                // Editor TextArea
                OutlinedTextField(
                    value = contentText,
                    onValueChange = { contentText = it },
                    textStyle = MaterialTheme.typography.bodySmall.copy(
                        fontFamily = FontFamily.Monospace,
                        color = Color(0xFFC9D1D9)
                    ),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = CyberAccent,
                        unfocusedBorderColor = CyberBorder,
                        focusedContainerColor = Color(0xFF070A0E),
                        unfocusedContainerColor = Color(0xFF070A0E)
                    ),
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f)
                )

                Spacer(modifier = Modifier.height(10.dp))

                // Actions
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(onClick = { onDelete(file.id) }) {
                        Icon(Icons.Default.DeleteOutline, contentDescription = "Sil", tint = Color(0xFFFF7B72))
                    }

                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedButton(
                            onClick = {
                                clipboardManager.setText(AnnotatedString(contentText))
                            },
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Icon(Icons.Default.ContentCopy, contentDescription = null, modifier = Modifier.size(16.dp), tint = Color.White)
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Kopyala", color = Color.White, fontSize = 12.sp)
                        }

                        Button(
                            onClick = {
                                onSave(
                                    file.copy(
                                        content = contentText,
                                        sizeBytes = contentText.toByteArray().size.toLong(),
                                        lastModified = "2026-08-25 " + java.text.SimpleDateFormat("HH:mm", java.util.Locale.getDefault()).format(java.util.Date())
                                    )
                                )
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = CyberGreen),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Icon(Icons.Default.Save, contentDescription = null, modifier = Modifier.size(16.dp), tint = Color.White)
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Kaydet", color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun PersonalNewFileDialog(
    onConfirm: (name: String, category: String, content: String) -> Unit,
    onDismiss: () -> Unit
) {
    var fileName by remember { mutableStateOf("") }
    var category by remember { mutableStateOf("KAYNAK KOD") }
    var initialContent by remember { mutableStateOf("") }

    val categories = listOf("KAYNAK KOD", "İSG RAPORU", "YAPILANDIRMA", "DOKÜMAN", "SCRİPT")

    Dialog(onDismissRequest = onDismiss) {
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Text(
                    text = "📄 Yeni Çalışma Dosyası Oluştur",
                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                )

                OutlinedTextField(
                    value = fileName,
                    onValueChange = { fileName = it },
                    label = { Text("Dosya Adı (örn: isg_denetim_notu.py)") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                Text(text = "Kategori:", style = MaterialTheme.typography.labelSmall)
                LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    items(categories) { cat ->
                        FilterChip(
                            selected = category == cat,
                            onClick = { category = cat },
                            label = { Text(cat, fontSize = 10.sp) }
                        )
                    }
                }

                OutlinedTextField(
                    value = initialContent,
                    onValueChange = { initialContent = it },
                    label = { Text("Başlangıç İçeriği") },
                    minLines = 4,
                    modifier = Modifier.fillMaxWidth()
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.End,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    TextButton(onClick = onDismiss) {
                        Text("İptal")
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    Button(
                        onClick = {
                            if (fileName.isNotBlank()) {
                                onConfirm(fileName.trim(), category, initialContent)
                            }
                        },
                        enabled = fileName.isNotBlank(),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Text("Oluştur")
                    }
                }
            }
        }
    }
}

@Composable
private fun PersonalNewNoteDialog(
    onConfirm: (title: String, content: String, category: String, tags: List<String>) -> Unit,
    onDismiss: () -> Unit
) {
    var title by remember { mutableStateOf("") }
    var content by remember { mutableStateOf("") }
    var category by remember { mutableStateOf("Geliştirme") }
    var tagsInput by remember { mutableStateOf("İSG, Saha") }

    val categories = listOf("Geliştirme", "İSG Mevzuat", "Sistem & Terminal", "Yapılacaklar")

    Dialog(onDismissRequest = onDismiss) {
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Text(
                    text = "📝 Yeni Çalışma Notu",
                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                )

                OutlinedTextField(
                    value = title,
                    onValueChange = { title = it },
                    label = { Text("Not Başlığı") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                Text(text = "Kategori:", style = MaterialTheme.typography.labelSmall)
                LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    items(categories) { cat ->
                        FilterChip(
                            selected = category == cat,
                            onClick = { category = cat },
                            label = { Text(cat, fontSize = 10.sp) }
                        )
                    }
                }

                OutlinedTextField(
                    value = content,
                    onValueChange = { content = it },
                    label = { Text("Not İçeriği") },
                    minLines = 4,
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = tagsInput,
                    onValueChange = { tagsInput = it },
                    label = { Text("Etiketler (Virgülle ayırın)") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.End,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    TextButton(onClick = onDismiss) {
                        Text("İptal")
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    Button(
                        onClick = {
                            if (title.isNotBlank() && content.isNotBlank()) {
                                val parsedTags = tagsInput.split(",").map { it.trim() }.filter { it.isNotBlank() }
                                onConfirm(title.trim(), content.trim(), category, parsedTags)
                            }
                        },
                        enabled = title.isNotBlank() && content.isNotBlank(),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Text("Kaydet")
                    }
                }
            }
        }
    }
}
