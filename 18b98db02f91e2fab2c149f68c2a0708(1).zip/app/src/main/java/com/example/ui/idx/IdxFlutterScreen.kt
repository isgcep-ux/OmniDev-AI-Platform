package com.example.ui.idx

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.FlutterPreset
import com.example.ui.components.CodeViewerCard
import com.example.ui.components.SectionHeader
import com.example.ui.components.StatCard
import com.example.ui.theme.FlutterCyan
import com.example.ui.theme.IdxBlue
import com.example.ui.theme.SuccessEmerald

@Composable
fun IdxFlutterScreen(
    presets: List<FlutterPreset>,
    onSaveSnippet: (String, String, String) -> Unit,
    modifier: Modifier = Modifier
) {
    var selectedPreset by remember { mutableStateOf(presets.firstOrNull()) }
    var selectedRenderer by remember { mutableStateOf("WASM (WebAssembly)") }
    var counterValue by remember { mutableStateOf(42) }
    var isSimulatingHotReload by remember { mutableStateOf(false) }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            SectionHeader(
                title = "Flutter Web Application",
                subtitle = "idx.google.com ├── Flutter Web App (WASM & CanvasKit Compiler)",
                badge = "Project IDX Native",
                badgeColor = FlutterCyan
            )
        }

        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                StatCard(
                    title = "Engine Renderer",
                    value = selectedRenderer,
                    icon = Icons.Default.Speed,
                    accentColor = FlutterCyan,
                    modifier = Modifier.weight(1f)
                )
                StatCard(
                    title = "Frame Rate",
                    value = "60 FPS (WasmGC)",
                    icon = Icons.Default.Bolt,
                    accentColor = SuccessEmerald,
                    modifier = Modifier.weight(1f)
                )
            }
        }

        // Project Presets Selector
        item {
            Text(
                text = "Flutter Architecture Presets",
                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.SemiBold),
                color = MaterialTheme.colorScheme.onBackground
            )
            Spacer(modifier = Modifier.height(8.dp))
            LazyRow(
                horizontalArrangement = Arrangement.spacedBy(10.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                items(presets) { preset ->
                    val isSelected = selectedPreset?.id == preset.id
                    Card(
                        modifier = Modifier
                            .width(220.dp)
                            .clickable {
                                selectedPreset = preset
                                selectedRenderer = preset.renderer
                            }
                            .testTag("flutter_preset_${preset.id}"),
                        shape = RoundedCornerShape(12.dp),
                        colors = CardDefaults.cardColors(
                            containerColor = if (isSelected) FlutterCyan.copy(alpha = 0.15f)
                            else MaterialTheme.colorScheme.surfaceVariant
                        ),
                        border = androidx.compose.foundation.BorderStroke(
                            if (isSelected) 1.5.dp else 1.dp,
                            if (isSelected) FlutterCyan else MaterialTheme.colorScheme.outline.copy(alpha = 0.3f)
                        )
                    ) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Text(
                                text = preset.title,
                                style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                                color = if (isSelected) FlutterCyan else MaterialTheme.colorScheme.onSurface
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "State: ${preset.stateManagement}",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
            }
        }

        // Live Web Preview Sandbox
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.3f))
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Icon(Icons.Default.Devices, contentDescription = null, tint = FlutterCyan)
                            Text(
                                text = "Interactive Canvas Preview",
                                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                            )
                        }

                        Button(
                            onClick = {
                                isSimulatingHotReload = true
                                counterValue += 5
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = FlutterCyan),
                            modifier = Modifier.testTag("hot_reload_button")
                        ) {
                            Icon(Icons.Default.Refresh, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Hot Reload", fontSize = 12.sp)
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    // Simulated Device Viewport
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(140.dp)
                            .clip(RoundedCornerShape(10.dp))
                            .background(MaterialTheme.colorScheme.surfaceVariant)
                            .padding(16.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text(
                                text = "Project IDX Flutter Web Client",
                                style = MaterialTheme.typography.labelMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            Spacer(modifier = Modifier.height(6.dp))
                            Text(
                                text = "State Count: $counterValue",
                                style = MaterialTheme.typography.headlineMedium.copy(fontWeight = FontWeight.ExtraBold),
                                color = FlutterCyan
                            )
                            Spacer(modifier = Modifier.height(8.dp))
                            FilledTonalButton(
                                onClick = { counterValue++ },
                                modifier = Modifier.testTag("increment_widget_button")
                            ) {
                                Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("Tap Widget", fontSize = 12.sp)
                            }
                        }
                    }
                }
            }
        }

        // Code and Pubspec Blocks
        selectedPreset?.let { preset ->
            item {
                CodeViewerCard(
                    title = "lib/main.dart (${preset.stateManagement})",
                    language = "dart",
                    code = preset.sampleCode
                )
            }

            item {
                CodeViewerCard(
                    title = "pubspec.yaml",
                    language = "yaml",
                    code = preset.pubspecYaml
                )
            }

            item {
                OutlinedButton(
                    onClick = {
                        onSaveSnippet(preset.title, "Flutter", preset.sampleCode)
                    },
                    modifier = Modifier.fillMaxWidth().testTag("save_flutter_snippet_button")
                ) {
                    Icon(Icons.Default.BookmarkBorder, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Save Flutter Snippet to Local Library")
                }
            }
        }
    }
}
