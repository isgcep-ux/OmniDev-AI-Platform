package com.example.ui.aistudio

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.QuizQuestion
import com.example.ui.components.SectionHeader
import com.example.ui.components.StatCard
import com.example.ui.theme.ErrorRose
import com.example.ui.theme.GeminiPurple
import com.example.ui.theme.IdxBlue
import com.example.ui.theme.SuccessEmerald
import kotlinx.coroutines.launch

@Composable
fun AiQAGeneratorScreen(
    questions: List<QuizQuestion>,
    onGenerateCustomQA: suspend (String, String) -> QuizQuestion?,
    modifier: Modifier = Modifier
) {
    val coroutineScope = rememberCoroutineScope()
    var selectedStack by remember { mutableStateOf("All Stacks") }
    var selectedDifficulty by remember { mutableStateOf("Intermediate") }
    val userAnswers = remember { mutableStateMapOf<String, Int>() }
    var isGeneratingCustom by remember { mutableStateOf(false) }
    var dynamicQuestions by remember { mutableStateOf(questions) }

    val filteredQuestions = if (selectedStack == "All Stacks") {
        dynamicQuestions
    } else {
        dynamicQuestions.filter { it.stack.equals(selectedStack, ignoreCase = true) }
    }

    val correctCount = userAnswers.count { (qId, ansIdx) ->
        dynamicQuestions.find { it.id == qId }?.correctIndex == ansIdx
    }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            SectionHeader(
                title = "AI Q&A Generator",
                subtitle = "aistudio.google.com ├── AI Q&A Generator (Interactive Quiz & Deep Dive)",
                badge = "Gemini Powered",
                badgeColor = GeminiPurple
            )
        }

        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                StatCard(
                    title = "Quiz Score",
                    value = "$correctCount / ${userAnswers.size} Correct",
                    icon = Icons.Default.Quiz,
                    accentColor = SuccessEmerald,
                    modifier = Modifier.weight(1f)
                )
                StatCard(
                    title = "Questions Available",
                    value = "${filteredQuestions.size} Questions",
                    icon = Icons.Default.School,
                    accentColor = GeminiPurple,
                    modifier = Modifier.weight(1f)
                )
            }
        }

        // Stack & Difficulty Filters
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Text(
                        text = "Select Technology Stack & Difficulty",
                        style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold)
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        listOf("All Stacks", "Flutter", "Next.js", "Firebase", "Gemini").forEach { stack ->
                            FilterChip(
                                selected = selectedStack == stack,
                                onClick = { selectedStack = stack },
                                label = { Text(stack, fontSize = 11.sp) },
                                modifier = Modifier.testTag("filter_stack_$stack")
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(6.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            listOf("Junior", "Intermediate", "Senior", "Architect").forEach { diff ->
                                FilterChip(
                                    selected = selectedDifficulty == diff,
                                    onClick = { selectedDifficulty = diff },
                                    label = { Text(diff, fontSize = 11.sp) },
                                    modifier = Modifier.testTag("filter_diff_$diff")
                                )
                            }
                        }

                        Button(
                            onClick = {
                                coroutineScope.launch {
                                    isGeneratingCustom = true
                                    val newQ = onGenerateCustomQA(selectedStack, selectedDifficulty)
                                    if (newQ != null) {
                                        dynamicQuestions = listOf(newQ) + dynamicQuestions
                                    }
                                    isGeneratingCustom = false
                                }
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = GeminiPurple),
                            enabled = !isGeneratingCustom,
                            modifier = Modifier.testTag("generate_ai_qa_button")
                        ) {
                            Icon(Icons.Default.AutoAwesome, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(if (isGeneratingCustom) "Synthesizing..." else "AI Gen Q&A", fontSize = 11.sp)
                        }
                    }
                }
            }
        }

        // Questions List
        items(filteredQuestions) { q ->
            val userAnswer = userAnswers[q.id]
            val isAnswered = userAnswer != null

            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.3f))
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            Surface(
                                shape = RoundedCornerShape(4.dp),
                                color = GeminiPurple.copy(alpha = 0.15f)
                            ) {
                                Text(
                                    text = q.stack,
                                    color = GeminiPurple,
                                    style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                )
                            }
                            Surface(
                                shape = RoundedCornerShape(4.dp),
                                color = MaterialTheme.colorScheme.surfaceVariant
                            ) {
                                Text(
                                    text = q.difficulty,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                    style = MaterialTheme.typography.labelSmall,
                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                )
                            }
                        }

                        if (isAnswered) {
                            val isCorrect = userAnswer == q.correctIndex
                            Surface(
                                shape = RoundedCornerShape(4.dp),
                                color = if (isCorrect) SuccessEmerald.copy(alpha = 0.15f) else ErrorRose.copy(alpha = 0.15f)
                            ) {
                                Text(
                                    text = if (isCorrect) "✓ CORRECT" else "✗ INCORRECT",
                                    color = if (isCorrect) SuccessEmerald else ErrorRose,
                                    style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))
                    Text(
                        text = q.question,
                        style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.SemiBold, lineHeight = 20.sp)
                    )

                    Spacer(modifier = Modifier.height(12.dp))
                    q.options.forEachIndexed { index, option ->
                        val isSelected = userAnswer == index
                        val isCorrectChoice = isAnswered && index == q.correctIndex
                        val isWrongChoice = isAnswered && isSelected && index != q.correctIndex

                        Surface(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 4.dp)
                                .clickable(enabled = !isAnswered) {
                                    userAnswers[q.id] = index
                                }
                                .testTag("option_${q.id}_$index"),
                            shape = RoundedCornerShape(8.dp),
                            color = when {
                                isCorrectChoice -> SuccessEmerald.copy(alpha = 0.15f)
                                isWrongChoice -> ErrorRose.copy(alpha = 0.15f)
                                isSelected -> IdxBlue.copy(alpha = 0.15f)
                                else -> MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f)
                            },
                            border = androidx.compose.foundation.BorderStroke(
                                1.dp,
                                when {
                                    isCorrectChoice -> SuccessEmerald
                                    isWrongChoice -> ErrorRose
                                    isSelected -> IdxBlue
                                    else -> Color.Transparent
                                }
                            )
                        ) {
                            Row(
                                modifier = Modifier.padding(12.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Text(
                                    text = "${('A' + index)}.",
                                    style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold),
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                                Text(
                                    text = option,
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                            }
                        }
                    }

                    AnimatedVisibility(visible = isAnswered) {
                        Column(modifier = Modifier.padding(top = 10.dp)) {
                            Surface(
                                shape = RoundedCornerShape(8.dp),
                                color = MaterialTheme.colorScheme.surfaceVariant,
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Column(modifier = Modifier.padding(12.dp)) {
                                    Text(
                                        text = "Explanation & Architectural Context:",
                                        style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold),
                                        color = GeminiPurple
                                    )
                                    Spacer(modifier = Modifier.height(4.dp))
                                    Text(
                                        text = q.explanation,
                                        style = MaterialTheme.typography.bodySmall.copy(lineHeight = 18.sp)
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
