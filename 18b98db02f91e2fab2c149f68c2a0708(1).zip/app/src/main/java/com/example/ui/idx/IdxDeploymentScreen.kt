package com.example.ui.idx

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.DeploymentTarget
import com.example.ui.components.CodeViewerCard
import com.example.ui.components.SectionHeader
import com.example.ui.components.StatCard
import com.example.ui.theme.IdxBlue
import com.example.ui.theme.SuccessEmerald
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

@Composable
fun IdxDeploymentScreen(
    targets: List<DeploymentTarget>,
    modifier: Modifier = Modifier
) {
    val coroutineScope = rememberCoroutineScope()
    var isDeploying by remember { mutableStateOf(false) }
    var deployLogs by remember {
        mutableStateOf(
            """
[10:14:02] Initializing Cloud Build pipeline in Project IDX container...
[10:14:04] Step 1: Compiling Flutter Web WASM binaries (wasm-gc target) -> OK
[10:14:08] Step 2: Next.js Turbopack build & SSR server bundle generated -> OK
[10:14:11] Step 3: Firebase Hosting CDN cache synchronized (34 static assets) -> OK
[10:14:14] Step 4: Google Cloud Run service updated (idx-backend-cr-xr5db) -> ACTIVE
[10:14:15] Deployment complete! Live URL: https://idx-devstudio.web.app
            """.trimIndent()
        )
    }

    val cicdYaml = """
# .github/workflows/idx-deploy.yml (or cloudbuild.yaml)
steps:
  - name: 'gcr.io/cloud-builders/npm'
    args: ['install', '--frozen-lockfile']
  - name: 'ghcr.io/flutter/flutter:3.24.0'
    args: ['flutter', 'build', 'web', '--wasm']
  - name: 'gcr.io/cloud-builders/gcloud'
    args: ['run', 'deploy', 'idx-service', '--image', 'gcr.io/idx-workspace/app:latest', '--region', 'europe-west2', '--allow-unauthenticated']
    """.trimIndent()

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            SectionHeader(
                title = "Cloud Deployment Pipeline",
                subtitle = "idx.google.com ├── Deployment (Firebase Hosting & Google Cloud Run)",
                badge = "Global Edge CDN",
                badgeColor = IdxBlue
            )
        }

        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                StatCard(
                    title = "Primary URL",
                    value = "idx-devstudio.web.app",
                    icon = Icons.Default.Language,
                    accentColor = IdxBlue,
                    modifier = Modifier.weight(1f)
                )
                StatCard(
                    title = "Cloud Regions",
                    value = "europe-west2 & Global",
                    icon = Icons.Default.Public,
                    accentColor = SuccessEmerald,
                    modifier = Modifier.weight(1f)
                )
            }
        }

        // Deployment Targets
        item {
            Text(
                text = "Target Environments",
                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.SemiBold)
            )
        }

        items(targets) { target ->
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.3f))
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = target.name,
                            style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold)
                        )
                        Surface(
                            color = SuccessEmerald.copy(alpha = 0.15f),
                            shape = RoundedCornerShape(4.dp)
                        ) {
                            Text(
                                text = target.status,
                                color = SuccessEmerald,
                                style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "URL: ${target.url}",
                        style = MaterialTheme.typography.bodySmall.copy(
                            fontFamily = FontFamily.Monospace,
                            color = IdxBlue
                        )
                    )
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                        text = "Provider: ${target.provider} • Deployed: ${target.lastDeployTime}",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }

        // Live Log Terminal
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.3f))
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Icon(Icons.Default.Terminal, contentDescription = null, tint = IdxBlue)
                            Text(
                                text = "Build & Deploy Log Stream",
                                style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold)
                            )
                        }

                        Button(
                            onClick = {
                                coroutineScope.launch {
                                    isDeploying = true
                                    deployLogs = "[Triggering live release...] Compiling WASM & Edge containers..."
                                    delay(800)
                                    deployLogs = """
[Triggering live release...] Compiling WASM & Edge containers...
[00:00:01] Project IDX cloud image rebuilt
[00:00:02] Firebase Hosting CDN updated -> 200 OK
[00:00:03] Deployment Successful!
                                    """.trimIndent()
                                    isDeploying = false
                                }
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = IdxBlue),
                            enabled = !isDeploying,
                            modifier = Modifier.testTag("trigger_deploy_button")
                        ) {
                            Icon(Icons.Default.CloudUpload, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(if (isDeploying) "Deploying..." else "Trigger Deploy", fontSize = 12.sp)
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))
                    Surface(
                        color = MaterialTheme.colorScheme.surfaceVariant,
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(
                            text = deployLogs,
                            style = MaterialTheme.typography.bodySmall.copy(
                                fontFamily = FontFamily.Monospace,
                                fontSize = 11.sp,
                                lineHeight = 16.sp
                            ),
                            modifier = Modifier.padding(12.dp)
                        )
                    }
                }
            }
        }

        // CI/CD Config
        item {
            CodeViewerCard(
                title = "cloudbuild.yaml (GCP CI/CD Pipeline)",
                language = "yaml",
                code = cicdYaml
            )
        }
    }
}
