package com.example.ui.idx

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.NextJsRoute
import com.example.ui.components.CodeViewerCard
import com.example.ui.components.SectionHeader
import com.example.ui.components.StatCard
import com.example.ui.theme.GeminiPurple
import com.example.ui.theme.IdxBlue
import com.example.ui.theme.SuccessEmerald

@Composable
fun IdxNextJsScreen(
    routes: List<NextJsRoute>,
    onSaveSnippet: (String, String, String) -> Unit,
    modifier: Modifier = Modifier
) {
    var selectedRoute by remember { mutableStateOf(routes.firstOrNull()) }
    var actionStatus by remember { mutableStateOf("IDLE") }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            SectionHeader(
                title = "Next.js Web Platform",
                subtitle = "idx.google.com ├── Next.js Web Platform (App Router & Server Actions)",
                badge = "Next.js 15+ & React 19",
                badgeColor = IdxBlue
            )
        }

        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                StatCard(
                    title = "Architecture",
                    value = "RSC + Server Actions",
                    icon = Icons.Default.Storage,
                    accentColor = IdxBlue,
                    modifier = Modifier.weight(1f)
                )
                StatCard(
                    title = "Build Mode",
                    value = "Turbopack",
                    icon = Icons.Default.Speed,
                    accentColor = SuccessEmerald,
                    modifier = Modifier.weight(1f)
                )
            }
        }

        // Route Hierarchy Explorer
        item {
            Text(
                text = "App Router Route Tree",
                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.SemiBold),
                color = MaterialTheme.colorScheme.onBackground
            )
        }

        items(routes) { route ->
            val isSelected = selectedRoute?.path == route.path
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { selectedRoute = route }
                    .testTag("nextjs_route_${route.path}"),
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(
                    containerColor = if (isSelected) IdxBlue.copy(alpha = 0.12f)
                    else MaterialTheme.colorScheme.surfaceVariant
                ),
                border = androidx.compose.foundation.BorderStroke(
                    if (isSelected) 1.5.dp else 1.dp,
                    if (isSelected) IdxBlue else MaterialTheme.colorScheme.outline.copy(alpha = 0.3f)
                )
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(14.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = route.path,
                            style = MaterialTheme.typography.titleSmall.copy(
                                fontFamily = FontFamily.Monospace,
                                fontWeight = FontWeight.Bold
                            ),
                            color = if (isSelected) IdxBlue else MaterialTheme.colorScheme.onSurface
                        )
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = "${route.type} • ${route.renderStrategy}",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }

                    Icon(
                        imageVector = if (isSelected) Icons.Default.CheckCircle else Icons.Default.ChevronRight,
                        contentDescription = null,
                        tint = if (isSelected) IdxBlue else MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.size(20.dp)
                    )
                }
            }
        }

        // Interactive Server Action Runner
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.3f))
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Server Action Mutation Simulator",
                            style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold)
                        )
                        FilledTonalButton(
                            onClick = {
                                actionStatus = "EXECUTED (revalidatePath triggered)"
                            },
                            modifier = Modifier.testTag("run_server_action_button")
                        ) {
                            Icon(Icons.Default.PlayArrow, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Dispatch Action", fontSize = 12.sp)
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "Status: $actionStatus",
                        style = MaterialTheme.typography.bodySmall.copy(fontFamily = FontFamily.Monospace),
                        color = if (actionStatus.startsWith("EXECUTED")) SuccessEmerald else MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }

        // Code Viewer for selected route
        selectedRoute?.let { route ->
            item {
                CodeViewerCard(
                    title = route.path,
                    language = "typescript",
                    code = route.codeSnippet
                )
            }

            item {
                OutlinedButton(
                    onClick = {
                        onSaveSnippet(route.path, "Next.js", route.codeSnippet)
                    },
                    modifier = Modifier.fillMaxWidth().testTag("save_nextjs_snippet_button")
                ) {
                    Icon(Icons.Default.BookmarkBorder, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Save Next.js Route to Snippet Library")
                }
            }
        }
    }
}
