package com.example.ui.idx

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.DbTableSchema
import com.example.ui.components.CodeViewerCard
import com.example.ui.components.SectionHeader
import com.example.ui.components.StatCard
import com.example.ui.theme.FlutterCyan
import com.example.ui.theme.IdxBlue
import com.example.ui.theme.SuccessEmerald

@Composable
fun IdxDatabaseScreen(
    schemas: List<DbTableSchema>,
    onSaveSnippet: (String, String, String) -> Unit,
    modifier: Modifier = Modifier
) {
    var selectedSchema by remember { mutableStateOf(schemas.firstOrNull()) }
    var sqlQuery by remember { mutableStateOf("SELECT * FROM idx_projects WHERE status = 'ACTIVE';") }
    var queryOutput by remember { mutableStateOf("Query ready. Tap Execute Query to run on database instance.") }

    val roomOrmSnippet = """
@Entity(tableName = "projects")
data class ProjectEntity(
    @PrimaryKey val id: String,
    val name: String,
    val template: String,
    val createdAt: Long,
    val status: String
)

@Dao
interface ProjectDao {
    @Query("SELECT * FROM projects WHERE status = 'ACTIVE' ORDER BY createdAt DESC")
    fun getActiveProjects(): Flow<List<ProjectEntity>>
}
    """.trimIndent()

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            SectionHeader(
                title = "Database Engine & ORM",
                subtitle = "idx.google.com ├── Database (Cloud SQL, Firestore & Local Room ORM)",
                badge = "Cloud SQL & SQLite",
                badgeColor = IdxBlue
            )
        }

        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                StatCard(
                    title = "Database Type",
                    value = "Postgres / SQLite",
                    icon = Icons.Default.Storage,
                    accentColor = IdxBlue,
                    modifier = Modifier.weight(1f)
                )
                StatCard(
                    title = "Persistence",
                    value = "Room + Cloud SQL",
                    icon = Icons.Default.Sync,
                    accentColor = SuccessEmerald,
                    modifier = Modifier.weight(1f)
                )
            }
        }

        // Schema Table List
        item {
            Text(
                text = "Database Schemas & Tables",
                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.SemiBold)
            )
        }

        items(schemas) { schema ->
            val isSelected = selectedSchema?.tableName == schema.tableName
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { selectedSchema = schema }
                    .testTag("schema_table_${schema.tableName}"),
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(
                    containerColor = if (isSelected) IdxBlue.copy(alpha = 0.12f)
                    else MaterialTheme.colorScheme.surfaceVariant
                ),
                border = androidx.compose.foundation.BorderStroke(
                    if (isSelected) 1.5.dp else 1.dp,
                    if (isSelected) IdxBlue else MaterialTheme.colorScheme.outline.copy(alpha = 0.3f)
                )
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = schema.tableName,
                            style = MaterialTheme.typography.titleSmall.copy(
                                fontFamily = FontFamily.Monospace,
                                fontWeight = FontWeight.Bold
                            ),
                            color = if (isSelected) IdxBlue else MaterialTheme.colorScheme.onSurface
                        )
                        Text(
                            text = "${schema.columns.size} columns • ${schema.sampleRows.size} records",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }

                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = schema.columns.joinToString(", ") { "${it.name}: ${it.type}" },
                        style = MaterialTheme.typography.bodySmall.copy(fontFamily = FontFamily.Monospace),
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }

        // Interactive SQL Query Lab
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.3f))
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "Interactive Query Runner",
                        style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold)
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    OutlinedTextField(
                        value = sqlQuery,
                        onValueChange = { sqlQuery = it },
                        modifier = Modifier.fillMaxWidth().testTag("sql_query_input"),
                        label = { Text("SQL Query") },
                        textStyle = MaterialTheme.typography.bodySmall.copy(fontFamily = FontFamily.Monospace)
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.End
                    ) {
                        Button(
                            onClick = {
                                queryOutput = "✓ Execution completed: 2 rows returned in 12ms.\nRow 1: [p-101, ShopFast Flutter Web, flutter_wasm, ACTIVE]\nRow 2: [p-103, Gemini Vision Tutor, ai_studio_starter, ACTIVE]"
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = IdxBlue),
                            modifier = Modifier.testTag("execute_query_button")
                        ) {
                            Icon(Icons.Default.PlayArrow, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Execute SQL", fontSize = 12.sp)
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))
                    Surface(
                        color = MaterialTheme.colorScheme.surfaceVariant,
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(
                            text = queryOutput,
                            style = MaterialTheme.typography.bodySmall.copy(fontFamily = FontFamily.Monospace),
                            modifier = Modifier.padding(10.dp)
                        )
                    }
                }
            }
        }

        // Room SQLite Code
        item {
            CodeViewerCard(
                title = "Room Database Kotlin ORM Entity",
                language = "kotlin",
                code = roomOrmSnippet
            )
        }

        item {
            OutlinedButton(
                onClick = { onSaveSnippet("Room ORM Schema", "Database", roomOrmSnippet) },
                modifier = Modifier.fillMaxWidth().testTag("save_database_snippet_button")
            ) {
                Icon(Icons.Default.BookmarkBorder, contentDescription = null, modifier = Modifier.size(18.dp))
                Spacer(modifier = Modifier.width(8.dp))
                Text("Save Database Schema Snippet")
            }
        }
    }
}
