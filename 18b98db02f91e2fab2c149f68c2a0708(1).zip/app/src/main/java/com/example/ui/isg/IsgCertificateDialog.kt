package com.example.ui.isg

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.widget.Toast
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.scaleIn
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.model.IsgCourseModule
import com.example.ui.theme.*
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun IsgCertificateDialog(
    course: IsgCourseModule,
    userName: String = "İSG Profesyoneli / Katılımcı",
    onDismiss: () -> Unit
) {
    val context = LocalContext.current
    var recipientName by remember { mutableStateOf(userName) }
    var isEditingName by remember { mutableStateOf(false) }

    val certIssueDate = remember(course.id) {
        val sdf = SimpleDateFormat("dd MMMM yyyy", Locale("tr", "TR"))
        sdf.format(Date())
    }

    val certSerial = remember(course.id) {
        "ISG-CERT-2026-${course.id.uppercase().take(8)}-AKD"
    }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Card(
            modifier = Modifier
                .fillMaxWidth(0.95f)
                .fillMaxHeight(0.92f)
                .padding(vertical = 12.dp)
                .testTag("dialog_isg_certificate"),
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            elevation = CardDefaults.cardElevation(defaultElevation = 16.dp)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(16.dp)
            ) {
                // Top Modal Action Bar
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Surface(
                            shape = CircleShape,
                            color = WarningYellow.copy(alpha = 0.2f),
                            modifier = Modifier.size(32.dp)
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Icon(
                                    Icons.Default.WorkspacePremium,
                                    contentDescription = null,
                                    tint = WarningYellow,
                                    modifier = Modifier.size(20.dp)
                                )
                            }
                        }
                        Text(
                            text = "Dijital Başarı Belgesi",
                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                        )
                    }

                    IconButton(
                        onClick = onDismiss,
                        modifier = Modifier.testTag("btn_close_certificate_dialog")
                    ) {
                        Icon(Icons.Default.Close, contentDescription = "Kapat")
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                // Scrollable Certificate Container
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxWidth()
                        .verticalScroll(rememberScrollState()),
                    contentAlignment = Alignment.Center
                ) {
                    CertificatePaperCanvas(
                        course = course,
                        recipientName = recipientName,
                        certIssueDate = certIssueDate,
                        certSerial = certSerial,
                        onEditNameClick = { isEditingName = !isEditingName }
                    )
                }

                Spacer(modifier = Modifier.height(12.dp))

                if (isEditingName) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(bottom = 8.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        OutlinedTextField(
                            value = recipientName,
                            onValueChange = { recipientName = it },
                            label = { Text("Sertifika Sahibi Adı") },
                            modifier = Modifier.weight(1f),
                            singleLine = true
                        )
                        Button(
                            onClick = { isEditingName = false }
                        ) {
                            Text("Kaydet")
                        }
                    }
                }

                // Action Buttons (Share / Copy Link / Verify)
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    OutlinedButton(
                        onClick = {
                            val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                            val clip = ClipData.newPlainText(
                                "ISG Sertifika Doğrulama",
                                "https://${course.domain}/verify?certId=$certSerial&holder=${recipientName.replace(" ", "+")}"
                            )
                            clipboard.setPrimaryClip(clip)
                            Toast.makeText(context, "Sertifika doğrulama linki kopyalandı!", Toast.LENGTH_SHORT).show()
                        },
                        modifier = Modifier
                            .weight(1f)
                            .testTag("btn_copy_cert_verification"),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Icon(Icons.Default.ContentCopy, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Linki Kopyala", style = MaterialTheme.typography.labelMedium)
                    }

                    Button(
                        onClick = {
                            Toast.makeText(context, "Başarı Belgeniz dijital profilinize kaydedildi ve doğrulandı! (Akredite ID: $certSerial)", Toast.LENGTH_LONG).show()
                        },
                        modifier = Modifier
                            .weight(1f)
                            .testTag("btn_save_cert_profile"),
                        colors = ButtonDefaults.buttonColors(containerColor = GeminiPurple),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Icon(Icons.Default.DownloadDone, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Belgeyi Onayla", style = MaterialTheme.typography.labelMedium)
                    }
                }
            }
        }
    }
}

@Composable
fun CertificatePaperCanvas(
    course: IsgCourseModule,
    recipientName: String,
    certIssueDate: String,
    certSerial: String,
    onEditNameClick: () -> Unit
) {
    // Certificate Frame with Classical Parchment / Gold Edge Styling
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(4.dp)
            .shadow(10.dp, RoundedCornerShape(16.dp)),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = Color(0xFFFCFDFE)),
        border = BorderStroke(3.dp, Brush.linearGradient(
            colors = listOf(
                Color(0xFFD4AF37), // Gold
                Color(0xFFF9E4B7),
                Color(0xFFAA771C),
                Color(0xFFD4AF37)
            )
        ))
    ) {
        Box(modifier = Modifier.fillMaxWidth()) {
            // Background Decorative Watermark Crest
            Icon(
                Icons.Default.Shield,
                contentDescription = null,
                tint = Color(0xFFD4AF37).copy(alpha = 0.04f),
                modifier = Modifier
                    .size(240.dp)
                    .align(Alignment.Center)
            )

            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(20.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                // Header Crest & Republic of Safety Branding
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(horizontalAlignment = Alignment.Start) {
                        Text(
                            text = "İSG CEP AKADEMİ",
                            style = MaterialTheme.typography.titleMedium.copy(
                                fontWeight = FontWeight.Black,
                                letterSpacing = 2.sp,
                                color = Color(0xFF1E293B)
                            )
                        )
                        Text(
                            text = course.domain,
                            style = MaterialTheme.typography.labelSmall.copy(
                                fontWeight = FontWeight.Bold,
                                color = GeminiGreen,
                                fontSize = 9.sp
                            )
                        )
                    }

                    // Gold Medal Seal Badge
                    Surface(
                        shape = CircleShape,
                        color = Color(0xFFFFFBEB),
                        border = BorderStroke(2.dp, Color(0xFFD4AF37)),
                        modifier = Modifier.size(44.dp)
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Icon(
                                Icons.Default.Verified,
                                contentDescription = null,
                                tint = Color(0xFFD4AF37),
                                modifier = Modifier.size(26.dp)
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))
                HorizontalDivider(
                    thickness = 1.5.dp,
                    color = Color(0xFFD4AF37).copy(alpha = 0.6f),
                    modifier = Modifier.fillMaxWidth(0.85f)
                )
                Spacer(modifier = Modifier.height(14.dp))

                // Certificate Title
                Text(
                    text = "DİJİTAL BAŞARI BELGESİ",
                    style = MaterialTheme.typography.headlineSmall.copy(
                        fontWeight = FontWeight.Black,
                        letterSpacing = 1.5.sp,
                        color = Color(0xFF0F172A)
                    ),
                    textAlign = TextAlign.Center
                )
                Text(
                    text = "CERTIFICATE OF ACHIEVEMENT & COMPLETION",
                    style = MaterialTheme.typography.labelSmall.copy(
                        fontWeight = FontWeight.SemiBold,
                        letterSpacing = 1.sp,
                        color = Color(0xFF64748B),
                        fontSize = 9.sp
                    ),
                    textAlign = TextAlign.Center
                )

                Spacer(modifier = Modifier.height(18.dp))

                Text(
                    text = "Bu belge, İş Sağlığı ve Güvenliği mevzuat ve standartları çerçevesinde",
                    style = MaterialTheme.typography.bodySmall.copy(
                        fontStyle = FontStyle.Italic,
                        color = Color(0xFF475569)
                    ),
                    textAlign = TextAlign.Center
                )

                Spacer(modifier = Modifier.height(8.dp))

                // Recipient Name Display
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.Center,
                    modifier = Modifier
                        .clip(RoundedCornerShape(8.dp))
                        .background(Color(0xFFF1F5F9))
                        .padding(horizontal = 14.dp, vertical = 6.dp)
                ) {
                    Text(
                        text = recipientName,
                        style = MaterialTheme.typography.titleLarge.copy(
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF1E293B)
                        ),
                        textAlign = TextAlign.Center
                    )
                    IconButton(
                        onClick = onEditNameClick,
                        modifier = Modifier.size(24.dp)
                    ) {
                        Icon(
                            Icons.Default.Edit,
                            contentDescription = "İsmi Düzenle",
                            tint = IdxBlue,
                            modifier = Modifier.size(14.dp)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                Text(
                    text = "adlı uzmanın/katılımcının aşağıdaki İSG eğitim modülünü başarıyla ve %100 oranında tamamladığını tevsik eder:",
                    style = MaterialTheme.typography.bodySmall.copy(color = Color(0xFF475569)),
                    textAlign = TextAlign.Center
                )

                Spacer(modifier = Modifier.height(14.dp))

                // Course Highlight Box
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = Color(0xFFF8FAFC),
                    border = BorderStroke(1.dp, Color(0xFFE2E8F0)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier.padding(12.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text(
                            text = course.title,
                            style = MaterialTheme.typography.titleMedium.copy(
                                fontWeight = FontWeight.ExtraBold,
                                color = Color(0xFF0F172A)
                            ),
                            textAlign = TextAlign.Center
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Row(
                            horizontalArrangement = Arrangement.spacedBy(12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Surface(
                                shape = RoundedCornerShape(4.dp),
                                color = GeminiPurple.copy(alpha = 0.15f)
                            ) {
                                Text(
                                    text = course.category,
                                    style = MaterialTheme.typography.labelSmall.copy(
                                        color = GeminiPurple,
                                        fontWeight = FontWeight.Bold
                                    ),
                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                )
                            }
                            Text(
                                text = "⏱ ${course.durationHours} Saat Eğitim",
                                style = MaterialTheme.typography.labelSmall.copy(
                                    fontWeight = FontWeight.SemiBold,
                                    color = Color(0xFF475569)
                                )
                            )
                            Text(
                                text = "🎯 %100 Tamamlandı",
                                style = MaterialTheme.typography.labelSmall.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = SuccessEmerald
                                )
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Signatures & Accreditation Footer
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.Bottom
                ) {
                    // Instructor signature
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        modifier = Modifier.weight(1f)
                    ) {
                        Text(
                            text = course.instructor,
                            style = MaterialTheme.typography.bodySmall.copy(
                                fontWeight = FontWeight.Bold,
                                fontStyle = FontStyle.Italic,
                                color = Color(0xFF1E293B)
                            )
                        )
                        HorizontalDivider(
                            thickness = 1.dp,
                            color = Color(0xFF94A3B8),
                            modifier = Modifier.width(90.dp).padding(vertical = 2.dp)
                        )
                        Text(
                            text = "Baş Eğitmen & Danışman",
                            style = MaterialTheme.typography.labelSmall.copy(
                                fontSize = 8.5.sp,
                                color = Color(0xFF64748B)
                            )
                        )
                    }

                    // Official Seal Stamp
                    Surface(
                        shape = CircleShape,
                        color = Color(0xFFF0FDF4),
                        border = BorderStroke(1.5.dp, SuccessEmerald),
                        modifier = Modifier.size(54.dp)
                    ) {
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.Center,
                            modifier = Modifier.padding(2.dp)
                        ) {
                            Icon(
                                Icons.Default.GppGood,
                                contentDescription = null,
                                tint = SuccessEmerald,
                                modifier = Modifier.size(20.dp)
                            )
                            Text(
                                text = "ONAYLI",
                                style = MaterialTheme.typography.labelSmall.copy(
                                    fontWeight = FontWeight.Black,
                                    fontSize = 7.5.sp,
                                    color = SuccessEmerald
                                )
                            )
                        }
                    }

                    // Academy Director
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        modifier = Modifier.weight(1f)
                    ) {
                        Text(
                            text = "İSG Cep Akademi",
                            style = MaterialTheme.typography.bodySmall.copy(
                                fontWeight = FontWeight.Bold,
                                fontStyle = FontStyle.Italic,
                                color = Color(0xFF1E293B)
                            )
                        )
                        HorizontalDivider(
                            thickness = 1.dp,
                            color = Color(0xFF94A3B8),
                            modifier = Modifier.width(90.dp).padding(vertical = 2.dp)
                        )
                        Text(
                            text = "Eğitim Kurulu Başkanı",
                            style = MaterialTheme.typography.labelSmall.copy(
                                fontSize = 8.5.sp,
                                color = Color(0xFF64748B)
                            )
                        )
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))
                HorizontalDivider(thickness = 0.8.dp, color = Color(0xFFE2E8F0))
                Spacer(modifier = Modifier.height(8.dp))

                // Verification details & Serial
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Düzenleme: $certIssueDate",
                        style = MaterialTheme.typography.labelSmall.copy(fontSize = 8.5.sp, color = Color(0xFF64748B))
                    )
                    Text(
                        text = "Sertifika No: $certSerial",
                        style = MaterialTheme.typography.labelSmall.copy(
                            fontSize = 8.5.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF334155)
                        )
                    )
                }
            }
        }
    }
}
