package com.example.ui.aistudio

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.GeminiModelSpec
import com.example.ui.components.CodeViewerCard
import com.example.ui.components.SectionHeader
import com.example.ui.components.StatCard
import com.example.ui.theme.GeminiPurple
import com.example.ui.theme.IdxBlue
import com.example.ui.theme.SuccessEmerald

@Composable
fun AiModelsScreen(
    models: List<GeminiModelSpec>,
    modifier: Modifier = Modifier
) {
    var selectedModel by remember { mutableStateOf(models.firstOrNull()) }
    var temperature by remember { mutableFloatStateOf(0.7f) }
    var topP by remember { mutableFloatStateOf(0.95f) }
    var topK by remember { mutableFloatStateOf(40f) }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            SectionHeader(
                title = "Gemini Models Hub",
                subtitle = "aistudio.google.com ├── Gemini Models (3.5 Flash, 3.1 Pro & Multimodal)",
                badge = "Google AI Studio",
                badgeColor = GeminiPurple
            )
        }

        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                StatCard(
                    title = "Selected Model",
                    value = selectedModel?.displayName ?: "Gemini 3.5 Flash",
                    icon = Icons.Default.AutoAwesome,
                    accentColor = GeminiPurple,
                    modifier = Modifier.weight(1f)
                )
                StatCard(
                    title = "Avg Latency",
                    value = "${selectedModel?.latencyMs ?: 280} ms",
                    icon = Icons.Default.Speed,
                    accentColor = SuccessEmerald,
                    modifier = Modifier.weight(1f)
                )
            }
        }

        // Model Cards
        item {
            Text(
                text = "Available Gemini Foundation Models",
                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.SemiBold)
            )
        }

        items(models) { model ->
            val isSelected = selectedModel?.modelId == model.modelId
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { selectedModel = model }
                    .testTag("model_card_${model.modelId}"),
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(
                    containerColor = if (isSelected) GeminiPurple.copy(alpha = 0.12f)
                    else MaterialTheme.colorScheme.surfaceVariant
                ),
                border = androidx.compose.foundation.BorderStroke(
                    if (isSelected) 1.5.dp else 1.dp,
                    if (isSelected) GeminiPurple else MaterialTheme.colorScheme.outline.copy(alpha = 0.3f)
                )
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = model.displayName,
                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                            color = if (isSelected) GeminiPurple else MaterialTheme.colorScheme.onSurface
                        )
                        Surface(
                            color = if (isSelected) GeminiPurple.copy(alpha = 0.2f) else MaterialTheme.colorScheme.surface,
                            shape = RoundedCornerShape(6.dp)
                        ) {
                            Text(
                                text = model.badge,
                                color = if (isSelected) GeminiPurple else MaterialTheme.colorScheme.onSurfaceVariant,
                                style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = model.bestFor,
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )

                    Spacer(modifier = Modifier.height(10.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = "Context: ${model.contextWindow}",
                            style = MaterialTheme.typography.labelSmall.copy(fontFamily = FontFamily.Monospace),
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Text(
                            text = "In: ${model.inputCostPerMillion}/M • Out: ${model.outputCostPerMillion}/M",
                            style = MaterialTheme.typography.labelSmall.copy(fontFamily = FontFamily.Monospace),
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }

                    Spacer(modifier = Modifier.height(8.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        model.capabilities.forEach { cap ->
                            Surface(
                                shape = RoundedCornerShape(4.dp),
                                color = MaterialTheme.colorScheme.surface
                            ) {
                                Text(
                                    text = cap,
                                    fontSize = 10.sp,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                )
                            }
                        }
                    }
                }
            }
        }

        // Hyperparameter Playground
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.3f))
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "Model Generation Parameters",
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                    )
                    Spacer(modifier = Modifier.height(12.dp))

                    Text("Temperature: ${String.format("%.2f", temperature)} (Creativity vs Determinism)")
                    Slider(
                        value = temperature,
                        onValueChange = { temperature = it },
                        valueRange = 0f..2f,
                        modifier = Modifier.testTag("temperature_slider")
                    )

                    Spacer(modifier = Modifier.height(8.dp))
                    Text("Top-P (Nucleus Sampling): ${String.format("%.2f", topP)}")
                    Slider(
                        value = topP,
                        onValueChange = { topP = it },
                        valueRange = 0f..1f,
                        modifier = Modifier.testTag("topp_slider")
                    )

                    Spacer(modifier = Modifier.height(8.dp))
                    Text("Top-K: ${topK.toInt()}")
                    Slider(
                        value = topK,
                        onValueChange = { topK = it },
                        valueRange = 1f..100f,
                        modifier = Modifier.testTag("topk_slider")
                    )
                }
            }
        }
    }
}
