package com.example.ui

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Assignment
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.model.MainTab
import com.example.ui.aistudio.*
import com.example.ui.idx.*
import com.example.ui.isg.*
import com.example.ui.pc.*
import com.example.ui.theme.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainScreen(
    viewModel: MainViewModel,
    modifier: Modifier = Modifier
) {
    val currentTab by viewModel.currentTab.collectAsStateWithLifecycle()
    val savedPrompts by viewModel.savedPrompts.collectAsStateWithLifecycle()
    val chatHistory by viewModel.chatHistory.collectAsStateWithLifecycle()
    val testHistory by viewModel.testHistory.collectAsStateWithLifecycle()
    val isThinking by viewModel.isThinking.collectAsStateWithLifecycle()
    val isgCourses by viewModel.isgCourses.collectAsStateWithLifecycle()
    val isgHapBilgileri by viewModel.isgHapBilgileri.collectAsStateWithLifecycle()
    val isgPlugins by viewModel.isgPluginsList.collectAsStateWithLifecycle()
    val isgRiskAssessments by viewModel.riskAssessments.collectAsStateWithLifecycle()
    val isgQuizHistory by viewModel.isgQuizHistory.collectAsStateWithLifecycle()
    val isgAiQuestions by viewModel.isgAiQuestions.collectAsStateWithLifecycle()
    val voiceProfiles by viewModel.voiceProfiles.collectAsStateWithLifecycle()
    val videoPipelineJobs by viewModel.videoPipelineJobs.collectAsStateWithLifecycle()
    val activeVideoJobStatus by viewModel.activeVideoJobStatus.collectAsStateWithLifecycle()
    val activeJobProgressPercent by viewModel.activeJobProgressPercent.collectAsStateWithLifecycle()
    val activeJobProgressMessage by viewModel.activeJobProgressMessage.collectAsStateWithLifecycle()

    val personalPcWorkstation by viewModel.personalPcWorkstation.collectAsStateWithLifecycle()
    val workspaceFiles by viewModel.workspaceFiles.collectAsStateWithLifecycle()
    val workspaceNotes by viewModel.workspaceNotes.collectAsStateWithLifecycle()
    val terminalLogs by viewModel.terminalEntries.collectAsStateWithLifecycle()

    var activeGroup by remember { mutableStateOf("PRIMARY IDX") }

    val idxTabs = listOf(
        MainTab.FLUTTER,
        MainTab.NEXTJS,
        MainTab.FIREBASE,
        MainTab.DATABASE,
        MainTab.TESTS,
        MainTab.DEPLOYMENT
    )

    val aiStudioTabs = listOf(
        MainTab.GEMINI_MODELS,
        MainTab.PROMPT_STUDIO,
        MainTab.QA_GENERATOR,
        MainTab.TUTOR_CHAT,
        MainTab.INTEGRATION_SDK
    )

    val isgTabs = listOf(
        MainTab.ISG_HAP_BILGILER,
        MainTab.ISG_COURSES,
        MainTab.ISG_PLUGINS,
        MainTab.ISG_AI_QA,
        MainTab.ISG_EXAMS,
        MainTab.ISG_RISK_CALC,
        MainTab.ISG_API_SUITE,
        MainTab.ISG_VOICE_STUDIO
    )

    val pcTabs = listOf(
        MainTab.PC_DESKTOP,
        MainTab.PC_EXPLORER,
        MainTab.PC_TERMINAL,
        MainTab.PC_NOTES,
        MainTab.PC_SETTINGS
    )

    val currentTabs = when (activeGroup) {
        "PRIMARY IDX" -> idxTabs
        "AI STUDIO" -> aiStudioTabs
        "İSG AKADEMİ" -> isgTabs
        else -> pcTabs
    }

    val activeGroupColor = when (activeGroup) {
        "PRIMARY IDX" -> IdxBlue
        "AI STUDIO" -> GeminiPurple
        "İSG AKADEMİ" -> Color(0xFFE65100)
        else -> Color(0xFF58A6FF)
    }

    Scaffold(
        modifier = modifier.fillMaxSize(),
        topBar = {
            TopAppBar(
                title = {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(32.dp)
                                .clip(RoundedCornerShape(8.dp))
                                .background(activeGroupColor),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = when (activeGroup) {
                                    "PRIMARY IDX" -> Icons.Default.Code
                                    "AI STUDIO" -> Icons.Default.AutoAwesome
                                    "İSG AKADEMİ" -> Icons.Default.HealthAndSafety
                                    else -> Icons.Default.LaptopChromebook
                                },
                                contentDescription = null,
                                tint = Color.White,
                                modifier = Modifier.size(18.dp)
                            )
                        }
                        Column {
                            Text(
                                text = when (activeGroup) {
                                    "PRIMARY IDX" -> "IDX Studio Hub"
                                    "AI STUDIO" -> "AI Studio Engine"
                                    "İSG AKADEMİ" -> "İSG Cep Akademi Hub"
                                    else -> "Kişisel Bilgisayarım (DevPC)"
                                },
                                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                            )
                            Text(
                                text = when (activeGroup) {
                                    "PRIMARY IDX" -> "idx.google.com • Cloud Dev Workspace"
                                    "AI STUDIO" -> "aistudio.google.com • Gemini AI Engine"
                                    "İSG AKADEMİ" -> "isgcepakademi.com, isgcepakademi.com.tr & isgcepakademi.xyz"
                                    else -> "${personalPcWorkstation.hostname} • ${personalPcWorkstation.osName}"
                                },
                                style = MaterialTheme.typography.labelSmall.copy(fontFamily = FontFamily.Monospace),
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                },
                actions = {
                    if (activeGroup != "KİŞİSEL PC") {
                        FilledTonalButton(
                            onClick = {
                                activeGroup = "KİŞİSEL PC"
                                viewModel.selectTab(MainTab.PC_DESKTOP)
                            },
                            shape = RoundedCornerShape(8.dp),
                            contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp),
                            modifier = Modifier.padding(end = 8.dp)
                        ) {
                            Icon(Icons.Default.Computer, contentDescription = null, modifier = Modifier.size(14.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Kişisel PC", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surface
                )
            )
        },
        bottomBar = {
            NavigationBar(
                modifier = Modifier
                    .fillMaxWidth()
                    .windowInsetsPadding(WindowInsets.navigationBars),
                containerColor = MaterialTheme.colorScheme.surface
            ) {
                NavigationBarItem(
                    selected = activeGroup == "PRIMARY IDX",
                    onClick = {
                        activeGroup = "PRIMARY IDX"
                        if (currentTab !in idxTabs) {
                            viewModel.selectTab(MainTab.FLUTTER)
                        }
                    },
                    icon = { Icon(Icons.Default.DeveloperMode, contentDescription = "Primary IDX") },
                    label = { Text("Primary Dev", fontSize = 10.sp) },
                    modifier = Modifier.testTag("nav_primary_idx")
                )
                NavigationBarItem(
                    selected = activeGroup == "AI STUDIO",
                    onClick = {
                        activeGroup = "AI STUDIO"
                        if (currentTab !in aiStudioTabs) {
                            viewModel.selectTab(MainTab.GEMINI_MODELS)
                        }
                    },
                    icon = { Icon(Icons.Default.AutoAwesome, contentDescription = "AI Studio") },
                    label = { Text("AI Studio", fontSize = 10.sp) },
                    modifier = Modifier.testTag("nav_ai_studio")
                )
                NavigationBarItem(
                    selected = activeGroup == "İSG AKADEMİ",
                    onClick = {
                        activeGroup = "İSG AKADEMİ"
                        if (currentTab !in isgTabs) {
                            viewModel.selectTab(MainTab.ISG_PLUGINS)
                        }
                    },
                    icon = { Icon(Icons.Default.HealthAndSafety, contentDescription = "İSG Akademi") },
                    label = { Text("İSG Akademi", fontSize = 10.sp) },
                    modifier = Modifier.testTag("nav_isg_akademi")
                )
                NavigationBarItem(
                    selected = activeGroup == "KİŞİSEL PC",
                    onClick = {
                        activeGroup = "KİŞİSEL PC"
                        if (currentTab !in pcTabs) {
                            viewModel.selectTab(MainTab.PC_DESKTOP)
                        }
                    },
                    icon = { Icon(Icons.Default.LaptopChromebook, contentDescription = "Kişisel PC") },
                    label = { Text("Kişisel PC", fontSize = 10.sp) },
                    modifier = Modifier.testTag("nav_personal_pc")
                )
            }
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            // Horizontal Scrollable Tab Bar
            val scrollState = rememberScrollState()
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(MaterialTheme.colorScheme.surface)
                    .horizontalScroll(scrollState)
                    .padding(horizontal = 16.dp, vertical = 6.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                currentTabs.forEach { tab ->
                    val isSelected = currentTab == tab
                    FilterChip(
                        selected = isSelected,
                        onClick = { viewModel.selectTab(tab) },
                        leadingIcon = {
                            Icon(
                                imageVector = when (tab) {
                                    MainTab.FLUTTER -> Icons.Default.PhoneAndroid
                                    MainTab.NEXTJS -> Icons.Default.Web
                                    MainTab.FIREBASE -> Icons.Default.LocalFireDepartment
                                    MainTab.DATABASE -> Icons.Default.Storage
                                    MainTab.TESTS -> Icons.Default.CheckCircle
                                    MainTab.DEPLOYMENT -> Icons.Default.CloudUpload
                                    MainTab.GEMINI_MODELS -> Icons.Default.Memory
                                    MainTab.PROMPT_STUDIO -> Icons.Default.EditNote
                                    MainTab.QA_GENERATOR -> Icons.Default.Quiz
                                    MainTab.TUTOR_CHAT -> Icons.Default.School
                                    MainTab.INTEGRATION_SDK -> Icons.Default.Code
                                    MainTab.ISG_HAP_BILGILER -> Icons.Default.Lightbulb
                                    MainTab.ISG_COURSES -> Icons.Default.MenuBook
                                    MainTab.ISG_PLUGINS -> Icons.Default.Extension
                                    MainTab.ISG_AI_QA -> Icons.Default.AutoAwesome
                                    MainTab.ISG_EXAMS -> Icons.AutoMirrored.Filled.Assignment
                                    MainTab.ISG_RISK_CALC -> Icons.Default.Shield
                                    MainTab.ISG_API_SUITE -> Icons.Default.Api
                                    MainTab.ISG_VOICE_STUDIO -> Icons.Default.RecordVoiceOver
                                    MainTab.PC_DESKTOP -> Icons.Default.Computer
                                    MainTab.PC_EXPLORER -> Icons.Default.FolderOpen
                                    MainTab.PC_TERMINAL -> Icons.Default.Terminal
                                    MainTab.PC_NOTES -> Icons.Default.EditNote
                                    MainTab.PC_SETTINGS -> Icons.Default.Tune
                                },
                                contentDescription = null,
                                modifier = Modifier.size(16.dp),
                                tint = if (isSelected) activeGroupColor else MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        },
                        label = {
                            Text(
                                text = tab.title,
                                style = MaterialTheme.typography.labelMedium.copy(
                                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                                )
                            )
                        },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = activeGroupColor.copy(alpha = 0.15f),
                            selectedLabelColor = activeGroupColor
                        ),
                        modifier = Modifier.testTag("subtab_${tab.name.lowercase()}")
                    )
                }
            }

            HorizontalDivider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.2f))

            // Main Content Area
            Box(modifier = Modifier.fillMaxSize().weight(1f)) {
                AnimatedContent(
                    targetState = currentTab,
                    transitionSpec = { fadeIn() togetherWith fadeOut() },
                    label = "TabContentTransition"
                ) { targetTab ->
                    when (targetTab) {
                        MainTab.FLUTTER -> IdxFlutterScreen(
                            presets = viewModel.flutterPresets,
                            onSaveSnippet = { title, stack, code -> viewModel.saveSnippet(title, stack, code) }
                        )
                        MainTab.NEXTJS -> IdxNextJsScreen(
                            routes = viewModel.nextJsRoutes,
                            onSaveSnippet = { title, stack, code -> viewModel.saveSnippet(title, stack, code) }
                        )
                        MainTab.FIREBASE -> IdxFirebaseScreen(
                            ruleTests = viewModel.firebaseRuleTests,
                            onSaveSnippet = { title, stack, code -> viewModel.saveSnippet(title, stack, code) }
                        )
                        MainTab.DATABASE -> IdxDatabaseScreen(
                            schemas = viewModel.dbSchemas,
                            onSaveSnippet = { title, stack, code -> viewModel.saveSnippet(title, stack, code) }
                        )
                        MainTab.TESTS -> IdxTestsScreen(
                            initialTests = viewModel.initialTestCases,
                            testHistory = testHistory,
                            onRecordTestRun = { run -> viewModel.recordTestRun(run) }
                        )
                        MainTab.DEPLOYMENT -> IdxDeploymentScreen(
                            targets = viewModel.deploymentTargets
                        )
                        MainTab.GEMINI_MODELS -> AiModelsScreen(
                            models = viewModel.geminiModels
                        )
                        MainTab.PROMPT_STUDIO -> AiPromptStudioScreen(
                            templates = viewModel.promptTemplates,
                            savedPrompts = savedPrompts,
                            onSavePrompt = { p -> viewModel.savePrompt(p) },
                            onDeletePrompt = { p -> viewModel.deletePrompt(p) },
                            onGenerate = { prompt, sys, model, isJson ->
                                viewModel.generatePromptResult(prompt, sys, model, isJson)
                            }
                        )
                        MainTab.QA_GENERATOR -> AiQAGeneratorScreen(
                            questions = viewModel.quizQuestions,
                            onGenerateCustomQA = { stack, diff -> viewModel.generateCustomQA(stack, diff) }
                        )
                        MainTab.TUTOR_CHAT -> AiTutorChatScreen(
                            messages = chatHistory,
                            onSendMessage = { text -> viewModel.sendChatMessage(text) },
                            onClearHistory = { viewModel.clearChatHistory() },
                            isThinking = isThinking
                        )
                        MainTab.INTEGRATION_SDK -> AiSdkWorkbenchScreen(
                            sdkSnippets = viewModel.sdkSnippets,
                            onSaveSnippet = { title, stack, code -> viewModel.saveSnippet(title, stack, code) }
                        )
                        MainTab.ISG_HAP_BILGILER -> IsgHapBilgiScreen(
                            hapBilgiler = isgHapBilgileri,
                            onToggleFavorite = { id -> viewModel.toggleHapBilgiFavorite(id) }
                        )
                        MainTab.ISG_COURSES -> IsgCourseListScreen(
                            courses = isgCourses,
                            onToggleCompletion = { courseId -> viewModel.toggleCourseCompletion(courseId) },
                            onToggleSyllabusItem = { courseId, item -> viewModel.toggleSyllabusItemCompletion(courseId, item) },
                            onUpdateProgressPercentage = { courseId, pct -> viewModel.updateCourseProgressPercentage(courseId, pct) },
                            onResetAllProgress = { viewModel.resetAllCoursesProgress() },
                            voiceProfiles = voiceProfiles,
                            onSynthesizeNarration = { text, profile, key ->
                                viewModel.synthesizeModuleScript(text, profile, key)
                            },
                            onSendToVideoStudio = { title, script, voice ->
                                activeGroup = "İSG AKADEMİ"
                                viewModel.selectTab(MainTab.ISG_VOICE_STUDIO)
                                viewModel.startVideoPipeline(
                                    title = title,
                                    script = script,
                                    voiceProfile = voice,
                                    avatarStyle = "3D İSG Baş Denetçisi",
                                    format = "9:16 Dikey (Shorts/Reels/TikTok)",
                                    domain = "isgcepakademi.com.tr"
                                )
                            }
                        )
                        MainTab.ISG_PLUGINS -> IsgPluginsScreen(
                            plugins = isgPlugins,
                            onToggleInstall = { pluginId -> viewModel.togglePluginInstall(pluginId) }
                        )
                        MainTab.ISG_AI_QA -> IsgAiQaScreen(
                            questions = isgAiQuestions,
                            quizHistory = isgQuizHistory,
                            onGenerateAiQuestion = { cat, diff, dom ->
                                viewModel.generateIsgAiQuestion(cat, diff, dom)
                            },
                            onSaveQuizResult = { cat, total, correct, diff, dom, notes ->
                                viewModel.saveIsgQuizResult(cat, total, correct, diff, dom, notes)
                            },
                            onDeleteQuizHistory = { item -> viewModel.deleteIsgQuizHistory(item) },
                            onClearAllHistory = { viewModel.clearAllIsgQuizHistory() }
                        )
                        MainTab.ISG_EXAMS -> IsgExamSimulatorScreen(
                            questions = viewModel.isgExamQuestions
                        )
                        MainTab.ISG_RISK_CALC -> IsgRiskCalculatorScreen(
                            assessments = isgRiskAssessments,
                            onAddRisk = { act, hazard, desc, prob, sev, freq, method ->
                                viewModel.addRiskAssessment(act, hazard, desc, prob, sev, freq, method)
                            },
                            onAnalyzeWithGemini = { incident ->
                                viewModel.analyzeIsgIncidentWithGemini(incident)
                            }
                        )
                        MainTab.ISG_API_SUITE -> IsgApiSuiteScreen(
                            endpoints = viewModel.isgApiEndpoints
                        )
                        MainTab.ISG_VOICE_STUDIO -> IsgVoiceAndVideoStudioScreen(
                            voiceProfiles = voiceProfiles,
                            pipelineJobs = videoPipelineJobs,
                            activeJobStatus = activeVideoJobStatus,
                            activeProgressPercent = activeJobProgressPercent,
                            activeProgressMessage = activeJobProgressMessage,
                            onStartPipeline = { title, script, voice, avatar, format, domain ->
                                viewModel.startVideoPipeline(title, script, voice, avatar, format, domain)
                            },
                            onCreateVoiceProfile = { name, prov, vId, gender, desc, stab, sim ->
                                viewModel.createCustomVoiceProfile(name, prov, vId, gender, desc, stab, sim)
                            },
                            onDeleteJob = { jobId -> viewModel.deleteVideoJob(jobId) }
                        )
                        MainTab.PC_DESKTOP,
                        MainTab.PC_EXPLORER,
                        MainTab.PC_TERMINAL,
                        MainTab.PC_NOTES,
                        MainTab.PC_SETTINGS -> PersonalWorkstationScreen(
                            workstation = personalPcWorkstation,
                            files = workspaceFiles,
                            notes = workspaceNotes,
                            terminalLogs = terminalLogs,
                            onUpdateWorkstation = { config -> viewModel.updateWorkstationConfig(config) },
                            onSaveFile = { file -> viewModel.saveWorkspaceFile(file) },
                            onDeleteFile = { id -> viewModel.deleteWorkspaceFile(id) },
                            onSaveNote = { note -> viewModel.saveWorkspaceNote(note) },
                            onDeleteNote = { id -> viewModel.deleteWorkspaceNote(id) },
                            onTogglePinNote = { id -> viewModel.togglePinNote(id) },
                            onExecuteCommand = { cmd -> viewModel.executeTerminalCommand(cmd) },
                            onClearTerminal = { viewModel.clearTerminalLogs() },
                            onSetDpiScale = { scale -> viewModel.setEmulatorDpi(scale) },
                            onSetWindowMode = { mode -> viewModel.setWindowMode(mode) }
                        )
                    }
                }
            }
        }
    }
}
