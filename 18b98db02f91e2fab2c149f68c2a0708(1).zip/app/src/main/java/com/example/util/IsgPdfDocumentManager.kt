package com.example.util

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Rect
import android.graphics.RectF
import android.graphics.pdf.PdfDocument
import android.graphics.pdf.PdfRenderer
import android.os.ParcelFileDescriptor
import com.example.model.IsgCourseModule
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream
import java.util.concurrent.ConcurrentHashMap

/**
 * Handles Native Android PDF generation, caching, and Bitmap rendering via [PdfRenderer].
 */
object IsgPdfDocumentManager {

    private val pageBitmapCache = ConcurrentHashMap<String, Bitmap>()

    /**
     * Ensures a local PDF file exists for the given course module and returns its File.
     */
    suspend fun getOrGeneratePdfFile(context: Context, course: IsgCourseModule): File = withContext(Dispatchers.IO) {
        val pdfDir = File(context.cacheDir, "isg_course_pdfs").apply { mkdirs() }
        val fileName = "${course.id}_v2.pdf"
        val targetFile = File(pdfDir, fileName)

        if (!targetFile.exists() || targetFile.length() < 1000) {
            generateCoursePdf(targetFile, course)
        }
        targetFile
    }

    /**
     * Renders a specific page of the course PDF into a high-resolution Bitmap using native [PdfRenderer].
     */
    suspend fun renderPdfPage(
        context: Context,
        course: IsgCourseModule,
        pageIndex: Int,
        targetWidth: Int = 1080,
        targetHeight: Int = 1528
    ): Bitmap? = withContext(Dispatchers.IO) {
        val cacheKey = "${course.id}_p${pageIndex}_w${targetWidth}"
        pageBitmapCache[cacheKey]?.let { return@withContext it }

        try {
            val file = getOrGeneratePdfFile(context, course)
            val fileDescriptor = ParcelFileDescriptor.open(file, ParcelFileDescriptor.MODE_READ_ONLY)
            val pdfRenderer = PdfRenderer(fileDescriptor)

            if (pageIndex < 0 || pageIndex >= pdfRenderer.pageCount) {
                pdfRenderer.close()
                fileDescriptor.close()
                return@withContext null
            }

            val page = pdfRenderer.openPage(pageIndex)
            val bitmap = Bitmap.createBitmap(targetWidth, targetHeight, Bitmap.Config.ARGB_8888)
            page.render(bitmap, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)

            page.close()
            pdfRenderer.close()
            fileDescriptor.close()

            pageBitmapCache[cacheKey] = bitmap
            bitmap
        } catch (e: Exception) {
            e.printStackTrace()
            null
        }
    }

    /**
     * Returns the total page count of the generated/cached PDF.
     */
    suspend fun getPageCount(context: Context, course: IsgCourseModule): Int = withContext(Dispatchers.IO) {
        try {
            val file = getOrGeneratePdfFile(context, course)
            val fileDescriptor = ParcelFileDescriptor.open(file, ParcelFileDescriptor.MODE_READ_ONLY)
            val pdfRenderer = PdfRenderer(fileDescriptor)
            val count = pdfRenderer.pageCount
            pdfRenderer.close()
            fileDescriptor.close()
            count
        } catch (e: Exception) {
            course.documentPagesCount.coerceAtLeast(1)
        }
    }

    /**
     * Generates a multi-page PDF document with typography, official branding, diagrams, and tables.
     */
    private fun generateCoursePdf(outputFile: File, course: IsgCourseModule) {
        val document = PdfDocument()
        val totalPages = course.documentPagesCount.coerceAtLeast(6)
        val pageWidth = 595 // A4 standard width (pt)
        val pageHeight = 842 // A4 standard height (pt)

        val primaryColor = when {
            course.domain.contains("tr") -> Color.parseColor("#1565C0") // Blue
            course.domain.contains("xyz") -> Color.parseColor("#6A1B9A") // Purple
            else -> Color.parseColor("#2E7D32") // Green
        }
        val secondaryColor = Color.parseColor("#37474F")
        val accentGold = Color.parseColor("#D4AF37")
        val textDark = Color.parseColor("#212121")
        val textMuted = Color.parseColor("#546E7A")
        val bgLight = Color.parseColor("#F8F9FA")
        val cardBorder = Color.parseColor("#CFD8DC")

        val titlePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = primaryColor
            textSize = 15f
            isFakeBoldText = true
        }

        val headerPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.WHITE
            textSize = 9f
            isFakeBoldText = true
        }

        val bodyPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = textDark
            textSize = 10f
        }

        val boldPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = textDark
            textSize = 10.5f
            isFakeBoldText = true
        }

        val smallPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = textMuted
            textSize = 8.5f
        }

        val rectPaint = Paint(Paint.ANTI_ALIAS_FLAG)

        for (pageIndex in 0 until totalPages) {
            val pageInfo = PdfDocument.PageInfo.Builder(pageWidth, pageHeight, pageIndex + 1).create()
            val page = document.startPage(pageInfo)
            val canvas = page.canvas

            // 1. Background Fill
            canvas.drawColor(Color.WHITE)

            // 2. Top Header Bar
            rectPaint.color = primaryColor
            canvas.drawRect(0f, 0f, pageWidth.toFloat(), 55f, rectPaint)

            // Gold accent stripe
            rectPaint.color = accentGold
            canvas.drawRect(0f, 55f, pageWidth.toFloat(), 58f, rectPaint)

            // Header Texts
            headerPaint.textSize = 8.5f
            canvas.drawText("T.C. ÇALIŞMA VE SOSYAL GÜVENLİK BAKANLIĞI AKREDİTE İSG EĞİTİM MERKEZİ", 24f, 22f, headerPaint)
            headerPaint.textSize = 11f
            canvas.drawText("İSG CEP AKADEMİ DERS DOKÜMANI VE MEVZUAT KILAVUZU", 24f, 42f, headerPaint)

            // Domain Badge in Header
            rectPaint.color = Color.WHITE
            val badgeRect = RectF(pageWidth - 145f, 15f, pageWidth - 20f, 42f)
            canvas.drawRoundRect(badgeRect, 6f, 6f, rectPaint)
            val domainTextPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = primaryColor
                textSize = 9f
                isFakeBoldText = true
            }
            canvas.drawText(course.domain, pageWidth - 135f, 32f, domainTextPaint)

            // 3. Watermark in Center
            val watermarkPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = Color.parseColor("#08000000") // Very faint
                textSize = 42f
                isFakeBoldText = true
            }
            canvas.save()
            canvas.rotate(-35f, pageWidth / 2f, pageHeight / 2f)
            canvas.drawText(course.domain.uppercase(), pageWidth / 2f - 180f, pageHeight / 2f, watermarkPaint)
            canvas.restore()

            // 4. Page Specific Content
            var currentY = 85f

            when (pageIndex) {
                0 -> {
                    // COVER / SUMMARY PAGE
                    rectPaint.color = bgLight
                    canvas.drawRoundRect(RectF(24f, currentY, pageWidth - 24f, currentY + 120f), 8f, 8f, rectPaint)
                    rectPaint.style = Paint.Style.STROKE
                    rectPaint.strokeWidth = 1f
                    rectPaint.color = cardBorder
                    canvas.drawRoundRect(RectF(24f, currentY, pageWidth - 24f, currentY + 120f), 8f, 8f, rectPaint)
                    rectPaint.style = Paint.Style.FILL

                    titlePaint.textSize = 14f
                    val courseTitleLines = wrapText(course.title, 55)
                    var titleY = currentY + 28f
                    courseTitleLines.forEach { line ->
                        canvas.drawText(line, 40f, titleY, titlePaint)
                        titleY += 18f
                    }

                    canvas.drawText("Kategori: ${course.category}  |  Düzey: ${course.level}  |  Süre: ${course.durationHours} Saat", 40f, currentY + 80f, smallPaint)
                    canvas.drawText("Eğitmen: ${course.instructor}  |  Kayıtlı Uzman: ${course.enrolledCount}+", 40f, currentY + 98f, smallPaint)

                    currentY += 140f

                    // Document Info Box
                    rectPaint.color = Color.parseColor("#E3F2FD")
                    canvas.drawRoundRect(RectF(24f, currentY, pageWidth - 24f, currentY + 70f), 6f, 6f, rectPaint)
                    val infoPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                        color = Color.parseColor("#0D47A1")
                        textSize = 9.5f
                        isFakeBoldText = true
                    }
                    canvas.drawText("📋 RESMİ DOKÜMAN BİLGİLERİ & DOĞRULAMA KODU", 36f, currentY + 22f, infoPaint)
                    bodyPaint.textSize = 9f
                    canvas.drawText("Doküman Kodu: DOC-ISG-${course.id.uppercase().take(12)}  |  Baskı: 2026/GÜNCEL  |  Boyut: ${course.documentFileSize}", 36f, currentY + 40f, bodyPaint)
                    canvas.drawText("Erişim URL: ${course.pdfDocumentUrl}", 36f, currentY + 56f, smallPaint)

                    currentY += 88f

                    // Course Description & Objectives
                    canvas.drawText("1. EĞİTİM MODÜLÜ AMACI VE KAPSAMI", 24f, currentY, boldPaint)
                    currentY += 18f
                    val descLines = wrapText(course.description, 75)
                    descLines.forEach { line ->
                        canvas.drawText(line, 28f, currentY, bodyPaint)
                        currentY += 15f
                    }

                    currentY += 15f
                    canvas.drawText("2. KAZANILACAK TEMEL YETKİNLİKLER (ÖĞRENME HEDEFLERİ)", 24f, currentY, boldPaint)
                    currentY += 18f
                    course.learningObjectives.forEachIndexed { i, obj ->
                        val objLines = wrapText("• ${obj}", 72)
                        objLines.forEach { l ->
                            canvas.drawText(l, 32f, currentY, bodyPaint)
                            currentY += 14f
                        }
                    }

                    currentY += 15f
                    canvas.drawText("3. MÜFREDAT VE KONU BAŞLIKLARI DİZİNİ", 24f, currentY, boldPaint)
                    currentY += 18f
                    course.syllabus.forEachIndexed { i, item ->
                        rectPaint.color = if (i % 2 == 0) bgLight else Color.WHITE
                        canvas.drawRect(24f, currentY - 11f, pageWidth - 24f, currentY + 7f, rectPaint)
                        canvas.drawText(item, 32f, currentY, bodyPaint)
                        canvas.drawText("Sayfa ${i + 2}", pageWidth - 80f, currentY, smallPaint)
                        currentY += 18f
                    }
                }

                1 -> {
                    // LEGAL FRAMEWORK & LEGISLATION ARTICLES
                    canvas.drawText("BÖLÜM 1: YASAL ÇERÇEVE & 6331 SAYILI KANUN MADDELERİ", 24f, currentY, titlePaint)
                    currentY += 25f

                    drawCalloutBox(canvas, 24f, currentY, pageWidth - 48f, 65f, "⚖️ İŞVEREN VE ÇALIŞANIN YASAL SORUMLULUKLARI", "6331 sayılı Kanun Madde 4 gereğince işveren, çalışanların işle ilgili sağlık ve güvenliğini sağlamakla yükümlü olup bu çerçevede mesleki risklerin önlenmesi, eğitim ve bilgi verilmesi dahil her türlü tedbiri almak zorundadır.", primaryColor)
                    currentY += 80f

                    canvas.drawText("1.1. Risklerden Korunma İlkeleri (Madde 5 Hiyerarşisi)", 24f, currentY, boldPaint)
                    currentY += 18f
                    val principles = listOf(
                        "1. Risklerden kaçınmak ve tehlikeyi kaynağında önlemek",
                        "2. Kaçınılması mümkün olmayan riskleri analiz ederek önceliklendirmek",
                        "3. Tehlikeli olanı, tehlikesiz veya daha az tehlikeli olanla değiştirmek (İkame)",
                        "4. Toplu korunma önlemlerine, kişisel korunma önlemlerine göre kesin öncelik vermek",
                        "5. Çalışanlara uygun talimat ve periyodik eğitimleri eksiksiz vermek"
                    )
                    principles.forEach { p ->
                        canvas.drawText(p, 32f, currentY, bodyPaint)
                        currentY += 16f
                    }

                    currentY += 20f
                    canvas.drawText("1.2. İdari Para Cezaları & İtiraz Usulleri (Tablo 1.1)", 24f, currentY, boldPaint)
                    currentY += 18f

                    drawTable(
                        canvas = canvas,
                        startX = 24f,
                        startY = currentY,
                        width = pageWidth - 48f,
                        headers = listOf("Yasal İhlal Türü", "Az Tehlikeli", "Tehlikeli", "Çok Tehlikeli"),
                        rows = listOf(
                            listOf("Risk Değerlendirmesi Yapmamak", "34.500 ₺", "51.750 ₺", "69.000 ₺"),
                            listOf("İGU / İH Görevlendirmemek (Aylık)", "28.900 ₺", "43.350 ₺", "57.800 ₺"),
                            listOf("İşe Giriş / Periyodik Muayene Eksikliği", "4.800 ₺/kişi", "7.200 ₺/kişi", "9.600 ₺/kişi"),
                            listOf("Acil Durum Planı Hazırlamamak", "17.200 ₺", "25.800 ₺", "34.400 ₺")
                        ),
                        primaryColor = primaryColor
                    )
                }

                2 -> {
                    // FIELD AUDIT & PRACTICAL CHECKLIST
                    canvas.drawText("BÖLÜM 2: SAHA DENETİM KONTROL LİSTESİ VE UYGULAMA", 24f, currentY, titlePaint)
                    currentY += 25f

                    drawCalloutBox(canvas, 24f, currentY, pageWidth - 48f, 65f, "🔍 SAHA BAŞ DENETÇİSİ UYARI REHBERİ", "Saha kontrollerinde tespit edilen her uygunsuzluk derhal Onaylı Deftere (Tespit ve Öneri Defteri) yazılmalı, işverene tebliğ edilmeli ve hayati tehlike içeren durumlar Bakanlığa bildirilmelidir.", accentGold)
                    currentY += 80f

                    canvas.drawText("2.1. Denetim Maddeleri ve Kontrol Kriterleri", 24f, currentY, boldPaint)
                    currentY += 18f

                    drawTable(
                        canvas = canvas,
                        startX = 24f,
                        startY = currentY,
                        width = pageWidth - 48f,
                        headers = listOf("No", "Kontrol Maddesi", "Referans Standart", "Durum"),
                        rows = listOf(
                            listOf("1", "Paraşüt Tipi Emniyet Kemeri & Yaşam Hattı", "TS EN 361 / EN 353", "Uygun [✓]"),
                            listOf("2", "Ön Yapımlı Flanşlı İskele Topraklama & Etiket", "TS EN 12810/12811", "Uygun [✓]"),
                            listOf("3", "Basınçlı Kap ve Kompresör 1.5x Hidrostatik Test", "İş Ekipmanları Yön.", "Periyodik [✓]"),
                            listOf("4", "Elektrik Panoları Kaçak Akım Rölesi (30mA)", "Topraklama Yön.", "Uygun [✓]"),
                            listOf("5", "Yangın Söndürme Tüpleri 6 Aylık Basınç Kontrolü", "Binaların Yangından Kor.", "Uygun [✓]"),
                            listOf("6", "Kimyasal Madde Güvenlik Bilgi Formları (MSDS)", "Kimyasal Riskler Yön.", "Mevcut [✓]")
                        ),
                        primaryColor = primaryColor
                    )
                }

                3 -> {
                    // QUANTITATIVE RISK FORMULATION & MATRIX
                    canvas.drawText("BÖLÜM 3: RİSK DEĞERLENDİRME MATRİSLERİ VE FORMÜLLER", 24f, currentY, titlePaint)
                    currentY += 25f

                    drawCalloutBox(canvas, 24f, currentY, pageWidth - 48f, 75f, "📐 FİNE-KİNNEY FORMÜLASYONU: R = İ x Ş x F", "Risk Skoru = İhtimal (0.2 - 10) x Şiddet (1 - 100) x Frekans (0.5 - 10)\nSkor > 400 ise: 'TOLERANS EDİLEMEZ RİSK' - Çalışma derhal durdurulur ve DÖF açılır.", primaryColor)
                    currentY += 90f

                    canvas.drawText("3.1. Fine-Kinney Risk Skor Aralıkları ve Termin Tablosu", 24f, currentY, boldPaint)
                    currentY += 18f

                    drawTable(
                        canvas = canvas,
                        startX = 24f,
                        startY = currentY,
                        width = pageWidth - 48f,
                        headers = listOf("Risk Skoru", "Risk Derecesi", "Gerekli Eylem", "Termin Süresi"),
                        rows = listOf(
                            listOf("R > 400", "Tolerans Edilemez Risk", "İş derhal durdurulur", "Hemen / Aynı Gün"),
                            listOf("200 < R <= 400", "Esaslı Risk", "Kısa vadeli önlem alınır", "En geç 3-7 gün"),
                            listOf("70 < R <= 200", "Önemli Risk", "İyileştirme planlanır", "1-3 ay içinde"),
                            listOf("20 < R <= 70", "Olası Risk", "Gözlem ve kontrol", "Yıllık periyotta"),
                            listOf("R <= 20", "Kabul Edilebilir Risk", "Önlem yeterlidir", "Rutin takip")
                        ),
                        primaryColor = primaryColor
                    )
                }

                else -> {
                    // GENERAL STUDY NOTES, SUMMARY & EXAM PREPARATION
                    val moduleTitle = course.syllabus.getOrNull(pageIndex) ?: "Modül Özeti ve İpuçları"
                    canvas.drawText("BÖLÜM ${pageIndex + 1}: ${moduleTitle.uppercase()}", 24f, currentY, titlePaint)
                    currentY += 25f

                    drawCalloutBox(canvas, 24f, currentY, pageWidth - 48f, 65f, "💡 SINAV VE UYGULAMA İPUÇLARI", "Bu ünitede yer alan kritik süreler, sayısal limitler ve yönetmelik maddeleri ÖSYM İSG Sınavlarında doğrudan soru olarak sorulmaktadır.", secondaryColor)
                    currentY += 80f

                    canvas.drawText("Konu İçeriği ve Vaka İncelemesi", 24f, currentY, boldPaint)
                    currentY += 18f

                    val sampleNotes = listOf(
                        "• İşyerlerinde Acil Durumlar: Çok Tehlikeli sınıfta her 30 çalışana 1 yangın ve 1 tahliye personeli atanır.",
                        "• Gürültü Maruziyeti: En yüksek eylem değeri 85 dB(A), maruziyet sınır değeri 87 dB(A)'dır.",
                        "• Gebe ve Emziren Kadınlar: Günde 7.5 saatten fazla çalıştırılamaz, gece postasında çalıştırılması yasaktır.",
                        "• İSG Kurulları: 50 ve daha fazla çalışan bulunan ve 6 aydan fazla süren işlerde kurul kurulması zorunludur.",
                        "• İskele Güvenliği: İskeleler en geç 6 ayda bir yetkili mühendis veya tekniker tarafından denetlenir."
                    )
                    sampleNotes.forEach { note ->
                        val lines = wrapText(note, 72)
                        lines.forEach { l ->
                            canvas.drawText(l, 28f, currentY, bodyPaint)
                            currentY += 16f
                        }
                        currentY += 4f
                    }
                }
            }

            // 5. Official Verification Stamp (at bottom)
            val stampY = pageHeight - 75f
            rectPaint.color = Color.parseColor("#ECEFF1")
            canvas.drawRoundRect(RectF(24f, stampY, pageWidth - 24f, stampY + 42f), 6f, 6f, rectPaint)

            val stampPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = textMuted
                textSize = 7.5f
            }
            canvas.drawText("© 2026 ${course.domain} - İSG Cep Akademi Dijital Kütüphanesi. Tüm Hakları Saklıdır.", 36f, stampY + 16f, stampPaint)
            canvas.drawText("Bu doküman ${course.instructor} tarafından hazırlanmış olup e-imzalı resmi eğitim materyalidir.", 36f, stampY + 30f, stampPaint)

            // 6. Bottom Footer Bar with Page Number
            rectPaint.color = primaryColor
            canvas.drawRect(0f, pageHeight - 24f, pageWidth.toFloat(), pageHeight.toFloat(), rectPaint)

            val pageNumberText = "Sayfa ${pageIndex + 1} / $totalPages"
            val footerTextPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = Color.WHITE
                textSize = 9f
                isFakeBoldText = true
            }
            canvas.drawText(pageNumberText, pageWidth - 100f, pageHeight - 8f, footerTextPaint)
            canvas.drawText("${course.id.uppercase()} • ${course.domain}", 24f, pageHeight - 8f, footerTextPaint)

            document.finishPage(page)
        }

        try {
            FileOutputStream(outputFile).use { out ->
                document.writeTo(out)
            }
        } finally {
            document.close()
        }
    }

    private fun drawCalloutBox(canvas: Canvas, x: Float, y: Float, width: Float, height: Float, title: String, text: String, accentColor: Int) {
        val bgPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.parseColor("#F5F7FA")
        }
        val stripePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = accentColor
        }
        val titlePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = accentColor
            textSize = 9.5f
            isFakeBoldText = true
        }
        val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.parseColor("#37474F")
            textSize = 8.5f
        }

        canvas.drawRoundRect(RectF(x, y, x + width, y + height), 6f, 6f, bgPaint)
        canvas.drawRoundRect(RectF(x, y, x + 5f, y + height), 2f, 2f, stripePaint)

        canvas.drawText(title, x + 14f, y + 18f, titlePaint)
        val lines = wrapText(text, 65)
        var lineY = y + 32f
        lines.forEach { l ->
            canvas.drawText(l, x + 14f, lineY, textPaint)
            lineY += 12f
        }
    }

    private fun drawTable(canvas: Canvas, startX: Float, startY: Float, width: Float, headers: List<String>, rows: List<List<String>>, primaryColor: Int) {
        val colWidth = width / headers.size
        val rowHeight = 22f
        val headerPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.WHITE
            textSize = 8.5f
            isFakeBoldText = true
        }
        val cellPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.parseColor("#263238")
            textSize = 8f
        }
        val rectPaint = Paint(Paint.ANTI_ALIAS_FLAG)

        // Header
        rectPaint.color = primaryColor
        canvas.drawRect(startX, startY, startX + width, startY + rowHeight, rectPaint)

        headers.forEachIndexed { i, h ->
            canvas.drawText(h, startX + (i * colWidth) + 6f, startY + 15f, headerPaint)
        }

        var currentY = startY + rowHeight
        rows.forEachIndexed { rowIndex, row ->
            rectPaint.color = if (rowIndex % 2 == 0) Color.parseColor("#F8F9FA") else Color.WHITE
            canvas.drawRect(startX, currentY, startX + width, currentY + rowHeight, rectPaint)

            row.forEachIndexed { colIndex, cell ->
                canvas.drawText(cell, startX + (colIndex * colWidth) + 6f, currentY + 15f, cellPaint)
            }
            currentY += rowHeight
        }

        // Table outline
        rectPaint.style = Paint.Style.STROKE
        rectPaint.color = Color.parseColor("#CFD8DC")
        rectPaint.strokeWidth = 1f
        canvas.drawRect(startX, startY, startX + width, currentY, rectPaint)
    }

    private fun wrapText(text: String, maxCharsPerLine: Int): List<String> {
        val words = text.split(" ")
        val lines = mutableListOf<String>()
        var currentLine = StringBuilder()

        for (word in words) {
            if (currentLine.length + word.length + 1 > maxCharsPerLine) {
                if (currentLine.isNotEmpty()) {
                    lines.add(currentLine.toString())
                    currentLine = StringBuilder()
                }
            }
            if (currentLine.isNotEmpty()) currentLine.append(" ")
            currentLine.append(word)
        }
        if (currentLine.isNotEmpty()) {
            lines.add(currentLine.toString())
        }
        return lines
    }
}
